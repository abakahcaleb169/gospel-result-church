import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import type { Request, Response, NextFunction } from 'express';
import db from './db.ts';
import type { UserRole } from '../src/types.ts';

const JWT_SECRET = process.env.JWT_SECRET || 'church-connect-royal-covenant-secret-2026';

export interface AuthUser {
  id: number;
  email: string;
  full_name: string;
  role: UserRole;
  department: string;
}

export interface AuthRequest extends Request {
  user?: AuthUser;
}

export function hashPassword(password: string): string {
  return bcrypt.hashSync(password, 10);
}

export function verifyPassword(password: string, hash: string): boolean {
  return bcrypt.compareSync(password, hash);
}

export function signToken(user: AuthUser): string {
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      full_name: user.full_name,
      role: user.role,
      department: user.department,
    },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
}

export function authenticate(req: AuthRequest, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Authentication required. Please sign in.' });
    return;
  }

  const token = authHeader.slice(7);
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as AuthUser;
    const row = db
      .prepare('SELECT id, email, full_name, role, department, status FROM users WHERE id = ?')
      .get(decoded.id) as { id: number; email: string; full_name: string; role: UserRole; department: string; status: string } | undefined;

    if (!row) {
      res.status(401).json({ error: 'Account no longer exists.' });
      return;
    }
    if (row.status !== 'Active') {
      res.status(403).json({ error: `Account is currently ${row.status.toLowerCase()}. Contact an administrator.` });
      return;
    }
    req.user = {
      id: row.id,
      email: row.email,
      full_name: row.full_name,
      role: row.role,
      department: row.department,
    };
    next();
  } catch {
    res.status(401).json({ error: 'Invalid or expired session token. Please sign in again.' });
  }
}

export function requireRoles(...allowedRoles: UserRole[]) {
  return (req: AuthRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    if (!allowedRoles.includes(req.user.role)) {
      res.status(403).json({ error: 'You do not have permission to perform this action.' });
      return;
    }
    next();
  };
}

export function logActivity(
  user: AuthUser | null,
  action: string,
  module: string,
  details: string
): void {
  try {
    db.prepare(
      `INSERT INTO system_logs (user_id, user_name, user_role, action, module, details)
       VALUES (?, ?, ?, ?, ?, ?)`
    ).run(
      user?.id ?? null,
      user?.full_name ?? 'System',
      user?.role ?? 'System',
      action,
      module,
      details
    );
  } catch {
    // Non-blocking audit logging
  }
}
