import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';

const dataDir = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, 'church_connect.db');
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export function initializeDatabase(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS app_settings (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      app_name TEXT NOT NULL DEFAULT 'CHURCH CONNECT',
      tagline TEXT NOT NULL DEFAULT 'Connecting Members, Strengthening Faith, Building Community.',
      church_name TEXT NOT NULL DEFAULT 'Grace Covenant Cathedral',
      logo_url TEXT NOT NULL DEFAULT '',
      primary_color TEXT NOT NULL DEFAULT '#4C1D95',
      accent_color TEXT NOT NULL DEFAULT '#B48327',
      navy_color TEXT NOT NULL DEFAULT '#0F1E3D',
      theme_mode TEXT NOT NULL DEFAULT 'light',
      dark_mode_enabled INTEGER NOT NULL DEFAULT 1,
      allow_registration INTEGER NOT NULL DEFAULT 1,
      require_verification INTEGER NOT NULL DEFAULT 0,
      email_notifications_enabled INTEGER NOT NULL DEFAULT 1,
      contact_email TEXT NOT NULL DEFAULT 'office@gracecovenant.org',
      contact_phone TEXT NOT NULL DEFAULT '+1 (555) 234-8910',
      address TEXT NOT NULL DEFAULT '450 Sanctuary Boulevard, Royal Heights, NY 10024',
      about_history TEXT NOT NULL DEFAULT '',
      live_stream_url TEXT NOT NULL DEFAULT 'https://www.youtube.com/live',
      daily_verse_text TEXT NOT NULL DEFAULT '',
      daily_verse_ref TEXT NOT NULL DEFAULT '',
      social_links TEXT NOT NULL DEFAULT '{}',
      gallery_images TEXT NOT NULL DEFAULT '[]'
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      member_code TEXT UNIQUE NOT NULL,
      full_name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      phone TEXT NOT NULL DEFAULT '',
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'Church Member',
      permissions TEXT NOT NULL DEFAULT '[]',
      department TEXT NOT NULL DEFAULT 'General Congregation',
      status TEXT NOT NULL DEFAULT 'Active',
      email_verified INTEGER NOT NULL DEFAULT 0,
      phone_verified INTEGER NOT NULL DEFAULT 0,
      verification_code TEXT DEFAULT '',
      reset_token TEXT DEFAULT '',
      reset_expires TEXT DEFAULT '',
      avatar_url TEXT NOT NULL DEFAULT '',
      date_of_birth TEXT NOT NULL DEFAULT '',
      date_joined TEXT NOT NULL DEFAULT '',
      address TEXT NOT NULL DEFAULT '',
      gender TEXT NOT NULL DEFAULT '',
      marital_status TEXT NOT NULL DEFAULT '',
      occupation TEXT NOT NULL DEFAULT '',
      emergency_contact TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS announcements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      image_url TEXT NOT NULL DEFAULT '',
      category TEXT NOT NULL DEFAULT 'General',
      is_important INTEGER NOT NULL DEFAULT 0,
      is_pinned INTEGER NOT NULL DEFAULT 0,
      is_emergency INTEGER NOT NULL DEFAULT 0,
      allow_comments INTEGER NOT NULL DEFAULT 1,
      publication_date TEXT NOT NULL,
      event_date TEXT NOT NULL DEFAULT '',
      author_id INTEGER,
      author_name TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS announcement_comments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      announcement_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      author_name TEXT NOT NULL,
      author_role TEXT NOT NULL,
      content TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (announcement_id) REFERENCES announcements(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS welfare_cases (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      case_code TEXT UNIQUE NOT NULL,
      member_id INTEGER,
      member_name TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      urgency TEXT NOT NULL DEFAULT 'Medium',
      amount_requested REAL NOT NULL DEFAULT 0,
      amount_approved REAL NOT NULL DEFAULT 0,
      materials_provided TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Pending',
      assigned_officer_id INTEGER,
      assigned_officer_name TEXT NOT NULL DEFAULT '',
      confidential_notes TEXT NOT NULL DEFAULT '',
      assistance_notes TEXT NOT NULL DEFAULT '',
      visit_date TEXT NOT NULL DEFAULT '',
      created_by INTEGER,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS conferences (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      poster_url TEXT NOT NULL DEFAULT '',
      start_date TEXT NOT NULL,
      end_date TEXT NOT NULL,
      venue TEXT NOT NULL,
      theme TEXT NOT NULL DEFAULT '',
      speakers TEXT NOT NULL DEFAULT '[]',
      programme TEXT NOT NULL DEFAULT '[]',
      committees TEXT NOT NULL DEFAULT '[]',
      budget REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'Upcoming',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS conference_registrations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      conference_id INTEGER NOT NULL,
      user_id INTEGER,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL DEFAULT '',
      department TEXT NOT NULL DEFAULT '',
      attended INTEGER NOT NULL DEFAULT 0,
      registered_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (conference_id) REFERENCES conferences(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS meetings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      meeting_type TEXT NOT NULL,
      department TEXT NOT NULL DEFAULT '',
      meeting_date TEXT NOT NULL,
      venue TEXT NOT NULL,
      agenda TEXT NOT NULL DEFAULT '',
      minutes TEXT NOT NULL DEFAULT '',
      document_url TEXT NOT NULL DEFAULT '',
      document_name TEXT NOT NULL DEFAULT '',
      invitees TEXT NOT NULL DEFAULT '[]',
      attendees TEXT NOT NULL DEFAULT '[]',
      status TEXT NOT NULL DEFAULT 'Scheduled',
      reminder_sent INTEGER NOT NULL DEFAULT 0,
      created_by INTEGER,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS meeting_tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      meeting_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      assigned_to_id INTEGER,
      assigned_to_name TEXT NOT NULL,
      due_date TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Pending',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (meeting_id) REFERENCES meetings(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS departments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      leader_id INTEGER,
      leader_name TEXT NOT NULL DEFAULT '',
      meeting_schedule TEXT NOT NULL DEFAULT '',
      budget_allocation REAL NOT NULL DEFAULT 0,
      performance_notes TEXT NOT NULL DEFAULT '',
      activities_count INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS department_members (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      department_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      member_name TEXT NOT NULL,
      role_in_dept TEXT NOT NULL DEFAULT 'Member',
      joined_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS department_announcements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      department_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      author_name TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'Service',
      event_date TEXT NOT NULL,
      end_date TEXT NOT NULL DEFAULT '',
      location TEXT NOT NULL,
      poster_url TEXT NOT NULL DEFAULT '',
      reminder_sent INTEGER NOT NULL DEFAULT 0,
      created_by INTEGER,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS event_registrations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      member_name TEXT NOT NULL,
      attended INTEGER NOT NULL DEFAULT 0,
      registered_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS financial_transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      txn_code TEXT UNIQUE NOT NULL,
      type TEXT NOT NULL,
      category TEXT NOT NULL,
      amount REAL NOT NULL,
      department TEXT NOT NULL DEFAULT 'General Church',
      conference_id INTEGER,
      member_id INTEGER,
      member_name TEXT NOT NULL DEFAULT '',
      payment_method TEXT NOT NULL DEFAULT 'Bank Transfer',
      reference_no TEXT NOT NULL DEFAULT '',
      description TEXT NOT NULL DEFAULT '',
      txn_date TEXT NOT NULL,
      recorded_by TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      file_name TEXT NOT NULL,
      file_size TEXT NOT NULL DEFAULT '24 KB',
      mime_type TEXT NOT NULL DEFAULT 'text/plain',
      file_data TEXT NOT NULL DEFAULT '',
      uploaded_by TEXT NOT NULL,
      access_level TEXT NOT NULL DEFAULT 'All Members',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sender_id INTEGER NOT NULL,
      sender_name TEXT NOT NULL,
      sender_role TEXT NOT NULL,
      recipient_id INTEGER,
      recipient_name TEXT NOT NULL DEFAULT '',
      channel TEXT NOT NULL DEFAULT 'Direct',
      department TEXT NOT NULL DEFAULT '',
      subject TEXT NOT NULL,
      body TEXT NOT NULL,
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'Announcement',
      link_page TEXT NOT NULL DEFAULT 'dashboard',
      is_read INTEGER NOT NULL DEFAULT 0,
      email_dispatched INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS prayer_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      requester_name TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'Prayer Request',
      title TEXT NOT NULL,
      details TEXT NOT NULL,
      is_confidential INTEGER NOT NULL DEFAULT 0,
      preferred_date TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Submitted',
      pastor_response TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS visitors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL DEFAULT '',
      phone TEXT NOT NULL DEFAULT '',
      visit_date TEXT NOT NULL,
      service_attended TEXT NOT NULL DEFAULT 'Sunday Morning Service',
      invited_by TEXT NOT NULL DEFAULT '',
      prayer_need TEXT NOT NULL DEFAULT '',
      follow_up_status TEXT NOT NULL DEFAULT 'New',
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS attendance_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      service_date TEXT NOT NULL,
      service_name TEXT NOT NULL,
      men_count INTEGER NOT NULL DEFAULT 0,
      women_count INTEGER NOT NULL DEFAULT 0,
      youth_count INTEGER NOT NULL DEFAULT 0,
      children_count INTEGER NOT NULL DEFAULT 0,
      visitors_count INTEGER NOT NULL DEFAULT 0,
      total_count INTEGER NOT NULL DEFAULT 0,
      recorded_by TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS system_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      user_name TEXT NOT NULL,
      user_role TEXT NOT NULL,
      action TEXT NOT NULL,
      module TEXT NOT NULL,
      details TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  seedInitialData();
}

function seedInitialData(): void {
  const settingsCount = (db.prepare('SELECT COUNT(*) as c FROM app_settings').get() as { c: number }).c;
  if (settingsCount === 0) {
    const gallery = [
      {
        id: 'gal-1',
        title: 'Sanctuary Dedication & Worship',
        caption: 'Sunday morning worship inside the newly renovated main sanctuary.',
        url: '/src/assets/images/church_sanctuary_hero_1794690388207.jpg',
        date: '2026-10-18',
      },
      {
        id: 'gal-2',
        title: 'Annual Kingdom Leadership Summit',
        caption: 'Over 640 leaders, elders, and ministry heads gathered for renewal.',
        url: '/src/assets/images/conference_banner_1794690387986.jpg',
        date: '2026-10-28',
      },
      {
        id: 'gal-3',
        title: 'Atrium Fellowship Hour',
        caption: 'Members and first-time guests sharing fellowship after second service.',
        url: '/src/assets/images/community_fellowship_1794690387540.jpg',
        date: '2026-11-08',
      },
    ];

    db.prepare(
      `INSERT INTO app_settings (
        id, app_name, tagline, church_name, logo_url, primary_color, accent_color, navy_color,
        theme_mode, dark_mode_enabled, allow_registration, require_verification, email_notifications_enabled,
        contact_email, contact_phone, address, about_history, live_stream_url,
        daily_verse_text, daily_verse_ref, social_links, gallery_images
      ) VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, 0, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      'GOSPEL RESULTS CHURCH GHANA',
      'Connecting Members, Strengthening Faith, Building Community.',
      'GOSPEL RESULTS CHURCH GHANA',
      '/assets/aistudio/IMG_0954_b4f1f733.jpeg',
      '#4C1D95',
      '#B48327',
      '#0F1E3D',
      'light',
      'office@gospelresultschurchghana.org',
      '+233 24 000 0000',
      'Accra, Ghana',
      'Founded with a mandate to win souls and nurture believers into maturity, Gospel Results Church Ghana is a vibrant parish committed to sound biblical teaching, compassionate community welfare, and missions across Ghana and beyond.',
      'https://www.youtube.com/watch?v=live_sanctuary_stream',
      'Let us consider how we may spur one another on toward love and good deeds, not giving up meeting together, as some are in the habit of doing, but encouraging one another.',
      'Hebrews 10:24-25',
      JSON.stringify({
        facebook: 'https://facebook.com/gospelresultschurchghana',
        youtube: 'https://youtube.com/@gospelresultschurchghana',
        instagram: 'https://instagram.com/gospelresultschurchghana',
        website: 'https://gospelresultschurchghana.org',
      }),
      JSON.stringify(gallery)
    );
  } else {
    db.prepare(
      `UPDATE app_settings
       SET app_name = 'GOSPEL RESULTS CHURCH GHANA',
           church_name = 'GOSPEL RESULTS CHURCH GHANA',
           logo_url = '/assets/aistudio/IMG_0954_b4f1f733.jpeg'
       WHERE id = 1 AND app_name = 'CHURCH CONNECT'`
    ).run();
  }

  const userCount = (db.prepare('SELECT COUNT(*) as c FROM users').get() as { c: number }).c;
  if (userCount === 0) {
    const defaultHash = bcrypt.hashSync('ChurchConnect2026!', 10);
    const seedUsers = [
      {
        member_code: 'CC-2026-0001',
        full_name: 'Dr. Emmanuel Mensah',
        email: 'admin@churchconnect.org',
        phone: '+1 (555) 101-1001',
        role: 'Super Administrator',
        department: 'Media Department',
        avatar_url: '/src/assets/images/church_crest_emblem_1794690387521.jpg',
        date_of_birth: '1980-11-18',
        date_joined: '2012-03-14',
        address: '12 Covenant Ridge Way, NY',
        gender: 'Male',
        marital_status: 'Married',
        occupation: 'Chief Systems Architect',
        emergency_contact: 'Grace Mensah (+1 555-101-1002)',
      },
      {
        member_code: 'CC-2026-0002',
        full_name: 'Pastor Samuel Osei',
        email: 'pastor@churchconnect.org',
        phone: '+1 (555) 101-2001',
        role: 'Senior Pastor',
        department: 'Prayer Department',
        avatar_url: '/src/assets/images/pastor_portrait_1794690388392.jpg',
        date_of_birth: '1968-11-22',
        date_joined: '1998-05-10',
        address: '101 Shepherd Hill Road, NY',
        gender: 'Male',
        marital_status: 'Married',
        occupation: 'Senior Clergyman',
        emergency_contact: 'Evelyn Osei (+1 555-101-2002)',
      },
      {
        member_code: 'CC-2026-0003',
        full_name: 'Rev. Miriam Boateng',
        email: 'assistant.pastor@churchconnect.org',
        phone: '+1 (555) 101-3001',
        role: 'Assistant Pastor',
        department: 'Evangelism Department',
        avatar_url: '',
        date_of_birth: '1979-06-14',
        date_joined: '2015-09-01',
        address: '45 Olive Terrace, NY',
        gender: 'Female',
        marital_status: 'Married',
        occupation: 'Associate Minister',
        emergency_contact: 'Daniel Boateng (+1 555-101-3002)',
      },
      {
        member_code: 'CC-2026-0004',
        full_name: 'Victoria Sterling',
        email: 'church.admin@churchconnect.org',
        phone: '+1 (555) 101-4001',
        role: 'Church Administrator',
        department: 'Ushering Department',
        avatar_url: '',
        date_of_birth: '1984-11-26',
        date_joined: '2016-01-20',
        address: '78 Laurel Lane, NY',
        gender: 'Female',
        marital_status: 'Married',
        occupation: 'Operations Director',
        emergency_contact: 'Mark Sterling (+1 555-101-4002)',
      },
      {
        member_code: 'CC-2026-0005',
        full_name: 'Hannah Thompson',
        email: 'secretary@churchconnect.org',
        phone: '+1 (555) 101-5001',
        role: 'Church Secretary',
        department: 'Choir Department',
        avatar_url: '',
        date_of_birth: '1990-04-09',
        date_joined: '2018-07-12',
        address: '214 Cedar Court, NY',
        gender: 'Female',
        marital_status: 'Single',
        occupation: 'Executive Secretary',
        emergency_contact: 'Ruth Thompson (+1 555-101-5002)',
      },
      {
        member_code: 'CC-2026-0006',
        full_name: 'Deacon Nathaniel Brooks',
        email: 'finance@churchconnect.org',
        phone: '+1 (555) 101-6001',
        role: 'Financial Secretary',
        department: "Men's Ministry",
        avatar_url: '',
        date_of_birth: '1975-09-30',
        date_joined: '2010-11-04',
        address: '89 Harbor View Drive, NY',
        gender: 'Male',
        marital_status: 'Married',
        occupation: 'Certified Public Accountant',
        emergency_contact: 'Claire Brooks (+1 555-101-6002)',
      },
      {
        member_code: 'CC-2026-0007',
        full_name: 'Deaconess Martha Appiah',
        email: 'welfare@churchconnect.org',
        phone: '+1 (555) 101-7001',
        role: 'Welfare Officer',
        department: 'Welfare Department',
        avatar_url: '',
        date_of_birth: '1977-11-16',
        date_joined: '2011-02-19',
        address: '33 Mercy Lane, NY',
        gender: 'Female',
        marital_status: 'Married',
        occupation: 'Clinical Social Worker',
        emergency_contact: 'Isaac Appiah (+1 555-101-7002)',
      },
      {
        member_code: 'CC-2026-0008',
        full_name: 'Caleb Bennett',
        email: 'leader@churchconnect.org',
        phone: '+1 (555) 101-8001',
        role: 'Department Leader',
        department: 'Youth Department',
        avatar_url: '',
        date_of_birth: '1994-08-21',
        date_joined: '2019-06-02',
        address: '67 Summit Ave, NY',
        gender: 'Male',
        marital_status: 'Single',
        occupation: 'Youth Educator',
        emergency_contact: 'Sarah Bennett (+1 555-101-8002)',
      },
      {
        member_code: 'CC-2026-0009',
        full_name: 'Grace Adeyemi',
        email: 'member@churchconnect.org',
        phone: '+1 (555) 101-9001',
        role: 'Church Member',
        department: "Women's Ministry",
        avatar_url: '',
        date_of_birth: '1992-11-29',
        date_joined: '2022-03-15',
        address: '192 Meadowbrook Street, NY',
        gender: 'Female',
        marital_status: 'Married',
        occupation: 'Registered Nurse',
        emergency_contact: 'Tunde Adeyemi (+1 555-101-9002)',
      },
      {
        member_code: 'CC-2026-0010',
        full_name: 'David Morales',
        email: 'david.morales@churchconnect.org',
        phone: '+1 (555) 101-9010',
        role: 'Church Member',
        department: 'Media Department',
        avatar_url: '',
        date_of_birth: '1996-02-11',
        date_joined: '2023-08-06',
        address: '54 Birchwood Ave, NY',
        gender: 'Male',
        marital_status: 'Single',
        occupation: 'Audio Engineer',
        emergency_contact: 'Elena Morales (+1 555-101-9011)',
      },
      {
        member_code: 'CC-2026-0011',
        full_name: 'Rebecca Lindqvist',
        email: 'rebecca.l@churchconnect.org',
        phone: '+1 (555) 101-9012',
        role: 'Department Leader',
        department: "Children's Ministry",
        avatar_url: '',
        date_of_birth: '1988-05-03',
        date_joined: '2017-04-22',
        address: '82 Willow Creek, NY',
        gender: 'Female',
        marital_status: 'Married',
        occupation: 'Elementary Teacher',
        emergency_contact: 'Peter Lindqvist (+1 555-101-9013)',
      },
      {
        member_code: 'CC-2026-0012',
        full_name: 'Joseph Vance',
        email: 'joseph.vance@churchconnect.org',
        phone: '+1 (555) 101-9014',
        role: 'Church Member',
        department: 'Ushering Department',
        avatar_url: '',
        date_of_birth: '1983-11-15',
        date_joined: '2020-09-13',
        address: '140 Oakwood Blvd, NY',
        gender: 'Male',
        marital_status: 'Married',
        occupation: 'Civil Engineer',
        emergency_contact: 'Naomi Vance (+1 555-101-9015)',
      },
    ];

    const insertUser = db.prepare(
      `INSERT INTO users (
        member_code, full_name, email, phone, password_hash, role, permissions, department,
        status, email_verified, phone_verified, avatar_url, date_of_birth, date_joined,
        address, gender, marital_status, occupation, emergency_contact
      ) VALUES (?, ?, ?, ?, ?, ?, '[]', ?, 'Active', 1, 1, ?, ?, ?, ?, ?, ?, ?, ?)`
    );

    for (const u of seedUsers) {
      insertUser.run(
        u.member_code,
        u.full_name,
        u.email,
        u.phone,
        defaultHash,
        u.role,
        u.department,
        u.avatar_url,
        u.date_of_birth,
        u.date_joined,
        u.address,
        u.gender,
        u.marital_status,
        u.occupation,
        u.emergency_contact
      );
    }
  }

  const deptCount = (db.prepare('SELECT COUNT(*) as c FROM departments').get() as { c: number }).c;
  if (deptCount === 0) {
    const depts = [
      ['Choir Department', 'Leading the congregation in reverent choral and contemporary praise during every service.', 5, 'Hannah Thompson', 'Thursdays 6:30 PM · Main Sanctuary', 14500, 'Preparing 18-voice cantata for Annual Harvest & Christmas Eve.', 12],
      ['Ushering Department', 'Hospitality, sanctuary order, visitor welcome, and communion assistance.', 4, 'Victoria Sterling', 'Saturdays 4:00 PM · Atrium', 4200, '98% service coverage across both Sunday worship gatherings.', 9],
      ['Youth Department', 'Mentoring young adults and teens in scripture, leadership, and community service.', 8, 'Caleb Bennett', 'Fridays 6:00 PM · Youth Chapel', 18000, 'Campus outreach grew weekly youth attendance by 22% this quarter.', 15],
      ["Men's Ministry", 'Fostering godly brotherhood, family leadership, and practical community mentoring.', 6, 'Deacon Nathaniel Brooks', '1st Saturday 8:00 AM · Fellowship Hall', 8500, 'Completed community carpentry support for 4 senior households.', 7],
      ["Women's Ministry", 'Equipping women across generations through prayer circles, mentorship, and hospitality.', 9, 'Grace Adeyemi', '2nd Saturday 10:00 AM · Chapel B', 9200, 'Annual Women of Grace retreat registrations exceeded target.', 10],
      ["Children's Ministry", 'Christ-centered Bible storytelling, music, and safe age-graded classes for ages 2–12.', 11, 'Rebecca Lindqvist', 'Sundays 8:15 AM · Kids Wing', 11000, 'All 18 volunteers certified in child safety and curriculum prep.', 14],
      ['Evangelism Department', 'Neighborhood outreach, follow-up visitation, and local mission partnerships.', 3, 'Rev. Miriam Boateng', 'Saturdays 9:30 AM · Mission Room', 12600, '38 new visitor follow-ups completed in the last 30 days.', 11],
      ['Media Department', 'Broadcast livestreaming, sanctuary acoustics, projection, and photography archive.', 1, 'Dr. Emmanuel Mensah', 'Saturdays 2:00 PM · Broadcast Booth', 22000, 'Upgraded 4K sanctuary livestream encoder with zero downtime.', 16],
      ['Prayer Department', 'Intercessory watches, altar ministry, and weekly corporate prayer evenings.', 2, 'Pastor Samuel Osei', 'Wednesdays 6:00 PM · Prayer Chapel', 3400, '24-hour chain of prayer sustained ahead of November Convocation.', 18],
      ['Welfare Department', 'Confidential benevolence, hospital visitation, food pantry, and bereavement care.', 7, 'Deaconess Martha Appiah', 'Tuesdays 5:30 PM · Care Suite', 32000, '44 families supported with food hampers, medical aid, and rent relief.', 19],
    ];
    const insertDept = db.prepare(
      `INSERT INTO departments (name, description, leader_id, leader_name, meeting_schedule, budget_allocation, performance_notes, activities_count)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    );
    for (const d of depts) {
      insertDept.run(...d);
    }

    // Seed department memberships
    const insertDeptMem = db.prepare(
      `INSERT INTO department_members (department_id, user_id, member_name, role_in_dept) VALUES (?, ?, ?, ?)`
    );
    insertDeptMem.run(1, 5, 'Hannah Thompson', 'Choir Director');
    insertDeptMem.run(2, 4, 'Victoria Sterling', 'Head Usher');
    insertDeptMem.run(2, 12, 'Joseph Vance', 'Member');
    insertDeptMem.run(3, 8, 'Caleb Bennett', 'Youth Leader');
    insertDeptMem.run(4, 6, 'Deacon Nathaniel Brooks', 'Men Coordinator');
    insertDeptMem.run(5, 9, 'Grace Adeyemi', 'Ministry Coordinator');
    insertDeptMem.run(6, 11, 'Rebecca Lindqvist', 'Children Director');
    insertDeptMem.run(7, 3, 'Rev. Miriam Boateng', 'Outreach Lead');
    insertDeptMem.run(8, 1, 'Dr. Emmanuel Mensah', 'Media Director');
    insertDeptMem.run(8, 10, 'David Morales', 'Audio Engineer');
    insertDeptMem.run(9, 2, 'Pastor Samuel Osei', 'Spiritual Oversight');
    insertDeptMem.run(10, 7, 'Deaconess Martha Appiah', 'Chief Welfare Officer');

    db.prepare(
      `INSERT INTO department_announcements (department_id, title, content, author_name) VALUES (?, ?, ?, ?)`
    ).run(1, 'Thanksgiving Cantata Rehearsal', 'Full choir dress rehearsal moves to Friday at 6:30 PM with the brass ensemble.', 'Hannah Thompson');
    db.prepare(
      `INSERT INTO department_announcements (department_id, title, content, author_name) VALUES (?, ?, ?, ?)`
    ).run(3, 'Youth Mentorship Night', 'Bring a friend this Friday for interactive small groups and dinner in the Youth Chapel.', 'Caleb Bennett');
  }

  const annCount = (db.prepare('SELECT COUNT(*) as c FROM announcements').get() as { c: number }).c;
  if (annCount === 0) {
    db.prepare(
      `INSERT INTO announcements (title, description, image_url, category, is_important, is_pinned, is_emergency, allow_comments, publication_date, event_date, author_id, author_name)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      '2026 Kingdom Leadership & Renewal Convocation',
      'Join our three-day annual convocation featuring morning leadership intensives, evening revival worship, and departmental commissioning. Registration is open inside the Conferences module for all members and ministry workers.',
      '/src/assets/images/conference_banner_1794690387986.jpg',
      'Conference',
      1,
      1,
      0,
      1,
      '2026-11-10',
      '2026-11-27',
      2,
      'Pastor Samuel Osei'
    );
    db.prepare(
      `INSERT INTO announcements (title, description, image_url, category, is_important, is_pinned, is_emergency, allow_comments, publication_date, event_date, author_id, author_name)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      'Winter Community Food & Coat Drive — Welfare Outreach',
      'Our Welfare Department is collecting non-perishable pantry staples and winter coats through November 24 to bless 120 neighborhood families. Drop-off bins are stationed in the main atrium before and after Sunday services.',
      '/src/assets/images/community_fellowship_1794690387540.jpg',
      'Welfare',
      1,
      0,
      0,
      1,
      '2026-11-12',
      '2026-11-24',
      7,
      'Deaconess Martha Appiah'
    );
    db.prepare(
      `INSERT INTO announcements (title, description, image_url, category, is_important, is_pinned, is_emergency, allow_comments, publication_date, event_date, author_id, author_name)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      'Sanctuary Thanksgiving Eve Candlelight Service',
      'Gather with your household on Wednesday, November 25 at 7:00 PM for an evening of scripture readings, choir anthems, testimonies, and Holy Communion.',
      '/src/assets/images/church_sanctuary_hero_1794690388207.jpg',
      'Worship Service',
      0,
      0,
      0,
      1,
      '2026-11-13',
      '2026-11-25',
      5,
      'Hannah Thompson'
    );

    db.prepare(
      `INSERT INTO announcement_comments (announcement_id, user_id, author_name, author_role, content)
       VALUES (?, ?, ?, ?, ?)`
    ).run(1, 9, 'Grace Adeyemi', 'Church Member', 'Already registered! Looking forward to the Friday morning leadership session.');
  }

  const welfareCount = (db.prepare('SELECT COUNT(*) as c FROM welfare_cases').get() as { c: number }).c;
  if (welfareCount === 0) {
    const insertWelfare = db.prepare(
      `INSERT INTO welfare_cases (
        case_code, member_id, member_name, category, description, urgency,
        amount_requested, amount_approved, materials_provided, status,
        assigned_officer_id, assigned_officer_name, confidential_notes, assistance_notes, visit_date, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    insertWelfare.run(
      'WLF-2026-014',
      12,
      'Joseph Vance',
      'Hospital Visit',
      'Post-operative recovery support and meal delivery following orthopedic surgery at St. Luke Medical Center.',
      'High',
      600,
      600,
      '7-day family meal package & devotional care kit',
      'Approved',
      7,
      'Deaconess Martha Appiah',
      'Family requested discreet pastoral visitation after 4 PM.',
      'Visitation team completed hospital prayer visit; financial stipend transferred.',
      '2026-11-16',
      7
    );
    insertWelfare.run(
      'WLF-2026-015',
      9,
      'Grace Adeyemi',
      'Food & Material Donation',
      'Household pantry replenishment and winter clothing assistance for newly relocated sister family.',
      'Medium',
      350,
      350,
      '2 family food hampers, 3 winter coats',
      'Completed',
      7,
      'Deaconess Martha Appiah',
      'Coordinated directly with Women Ministry care coordinator.',
      'Delivered hampers and coats on Nov 11.',
      '2026-11-11',
      7
    );
    insertWelfare.run(
      'WLF-2026-016',
      null,
      'Elder Arthur Pendelton',
      'Bereavement Support',
      'Funeral travel and family condolence assistance following passing of spouse.',
      'Critical',
      1500,
      1500,
      'Condolence floral wreath & hospitality catering for wake',
      'In Progress',
      7,
      'Deaconess Martha Appiah',
      'Senior Pastor scheduled to officiate memorial service on Nov 21.',
      'First disbursement processed; memorial logistics underway.',
      '2026-11-18',
      2
    );
    insertWelfare.run(
      'WLF-2026-017',
      10,
      'David Morales',
      'Emergency Assistance',
      'Temporary utility & rent bridge request following sudden medical leave.',
      'High',
      950,
      0,
      '',
      'Pending',
      7,
      'Deaconess Martha Appiah',
      'Awaiting Financial Secretary verification of emergency reserve allocation.',
      '',
      '2026-11-19',
      10
    );
  }

  const confCount = (db.prepare('SELECT COUNT(*) as c FROM conferences').get() as { c: number }).c;
  if (confCount === 0) {
    db.prepare(
      `INSERT INTO conferences (title, description, poster_url, start_date, end_date, venue, theme, speakers, programme, committees, budget, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      'Annual Kingdom Leadership & Renewal Convocation 2026',
      'Three days of intensive biblical leadership training, prophetic worship, departmental strategy workshops, and commissioning for the 2027 ministry year.',
      '/src/assets/images/conference_banner_1794690387986.jpg',
      '2026-11-27',
      '2026-11-29',
      'Grace Covenant Main Sanctuary & Grand Atrium',
      'Empowered, United, Called',
      JSON.stringify([
        { name: 'Pastor Samuel Osei', role: 'Senior Pastor & Host', topic: 'Stewards of Faithful Service' },
        { name: 'Dr. David Thompson', role: 'Guest Keynote Speaker', topic: 'Building Resilient Congregations' },
        { name: 'Rev. Miriam Boateng', role: 'Associate Minister', topic: 'Compassionate Urban Outreach' },
      ]),
      JSON.stringify([
        { day: 'Day 1 · Fri Nov 27', time: '6:00 PM – 9:00 PM', session: 'Opening Convocation & Worship', speaker: 'Pastor Samuel Osei' },
        { day: 'Day 2 · Sat Nov 28', time: '9:30 AM – 1:00 PM', session: 'Leadership & Departmental Labs', speaker: 'Dr. David Thompson' },
        { day: 'Day 2 · Sat Nov 28', time: '6:00 PM – 8:30 PM', session: 'Evening Impartation Service', speaker: 'Rev. Miriam Boateng' },
        { day: 'Day 3 · Sun Nov 29', time: '10:00 AM – 1:00 PM', session: 'Commissioning & Thanksgiving', speaker: 'Pastor Samuel Osei' },
      ]),
      JSON.stringify([
        { name: 'Hospitality & Protocol', lead: 'Victoria Sterling', members: 'Ushering & Catering Teams' },
        { name: 'Media & Livestream', lead: 'Dr. Emmanuel Mensah', members: 'Broadcast & Projection Crew' },
        { name: 'Finance & Registration', lead: 'Deacon Nathaniel Brooks', members: 'Check-in & Treasury Desk' },
      ]),
      24500,
      'Upcoming'
    );

    db.prepare(
      `INSERT INTO conferences (title, description, poster_url, start_date, end_date, venue, theme, speakers, programme, committees, budget, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      'Youth & Next-Gen Faith Summit 2027',
      'Equipping students and young professionals to integrate Christian integrity into university, career, and creative leadership.',
      '/src/assets/images/community_fellowship_1794690387540.jpg',
      '2027-01-15',
      '2027-01-17',
      'Youth Chapel & North Campus Hall',
      'Rooted & Courageous',
      JSON.stringify([
        { name: 'Caleb Bennett', role: 'Youth Department Leader', topic: 'Anchored in Purpose' },
        { name: 'Rebecca Lindqvist', role: 'Christian Educator', topic: 'Mentoring the Rising Generation' },
      ]),
      JSON.stringify([
        { day: 'Day 1 · Fri Jan 15', time: '6:30 PM', session: 'Worship & Keynote', speaker: 'Caleb Bennett' },
        { day: 'Day 2 · Sat Jan 16', time: '10:00 AM', session: 'Career & Calling Panels', speaker: 'Rebecca Lindqvist' },
      ]),
      JSON.stringify([
        { name: 'Youth Planning Board', lead: 'Caleb Bennett', members: '14 Youth Volunteers' },
      ]),
      12000,
      'Upcoming'
    );

    db.prepare(
      `INSERT INTO conference_registrations (conference_id, user_id, full_name, email, phone, department, attended)
       VALUES (1, 9, 'Grace Adeyemi', 'member@churchconnect.org', '+1 (555) 101-9001', 'Women''s Ministry', 0),
              (1, 8, 'Caleb Bennett', 'leader@churchconnect.org', '+1 (555) 101-8001', 'Youth Department', 0),
              (1, 5, 'Hannah Thompson', 'secretary@churchconnect.org', '+1 (555) 101-5001', 'Choir Department', 0)`
    ).run();
  }

  const meetingCount = (db.prepare('SELECT COUNT(*) as c FROM meetings').get() as { c: number }).c;
  if (meetingCount === 0) {
    db.prepare(
      `INSERT INTO meetings (title, meeting_type, department, meeting_date, venue, agenda, minutes, invitees, attendees, status, reminder_sent, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      'Monthly Church Council & Board Review',
      'Leadership Meeting',
      'Leadership',
      '2026-11-19T18:30',
      'Executive Boardroom · Suite 201',
      '1. Opening Prayer & Devotion\n2. November Convocation Readiness\n3. Q4 Welfare Budget Allocation\n4. Year-End Sanctuary Maintenance Plan',
      '',
      JSON.stringify(['Pastor Samuel Osei', 'Victoria Sterling', 'Deacon Nathaniel Brooks', 'Deaconess Martha Appiah', 'Hannah Thompson']),
      JSON.stringify([]),
      'Scheduled',
      1,
      4
    );

    db.prepare(
      `INSERT INTO meetings (title, meeting_type, department, meeting_date, venue, agenda, minutes, invitees, attendees, status, reminder_sent, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      'Choir & Media Thanksgiving Production Sync',
      'Departmental Meeting',
      'Choir Department',
      '2026-11-16T19:00',
      'Main Sanctuary Choir Loft',
      '1. Cantata Song Order\n2. Wireless Microphone Assignments\n3. Livestream Lighting Cues',
      'Confirmed 18-voice choir layout and 3 solo microphone channels. Lighting rehearsal locked for Nov 24.',
      JSON.stringify(['Hannah Thompson', 'Dr. Emmanuel Mensah', 'David Morales']),
      JSON.stringify(['Hannah Thompson', 'Dr. Emmanuel Mensah', 'David Morales']),
      'Completed',
      1,
      5
    );

    db.prepare(
      `INSERT INTO meeting_tasks (meeting_id, title, assigned_to_id, assigned_to_name, due_date, status)
       VALUES (1, 'Finalize Convocation printed programmes (700 copies)', 5, 'Hannah Thompson', '2026-11-22', 'Pending'),
              (1, 'Approve Q4 Welfare Reserve transfer of $4,500', 6, 'Deacon Nathaniel Brooks', '2026-11-20', 'Pending'),
              (2, 'Test sanctuary livestream audio bus and backup recorder', 10, 'David Morales', '2026-11-23', 'Completed')`
    ).run();
  }

  const eventCount = (db.prepare('SELECT COUNT(*) as c FROM events').get() as { c: number }).c;
  if (eventCount === 0) {
    const insertEvent = db.prepare(
      `INSERT INTO events (title, description, category, event_date, end_date, location, poster_url, reminder_sent, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    insertEvent.run(
      'Sunday Celebration Worship Services',
      'Two morning services featuring expository preaching by Pastor Samuel Osei, choral praise, and age-graded Children’s Ministry.',
      'Worship Service',
      '2026-11-15T09:00',
      '2026-11-15T12:30',
      'Main Sanctuary',
      '/src/assets/images/church_sanctuary_hero_1794690388207.jpg',
      1,
      2
    );
    insertEvent.run(
      'Midweek Corporate Prayer & Bible Exposition',
      'Verse-by-verse study in Ephesians followed by corporate intercession for families and our city.',
      'Prayer & Study',
      '2026-11-18T18:30',
      '2026-11-18T20:00',
      'Prayer Chapel',
      '',
      0,
      2
    );
    insertEvent.run(
      'New Members Welcome Luncheon',
      'Hosted by Pastoral Care and Ushering for recent visitors and new church family members.',
      'Fellowship',
      '2026-11-22T12:45',
      '2026-11-22T14:30',
      'Grand Atrium & Fellowship Hall',
      '/src/assets/images/community_fellowship_1794690387540.jpg',
      0,
      4
    );
    insertEvent.run(
      'Thanksgiving Eve Candlelight & Communion',
      'Special midweek worship gathering with choir anthems and Holy Communion.',
      'Special Service',
      '2026-11-25T19:00',
      '2026-11-25T20:45',
      'Main Sanctuary',
      '/src/assets/images/church_sanctuary_hero_1794690388207.jpg',
      0,
      2
    );
  }

  const finCount = (db.prepare('SELECT COUNT(*) as c FROM financial_transactions').get() as { c: number }).c;
  if (finCount === 0) {
    const txns = [
      ['TXN-2026-1001', 'Income', 'Tithe', 18450, 'General Church', null, null, 'Congregation Tithe Batch', 'Electronic Giving', 'EL-88412', 'First Sunday tithes', '2026-09-06', 'Deacon Nathaniel Brooks'],
      ['TXN-2026-1002', 'Income', 'Offering', 9240, 'General Church', null, null, 'Sunday Offering Plate', 'Cash & Card', 'OF-88413', 'September worship offerings', '2026-09-13', 'Deacon Nathaniel Brooks'],
      ['TXN-2026-1003', 'Expense', 'Utility & Maintenance', 4120, 'General Church', null, null, 'City Power & Sanctuary HVAC', 'ACH Debit', 'AP-4410', 'Monthly utilities & facility care', '2026-09-20', 'Deacon Nathaniel Brooks'],
      ['TXN-2026-1004', 'Income', 'Tithe', 21300, 'General Church', null, null, 'Congregation Tithe Batch', 'Electronic Giving', 'EL-89001', 'October tithe stewardship', '2026-10-04', 'Deacon Nathaniel Brooks'],
      ['TXN-2026-1005', 'Income', 'Welfare Contribution', 6800, 'Welfare Department', null, null, 'Welfare Love Offering', 'Bank Transfer', 'WL-89008', 'Dedicated benevolent fund support', '2026-10-11', 'Deacon Nathaniel Brooks'],
      ['TXN-2026-1006', 'Expense', 'Welfare Disbursement', 3250, 'Welfare Department', null, null, 'Benevolence Care Cases', 'Check', 'AP-4502', 'October family grocery & medical assistance', '2026-10-18', 'Deacon Nathaniel Brooks'],
      ['TXN-2026-1007', 'Income', 'Conference Income', 11400, 'Media Department', 1, null, 'Convocation Registration & Sponsorships', 'Card & Transfer', 'CF-2026-01', 'Early conference registrations', '2026-10-25', 'Deacon Nathaniel Brooks'],
      ['TXN-2026-1008', 'Expense', 'Conference Expense', 5600, 'Media Department', 1, null, 'Stage Audio & Print Deposit', 'Bank Transfer', 'AP-4590', 'Convocation production & brochures', '2026-11-02', 'Deacon Nathaniel Brooks'],
      ['TXN-2026-1009', 'Income', 'Tithe', 19850, 'General Church', null, 12, 'Joseph Vance & Nov Batch', 'Electronic Giving', 'EL-90122', 'November week 1 & 2 tithes', '2026-11-08', 'Deacon Nathaniel Brooks'],
      ['TXN-2026-1010', 'Income', 'Special Contribution', 7500, 'Youth Department', null, null, 'Next-Gen Scholarship Pledge', 'Bank Transfer', 'SP-90140', 'Youth outreach & retreat sponsorship', '2026-11-10', 'Deacon Nathaniel Brooks'],
      ['TXN-2026-1011', 'Income', 'Donation', 4200, "Choir Department", null, 9, 'Grace Adeyemi & Choir Friends', 'Online Card', 'DN-90155', 'Sanctuary music instrument fund', '2026-11-12', 'Deacon Nathaniel Brooks'],
      ['TXN-2026-1012', 'Expense', 'Ministry Outreach', 2890, 'Evangelism Department', null, null, 'Neighborhood Outreach Supplies', 'Card', 'AP-4618', 'Bibles, invitation cards, and hospitality packs', '2026-11-13', 'Deacon Nathaniel Brooks'],
    ];
    const insertTxn = db.prepare(
      `INSERT INTO financial_transactions (
        txn_code, type, category, amount, department, conference_id, member_id,
        member_name, payment_method, reference_no, description, txn_date, recorded_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    for (const t of txns) {
      insertTxn.run(...t);
    }
  }

  const docCount = (db.prepare('SELECT COUNT(*) as c FROM documents').get() as { c: number }).c;
  if (docCount === 0) {
    const insertDoc = db.prepare(
      `INSERT INTO documents (title, category, description, file_name, file_size, mime_type, file_data, uploaded_by, access_level)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    const makeTextUri = (text: string) =>
      `data:text/plain;charset=utf-8,${encodeURIComponent(text)}`;

    insertDoc.run(
      'Grace Covenant Cathedral Constitution & Bylaws (2026 Edition)',
      'Church Constitution',
      'Official governance charter covering membership covenants, elder oversight, and departmental administration.',
      'Church_Constitution_2026.txt',
      '14 KB',
      'text/plain',
      makeTextUri('GRACE COVENANT CATHEDRAL — CONSTITUTION & BYLAWS\nArticle I: Name & Mission\nConnecting Members, Strengthening Faith, Building Community.\nArticle II: Leadership & Ministry Oversight...'),
      'Victoria Sterling',
      'All Members'
    );
    insertDoc.run(
      'Ephesians Verse-by-Verse Study Guide (Weeks 1–8)',
      'Bible Study Material',
      'Printable small-group discussion questions and scripture cross-references for midweek study.',
      'Ephesians_Study_Guide.txt',
      '8 KB',
      'text/plain',
      makeTextUri('MIDWEEK BIBLE EXPOSITION: EPHESIANS\nWeek 1: Spiritual Blessings in Christ (Eph 1:1-14)\nDiscussion Prompt: How does our identity in Christ reshape community hospitality?'),
      'Pastor Samuel Osei',
      'All Members'
    );
    insertDoc.run(
      '2026 Kingdom Convocation Official Programme',
      'Conference Document',
      'Complete 3-day schedule, workshop rooms, and speaker biographies.',
      'Convocation_2026_Programme.txt',
      '6 KB',
      'text/plain',
      makeTextUri('2026 KINGDOM LEADERSHIP CONVOCATION\nTheme: Empowered, United, Called\nNov 27-29 · Main Sanctuary'),
      'Hannah Thompson',
      'All Members'
    );
    insertDoc.run(
      'Child Protection & Volunteer Safeguarding Policy',
      'Church Policy',
      'Mandatory safety guidelines for Children’s and Youth Ministry leaders.',
      'Safeguarding_Policy_2026.txt',
      '11 KB',
      'text/plain',
      makeTextUri('SAFEGUARDING POLICY\nAll volunteers serving minors must maintain active background clearance and two-adult classroom presence.'),
      'Rebecca Lindqvist',
      'Leaders'
    );
  }

  const msgCount = (db.prepare('SELECT COUNT(*) as c FROM messages').get() as { c: number }).c;
  if (msgCount === 0) {
    const insertMsg = db.prepare(
      `INSERT INTO messages (sender_id, sender_name, sender_role, recipient_id, recipient_name, channel, department, subject, body, is_read)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    insertMsg.run(
      2,
      'Pastor Samuel Osei',
      'Senior Pastor',
      null,
      'All Department Leaders',
      'Leadership',
      'Leadership',
      'Preparation for November Convocation Prayer Watch',
      'Dear Ministry Leaders, please encourage your department members to join Wednesday evening prayer at 6:00 PM as we prepare our hearts for the upcoming convocation.',
      0
    );
    insertMsg.run(
      4,
      'Victoria Sterling',
      'Church Administrator',
      9,
      'Grace Adeyemi',
      'Direct',
      '',
      'Women Ministry Retreat Room Assignment',
      'Hi Grace, Fellowship Hall and Chapel B are both reserved for your Saturday 10:00 AM leadership brunch.',
      0
    );
    insertMsg.run(
      8,
      'Caleb Bennett',
      'Department Leader',
      null,
      'Youth Department',
      'Department',
      'Youth Department',
      'Friday Youth Night Setup Volunteers',
      'Team, please arrive by 5:15 PM this Friday to assist with acoustic soundcheck and welcome tables.',
      1
    );
  }

  const notifCount = (db.prepare('SELECT COUNT(*) as c FROM notifications').get() as { c: number }).c;
  if (notifCount === 0) {
    const insertNotif = db.prepare(
      `INSERT INTO notifications (user_id, title, message, type, link_page, is_read, email_dispatched)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    );
    insertNotif.run(null, 'Convocation Registration Open', 'Register now for the 2026 Kingdom Leadership & Renewal Convocation (Nov 27–29).', 'Conference', 'conferences', 0, 1);
    insertNotif.run(null, 'Sunday Celebration Services', 'Join us this Sunday at 9:00 AM and 11:00 AM in the Main Sanctuary or online livestream.', 'Service', 'events', 0, 1);
    insertNotif.run(null, 'Winter Food & Coat Drive', 'Welfare Department drop-off bins are open in the atrium through Nov 24.', 'Announcement', 'announcements', 0, 1);
    insertNotif.run(4, 'Church Council Meeting Reminder', 'Monthly Church Council convenes Thursday Nov 19 at 6:30 PM in Suite 201.', 'Meeting', 'meetings', 0, 1);
  }

  const prayerCount = (db.prepare('SELECT COUNT(*) as c FROM prayer_requests').get() as { c: number }).c;
  if (prayerCount === 0) {
    const insertPrayer = db.prepare(
      `INSERT INTO prayer_requests (user_id, requester_name, category, title, details, is_confidential, preferred_date, status, pastor_response)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    insertPrayer.run(
      9,
      'Grace Adeyemi',
      'Testimony',
      'Gratitude for Complete Medical Clearance',
      'Praise God! My mother received a clear bill of health after three months of treatment. Thank you to the Prayer Department and Welfare team for standing with us.',
      0,
      '',
      'Answered',
      'We rejoice with your entire family! May the Lord continue to strengthen her.'
    );
    insertPrayer.run(
      12,
      'Joseph Vance',
      'Prayer Request',
      'Strength During Upcoming Work Relocation',
      'Praying for wisdom and smooth school transition for our two children as we settle into our new neighborhood.',
      0,
      '',
      'Praying',
      'Lifting your household up in Wednesday corporate prayer.'
    );
    insertPrayer.run(
      10,
      'David Morales',
      'Counselling Request',
      'Pre-Marital Pastoral Counselling Session',
      'My fiancée and I would like to schedule our first pastoral counselling consultation with Pastor Samuel or Rev. Miriam.',
      1,
      '2026-11-24',
      'Scheduled',
      'Confirmed for Tuesday Nov 24 at 4:30 PM in Pastoral Study 2.'
    );
  }

  const visitorCount = (db.prepare('SELECT COUNT(*) as c FROM visitors').get() as { c: number }).c;
  if (visitorCount === 0) {
    db.prepare(
      `INSERT INTO visitors (full_name, email, phone, visit_date, service_attended, invited_by, prayer_need, follow_up_status, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?),
              (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      'Olivia Kensington',
      'olivia.k@example.com',
      '+1 (555) 334-1290',
      '2026-11-08',
      'Sunday 9:00 AM Service',
      'Grace Adeyemi',
      'Looking for a welcoming women’s Bible study.',
      'Contacted',
      'Welcomed by Evangelism team; invited to Nov 22 luncheon.'
      ,
      'Marcus Chen',
      'marcus.chen@example.com',
      '+1 (555) 812-4501',
      '2026-11-08',
      'Sunday 11:00 AM Service',
      'Online Livestream',
      'Peace for new career transition.',
      'New',
      'Submitted digital visitor card after service.'
    );
  }

  const attCount = (db.prepare('SELECT COUNT(*) as c FROM attendance_records').get() as { c: number }).c;
  if (attCount === 0) {
    const insertAtt = db.prepare(
      `INSERT INTO attendance_records (service_date, service_name, men_count, women_count, youth_count, children_count, visitors_count, total_count, recorded_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    insertAtt.run('2026-10-18', 'Sunday Celebration Service', 185, 240, 112, 94, 18, 649, 'Victoria Sterling');
    insertAtt.run('2026-10-25', 'Sunday Celebration Service', 192, 248, 120, 98, 22, 680, 'Victoria Sterling');
    insertAtt.run('2026-11-01', 'First Sunday Communion Service', 210, 265, 134, 105, 27, 741, 'Victoria Sterling');
    insertAtt.run('2026-11-08', 'Sunday Celebration Service', 198, 254, 128, 102, 24, 706, 'Victoria Sterling');
  }

  const logCount = (db.prepare('SELECT COUNT(*) as c FROM system_logs').get() as { c: number }).c;
  if (logCount === 0) {
    db.prepare(
      `INSERT INTO system_logs (user_id, user_name, user_role, action, module, details)
       VALUES (1, 'Dr. Emmanuel Mensah', 'Super Administrator', 'SYSTEM_INITIALIZED', 'System', 'CHURCH CONNECT production database seeded and verified.')`
    ).run();
  }
}

export default db;
