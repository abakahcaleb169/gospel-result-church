import React, { useEffect, useState } from 'react';
import {
  BarChart3,
  Bell,
  Briefcase,
  Building2,
  CalendarDays,
  DollarSign,
  FileText,
  HeartHandshake,
  LayoutDashboard,
  LogOut,
  Megaphone,
  Menu,
  MessageSquare,
  Moon,
  Search,
  Settings as SettingsIcon,
  ShieldCheck,
  Sparkles,
  Sun,
  Users,
  Video,
  X,
} from 'lucide-react';
import { apiFetch, getStoredToken, setStoredToken } from './lib/api';
import { LoadingScreen, ResilientImage, ToastBanner } from './components/ui/ChurchUI';
import AuthPortal from './pages/AuthPortal';
import DashboardPage from './pages/DashboardPage';
import PastorPortalPage from './pages/PastorPortalPage';
import AnnouncementsPage from './pages/AnnouncementsPage';
import MembersPage from './pages/MembersPage';
import WelfarePage from './pages/WelfarePage';
import ConferencesPage from './pages/ConferencesPage';
import MeetingsPage from './pages/MeetingsPage';
import EventsPage from './pages/EventsPage';
import DepartmentsPage from './pages/DepartmentsPage';
import FinancePage from './pages/FinancePage';
import AdminPortalPage from './pages/AdminPortalPage';
import {
  DocumentsPage,
  MessagesPage,
  NotificationsPage,
  PrayerRequestsPage,
  ReportsPage,
  SettingsPage,
} from './pages/OperationsPages';
import {
  ROLE_NAV_ACCESS,
  type AppSettings,
  type NavSectionId,
  type NotificationItem,
  type UserAccount,
} from './types';

const NAV_ITEMS: Array<{
  id: NavSectionId;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}> = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'pastor-portal', label: "Pastor's Portal", icon: Sparkles },
  { id: 'announcements', label: 'Announcements', icon: Megaphone },
  { id: 'members', label: 'Church Members', icon: Users },
  { id: 'welfare', label: 'Welfare Management', icon: HeartHandshake },
  { id: 'conferences', label: 'Conferences', icon: Video },
  { id: 'meetings', label: 'Meetings', icon: Briefcase },
  { id: 'events', label: 'Church Events', icon: CalendarDays },
  { id: 'departments', label: 'Departments', icon: Building2 },
  { id: 'finance', label: 'Finance', icon: DollarSign },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'documents', label: 'Documents', icon: FileText },
  { id: 'messages', label: 'Messages', icon: MessageSquare },
  { id: 'prayer', label: 'Prayer Requests', icon: HeartHandshake },
  { id: 'reports', label: 'Reports', icon: BarChart3 },
  { id: 'settings', label: 'Settings', icon: SettingsIcon },
  { id: 'admin', label: 'Admin Portal', icon: ShieldCheck },
];

const DEFAULT_SETTINGS: AppSettings = {
  id: 1,
  app_name: 'GOSPEL RESULTS CHURCH GHANA',
  tagline: 'Connecting Members, Strengthening Faith, Building Community.',
  church_name: 'GOSPEL RESULTS CHURCH GHANA',
  logo_url: '/assets/aistudio/IMG_0954_b4f1f733.jpeg',
  primary_color: '#4C1D95',
  accent_color: '#B48327',
  navy_color: '#0F1E3D',
  theme_mode: 'light',
  dark_mode_enabled: true,
  allow_registration: true,
  require_verification: false,
  email_notifications_enabled: true,
  contact_email: 'office@gracecovenant.org',
  contact_phone: '+1 (555) 234-8910',
  address: '450 Sanctuary Boulevard, Royal Heights, NY 10024',
  about_history: '',
  live_stream_url: '',
  daily_verse_text: '',
  daily_verse_ref: '',
  social_links: { facebook: '', youtube: '', instagram: '', website: '' },
  gallery_images: [],
};

export default function App() {
  const [booting, setBooting] = useState(true);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [user, setUser] = useState<UserAccount | null>(null);
  const [activeSection, setActiveSection] = useState<NavSectionId>('dashboard');
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Global Search
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<
    Array<{ id: number; title: string; subtitle: string; module: NavSectionId; type: string }>
  >([]);

  function notify(type: 'success' | 'error', message: string) {
    setToast({ type, message });
    setTimeout(() => {
      setToast((prev) => (prev?.message === message ? null : prev));
    }, 4500);
  }

  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) root.classList.add('dark');
    else root.classList.remove('dark');
  }, [darkMode]);

  useEffect(() => {
    async function bootstrap() {
      try {
        const pubSettings = await apiFetch<AppSettings>('/api/public/settings');
        setSettings(pubSettings);
        const savedTheme = localStorage.getItem('church_connect_theme');
        if (savedTheme) {
          setDarkMode(savedTheme === 'dark');
        } else {
          setDarkMode(pubSettings.theme_mode === 'dark');
        }

        if (getStoredToken()) {
          const me = await apiFetch<UserAccount>('/api/auth/me');
          setUser(me);
        }
      } catch {
        setStoredToken(null);
        setUser(null);
      } finally {
        setTimeout(() => setBooting(false), 350);
      }
    }
    bootstrap();
  }, []);

  async function refreshUnread() {
    if (!user) return;
    try {
      const list = await apiFetch<NotificationItem[]>('/api/notifications');
      setUnreadCount(list.filter((n) => !n.is_read).length);
    } catch {
      // Ignore transient errors
    }
  }

  useEffect(() => {
    refreshUnread();
  }, [user, activeSection]);

  useEffect(() => {
    if (!user || !searchQuery.trim()) {
      setSearchResults([]);
      return;
    }
    const timer = setTimeout(async () => {
      try {
        const res = await apiFetch<{
          results: Array<{
            id: number;
            title: string;
            subtitle: string;
            module: NavSectionId;
            type: string;
          }>;
        }>(`/api/search?q=${encodeURIComponent(searchQuery.trim())}`);
        setSearchResults(res.results);
      } catch {
        setSearchResults([]);
      }
    }, 220);
    return () => clearTimeout(timer);
  }, [searchQuery, user]);

  function toggleDarkMode() {
    const next = !darkMode;
    setDarkMode(next);
    localStorage.setItem('church_connect_theme', next ? 'dark' : 'light');
  }

  function handleLogout() {
    setStoredToken(null);
    setUser(null);
    setActiveSection('dashboard');
    notify('success', 'You have signed out securely.');
  }

  if (booting) {
    return (
      <LoadingScreen
        appName={settings.app_name}
        tagline={settings.tagline}
        logoUrl={settings.logo_url}
      />
    );
  }

  if (!user) {
    return (
      <>
        <AuthPortal
          settings={settings}
          onAuthenticated={(u) => {
            setUser(u);
            setActiveSection('dashboard');
          }}
          onNotify={notify}
        />
        <ToastBanner toast={toast} onDismiss={() => setToast(null)} />
      </>
    );
  }

  const allowedSections = ROLE_NAV_ACCESS[user.role] || ROLE_NAV_ACCESS['Church Member'];
  const visibleNav = NAV_ITEMS.filter((item) => allowedSections.includes(item.id));
  const currentNavLabel = NAV_ITEMS.find((n) => n.id === activeSection)?.label || 'Dashboard';

  function navigateTo(section: NavSectionId) {
    if (allowedSections.includes(section)) {
      setActiveSection(section);
      setMobileMenuOpen(false);
      setSearchQuery('');
      setSearchResults([]);
    } else {
      notify('error', 'Your current role does not have access to that section.');
    }
  }

  return (
    <div className="min-h-screen flex bg-slate-50 dark:bg-[#080f1e] text-slate-900 dark:text-slate-100">
      {/* Mobile Sidebar Backdrop */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-950/60 lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Navigation Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-[#0f1e3d] text-slate-100 border-r border-slate-800 flex flex-col transition-transform duration-200 lg:static lg:translate-x-0 ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="h-16 px-4 flex items-center justify-between border-b border-white/10 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-full overflow-hidden border border-[#d4af37]/60 bg-[#080f1e] shrink-0">
              <ResilientImage
                src={settings.logo_url}
                alt={settings.app_name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="min-w-0">
              <div className="font-display text-sm font-bold tracking-tight text-white truncate">
                {settings.app_name}
              </div>
              <div className="text-[11px] text-[#e5c158] truncate">{settings.church_name}</div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setMobileMenuOpen(false)}
            className="lg:hidden p-1.5 text-slate-300 hover:text-white"
            aria-label="Close navigation menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {visibleNav.map((item) => {
            const Icon = item.icon;
            const active = activeSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => navigateTo(item.id)}
                className={`w-full flex items-center justify-between gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-[#4c1d95] text-white'
                    : 'text-slate-300 hover:bg-white/8 hover:text-white'
                }`}
              >
                <span className="flex items-center gap-2.5 truncate">
                  <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-[#e5c158]' : 'text-slate-400'}`} />
                  <span className="truncate">{item.label}</span>
                </span>
                {item.id === 'notifications' && unreadCount > 0 && (
                  <span className="font-mono text-[11px] font-semibold text-[#e5c158]">
                    {unreadCount}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-white/10 space-y-2 shrink-0">
          <div className="px-2 py-1.5 flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full overflow-hidden bg-white/10 flex items-center justify-center text-xs font-semibold shrink-0">
              {user.avatar_url ? (
                <ResilientImage
                  src={user.avatar_url}
                  alt={user.full_name}
                  className="w-full h-full object-cover"
                />
              ) : (
                user.full_name
                  .split(' ')
                  .map((n) => n[0])
                  .slice(0, 2)
                  .join('')
              )}
            </div>
            <div className="min-w-0">
              <div className="text-xs font-medium text-white truncate">{user.full_name}</div>
              <div className="text-[11px] text-slate-400 truncate">{user.role}</div>
            </div>
          </div>
          <button
            type="button"
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium rounded-lg border border-white/15 text-slate-200 hover:bg-white/10 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Workspace Header */}
        <header className="h-16 px-4 sm:px-8 bg-white dark:bg-[#111d36] border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4 sticky top-0 z-30">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
              aria-label="Open navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-xs sm:text-sm whitespace-nowrap truncate">
              <span className="text-slate-500 dark:text-slate-400 hidden sm:inline">
                {settings.church_name}
              </span>
              <span className="text-slate-400 hidden sm:inline">/</span>
              <span className="font-semibold text-[#0f1e3d] dark:text-white">
                {currentNavLabel}
              </span>
            </div>
          </div>

          {/* Global Cross-App Search */}
          <div className="relative flex-1 max-w-md hidden md:block">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search members, announcements, events, documents..."
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#080f1e] text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#4c1d95]"
            />
            {searchResults.length > 0 && (
              <div className="absolute left-0 right-0 mt-1.5 bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-700 rounded-xl shadow-xl divide-y divide-slate-100 dark:divide-slate-800 max-h-72 overflow-y-auto z-40">
                {searchResults.map((r, idx) => (
                  <button
                    key={`${r.type}-${r.id}-${idx}`}
                    type="button"
                    onClick={() => navigateTo(r.module)}
                    className="w-full text-left px-4 py-2.5 hover:bg-slate-50 dark:hover:bg-slate-800/60 flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-medium text-[#0f1e3d] dark:text-white truncate">
                        {r.title}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">{r.subtitle}</div>
                    </div>
                    <span className="text-[11px] font-medium text-[#4c1d95] dark:text-purple-300 shrink-0">
                      {r.type}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right Header Utilities */}
          <div className="flex items-center gap-2 shrink-0">
            {settings.dark_mode_enabled && (
              <button
                type="button"
                onClick={toggleDarkMode}
                className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                aria-label="Toggle light/dark mode"
                title={darkMode ? 'Light mode' : 'Dark mode'}
              >
                {darkMode ? <Sun className="w-4 h-4 text-[#e5c158]" /> : <Moon className="w-4 h-4" />}
              </button>
            )}
            <button
              type="button"
              onClick={() => navigateTo('notifications')}
              className="relative p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 px-1.5 min-w-[18px] h-[18px] rounded-full bg-[#4c1d95] text-white font-mono text-[10px] font-semibold flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </button>
          </div>
        </header>

        {/* Active Module Viewport */}
        <main className="flex-1 p-4 sm:p-8 max-w-7xl w-full mx-auto">
          {activeSection === 'dashboard' && (
            <DashboardPage
              user={user}
              settings={settings}
              onNavigate={navigateTo}
              onNotify={notify}
            />
          )}
          {activeSection === 'pastor-portal' && (
            <PastorPortalPage user={user} onNavigate={navigateTo} onNotify={notify} />
          )}
          {activeSection === 'announcements' && (
            <AnnouncementsPage user={user} onNotify={notify} />
          )}
          {activeSection === 'members' && <MembersPage user={user} onNotify={notify} />}
          {activeSection === 'welfare' && <WelfarePage user={user} onNotify={notify} />}
          {activeSection === 'conferences' && (
            <ConferencesPage user={user} onNotify={notify} />
          )}
          {activeSection === 'meetings' && <MeetingsPage user={user} onNotify={notify} />}
          {activeSection === 'events' && (
            <EventsPage user={user} settings={settings} onNotify={notify} />
          )}
          {activeSection === 'departments' && (
            <DepartmentsPage user={user} onNotify={notify} />
          )}
          {activeSection === 'finance' && <FinancePage user={user} onNotify={notify} />}
          {activeSection === 'notifications' && (
            <NotificationsPage
              user={user}
              onNavigate={navigateTo}
              onNotify={notify}
              onRefreshUnread={refreshUnread}
            />
          )}
          {activeSection === 'documents' && <DocumentsPage user={user} onNotify={notify} />}
          {activeSection === 'messages' && <MessagesPage user={user} onNotify={notify} />}
          {activeSection === 'prayer' && <PrayerRequestsPage user={user} onNotify={notify} />}
          {activeSection === 'reports' && <ReportsPage onNotify={notify} />}
          {activeSection === 'settings' && (
            <SettingsPage
              user={user}
              darkMode={darkMode}
              onToggleDarkMode={toggleDarkMode}
              onUserUpdated={setUser}
              onNotify={notify}
            />
          )}
          {activeSection === 'admin' && (
            <AdminPortalPage
              user={user}
              settings={settings}
              onSettingsUpdated={(updated) => {
                setSettings(updated);
                setDarkMode(updated.theme_mode === 'dark');
              }}
              onNavigate={navigateTo}
              onNotify={notify}
            />
          )}
        </main>
      </div>

      <ToastBanner toast={toast} onDismiss={() => setToast(null)} />
    </div>
  );
}
