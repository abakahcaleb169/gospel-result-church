import React, { useEffect, useState } from 'react';
import { Send, Users } from 'lucide-react';
import { apiFetch, formatCurrency, formatShortDate } from '../lib/api';
import { ResilientImage, SectionHeader, StatCard, StatusTag } from '../components/ui/ChurchUI';
import type {
  Announcement,
  Conference,
  Department,
  Meeting,
  NavSectionId,
  PrayerRequest,
  UserAccount,
  WelfareCase,
} from '../types';

export default function PastorPortalPage({
  user,
  onNavigate,
  onNotify,
}: {
  user: UserAccount;
  onNavigate: (section: NavSectionId) => void;
  onNotify: (type: 'success' | 'error', message: string) => void;
}) {
  const [members, setMembers] = useState<UserAccount[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [conferences, setConferences] = useState<Conference[]>([]);
  const [welfare, setWelfare] = useState<WelfareCase[]>([]);
  const [prayers, setPrayers] = useState<PrayerRequest[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);

  const [pastoralTitle, setPastoralTitle] = useState('');
  const [pastoralBody, setPastoralBody] = useState('');
  const [leaderSubject, setLeaderSubject] = useState('');
  const [leaderBody, setLeaderBody] = useState('');
  const [busy, setBusy] = useState(false);

  async function loadAll() {
    try {
      const [m, d, mt, cf, wf, pr, an] = await Promise.all([
        apiFetch<UserAccount[]>('/api/members'),
        apiFetch<Department[]>('/api/departments'),
        apiFetch<Meeting[]>('/api/meetings'),
        apiFetch<Conference[]>('/api/conferences'),
        apiFetch<WelfareCase[]>('/api/welfare'),
        apiFetch<PrayerRequest[]>('/api/prayers'),
        apiFetch<Announcement[]>('/api/announcements'),
      ]);
      setMembers(m);
      setDepartments(d);
      setMeetings(mt);
      setConferences(cf);
      setWelfare(wf);
      setPrayers(pr);
      setAnnouncements(an);
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  useEffect(() => {
    loadAll();
  }, []);

  async function publishPastoralMessage(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await apiFetch('/api/announcements', {
        method: 'POST',
        body: JSON.stringify({
          title: pastoralTitle,
          description: pastoralBody,
          category: 'Pastoral Message',
          is_important: true,
          is_pinned: true,
          push_notification: true,
        }),
      });
      setPastoralTitle('');
      setPastoralBody('');
      onNotify('success', 'Pastoral message published and pushed to congregation.');
      loadAll();
    } catch (err) {
      onNotify('error', (err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function messageLeaders(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await apiFetch('/api/messages', {
        method: 'POST',
        body: JSON.stringify({
          channel: 'Leadership',
          department: 'Leadership',
          recipient_name: 'All Church Leaders & Department Heads',
          subject: leaderSubject,
          body: leaderBody,
        }),
      });
      setLeaderSubject('');
      setLeaderBody('');
      onNotify('success', 'Message dispatched to all church leadership.');
    } catch (err) {
      onNotify('error', (err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  const activeMembers = members.filter((m) => m.status === 'Active').length;
  const totalWelfareApproved = welfare.reduce((sum, w) => sum + Number(w.amount_approved || 0), 0);
  const pendingCounselling = prayers.filter((p) => p.category === 'Counselling Request').length;

  return (
    <div className="space-y-8">
      <SectionHeader
        title="Pastor's Executive Portal"
        description="Shepherding oversight across membership health, pastoral communications, ministries, conferences, and confidential welfare care."
        actions={
          <button
            type="button"
            onClick={() => onNavigate('reports')}
            className="px-4 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
          >
            Ministry Reports
          </button>
        }
      />

      {/* Pastoral Header Card */}
      <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-[#b48327] shrink-0">
            <ResilientImage
              src={user.avatar_url || '/src/assets/images/pastor_portrait_1794690388392.jpg'}
              alt={user.full_name}
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <div className="text-xs font-medium text-[#9a6b16] dark:text-[#e5c158]">
              {user.role}
            </div>
            <h2 className="font-display text-xl font-semibold text-[#0f1e3d] dark:text-white">
              {user.full_name}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {user.email} · {user.phone}
            </p>
          </div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6 text-right">
          <div>
            <div className="text-xs text-slate-500 dark:text-slate-400">Active Flock</div>
            <div className="font-mono text-xl font-semibold text-[#0f1e3d] dark:text-white tabular-nums">
              {activeMembers}
            </div>
          </div>
          <div>
            <div className="text-xs text-slate-500 dark:text-slate-400">Ministries</div>
            <div className="font-mono text-xl font-semibold text-[#4c1d95] dark:text-purple-300 tabular-nums">
              {departments.length}
            </div>
          </div>
          <div>
            <div className="text-xs text-slate-500 dark:text-slate-400">Counselling</div>
            <div className="font-mono text-xl font-semibold text-[#9a6b16] dark:text-[#e5c158] tabular-nums">
              {pendingCounselling}
            </div>
          </div>
          <div>
            <div className="text-xs text-slate-500 dark:text-slate-400">Welfare Aid</div>
            <div className="font-mono text-xl font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums">
              {formatCurrency(totalWelfareApproved)}
            </div>
          </div>
        </div>
      </div>

      {/* Pastoral Actions: Publish Pastoral Message & Message Church Leaders */}
      <div className="grid lg:grid-cols-2 gap-6">
        <form
          onSubmit={publishPastoralMessage}
          className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4"
        >
          <div>
            <h3 className="font-display text-lg font-semibold text-[#0f1e3d] dark:text-white">
              Publish Pastoral Message
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Pinned directly to every member’s dashboard with instant notification.
            </p>
          </div>
          <input
            type="text"
            required
            value={pastoralTitle}
            onChange={(e) => setPastoralTitle(e.target.value)}
            placeholder="Pastoral message title (e.g. Shepherd's Note for November)"
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
          />
          <textarea
            rows={4}
            required
            value={pastoralBody}
            onChange={(e) => setPastoralBody(e.target.value)}
            placeholder="Write your devotional encouragement or pastoral directive..."
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
          />
          <button
            type="submit"
            disabled={busy}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
          >
            <Send className="w-3.5 h-3.5" />
            Publish Pastoral Message
          </button>
        </form>

        <form
          onSubmit={messageLeaders}
          className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4"
        >
          <div>
            <h3 className="font-display text-lg font-semibold text-[#0f1e3d] dark:text-white">
              Direct Brief to Church Leaders
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Send private leadership communication to department heads, officers, and elders.
            </p>
          </div>
          <input
            type="text"
            required
            value={leaderSubject}
            onChange={(e) => setLeaderSubject(e.target.value)}
            placeholder="Leadership brief subject"
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
          />
          <textarea
            rows={4}
            required
            value={leaderBody}
            onChange={(e) => setLeaderBody(e.target.value)}
            placeholder="Share strategic guidance, prayer focus, or meeting preparation..."
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
          />
          <button
            type="submit"
            disabled={busy}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg bg-[#0f1e3d] text-white hover:bg-[#1a2f5c]"
          >
            <Users className="w-3.5 h-3.5" />
            Send to Leadership Council
          </button>
        </form>
      </div>

      {/* Monitoring Grid: Departments, Meeting Reports, Conferences, Welfare Summaries */}
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
            <h3 className="font-display text-lg font-semibold text-[#0f1e3d] dark:text-white">
              Departmental Ministry Monitor
            </h3>
            <button
              type="button"
              onClick={() => onNavigate('departments')}
              className="text-xs font-medium text-[#4c1d95] dark:text-purple-300 hover:underline"
            >
              Manage
            </button>
          </div>
          <div className="mt-3 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
                  <th className="py-2 font-medium">Department</th>
                  <th className="py-2 font-medium">Leader</th>
                  <th className="py-2 font-medium text-right">Activities</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {departments.slice(0, 6).map((d) => (
                  <tr key={d.id}>
                    <td className="py-2.5 font-medium text-[#0f1e3d] dark:text-white">{d.name}</td>
                    <td className="py-2.5 text-slate-600 dark:text-slate-300">{d.leader_name}</td>
                    <td className="py-2.5 text-right font-mono tabular-nums text-slate-700 dark:text-slate-200">
                      {d.activities_count}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
            <h3 className="font-display text-lg font-semibold text-[#0f1e3d] dark:text-white">
              Authorized Welfare & Meeting Summaries
            </h3>
            <button
              type="button"
              onClick={() => onNavigate('welfare')}
              className="text-xs font-medium text-[#4c1d95] dark:text-purple-300 hover:underline"
            >
              Welfare Desk
            </button>
          </div>
          <div className="mt-3 space-y-3">
            {welfare.slice(0, 3).map((w) => (
              <div
                key={w.id}
                className="flex items-center justify-between gap-3 py-2 border-b border-slate-100 dark:border-slate-800 last:border-b-0"
              >
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-[#0f1e3d] dark:text-white truncate">
                    {w.case_code} · {w.member_name}
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">
                    {w.category} · Officer: {w.assigned_officer_name}
                  </div>
                </div>
                <StatusTag status={w.status} />
              </div>
            ))}
          </div>
          <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800">
            <div className="text-xs font-semibold text-slate-700 dark:text-slate-200 mb-2">
              Recent Meeting Reports & Schedules
            </div>
            {meetings.slice(0, 2).map((m) => (
              <div key={m.id} className="text-xs text-slate-600 dark:text-slate-300 py-1">
                <span className="font-medium text-[#0f1e3d] dark:text-white">{m.title}</span> —{' '}
                {m.minutes ? m.minutes : `Scheduled ${formatShortDate(m.meeting_date)}`}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Conference Schedules & Latest Announcements */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Conferences Planned"
          value={conferences.length}
          subtext={conferences[0]?.title || 'None'}
          accent="gold"
        />
        <StatCard
          label="Active Announcements"
          value={announcements.length}
          subtext="Published to congregation"
          accent="purple"
        />
        <StatCard
          label="Welfare Cases"
          value={welfare.length}
          subtext="Confidential pastoral care"
          accent="emerald"
        />
        <StatCard
          label="Prayer & Counselling"
          value={prayers.length}
          subtext="Intercessory ministry"
          accent="navy"
        />
      </div>
    </div>
  );
}
