import React, { useEffect, useState } from 'react';
import {
  Check,
  Download,
  Lock,
  Plus,
  Search,
  ShieldAlert,
  X,
} from 'lucide-react';
import {
  apiFetch,
  exportToExcel,
  exportToPdf,
  formatCurrency,
  formatShortDate,
} from '../lib/api';
import { EmptyState, Modal, SectionHeader, StatCard, StatusTag } from '../components/ui/ChurchUI';
import type { UserAccount, WelfareCase } from '../types';

const WELFARE_CATEGORIES = [
  'Emergency Assistance',
  'Hospital Visit',
  'Bereavement Support',
  'Financial Assistance',
  'Food & Material Donation',
  'General Welfare',
] as const;

export default function WelfarePage({
  user,
  onNotify,
}: {
  user: UserAccount;
  onNotify: (type: 'success' | 'error', message: string) => void;
}) {
  const [cases, setCases] = useState<WelfareCase[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  const [createOpen, setCreateOpen] = useState(false);
  const [selectedCase, setSelectedCase] = useState<WelfareCase | null>(null);

  const [createForm, setCreateForm] = useState({
    member_name: '',
    category: 'Emergency Assistance',
    urgency: 'Medium',
    amount_requested: '0',
    materials_provided: '',
    description: '',
    confidential_notes: '',
    visit_date: '',
    assigned_officer_name: 'Deaconess Martha Appiah',
  });

  const [updateForm, setUpdateForm] = useState({
    status: 'Pending',
    amount_approved: '0',
    materials_provided: '',
    assigned_officer_name: '',
    confidential_notes: '',
    assistance_notes: '',
    visit_date: '',
  });

  const canManage = [
    'Super Administrator',
    'Church Administrator',
    'Senior Pastor',
    'Assistant Pastor',
    'Welfare Officer',
  ].includes(user.role);

  async function loadCases() {
    try {
      const res = await apiFetch<WelfareCase[]>('/api/welfare');
      setCases(res);
    } catch (err) {
      onNotify('error', (err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadCases();
  }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    try {
      await apiFetch('/api/welfare', {
        method: 'POST',
        body: JSON.stringify(createForm),
      });
      onNotify('success', 'Welfare case recorded and assigned.');
      setCreateOpen(false);
      setCreateForm({
        member_name: '',
        category: 'Emergency Assistance',
        urgency: 'Medium',
        amount_requested: '0',
        materials_provided: '',
        description: '',
        confidential_notes: '',
        visit_date: '',
        assigned_officer_name: 'Deaconess Martha Appiah',
      });
      loadCases();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  function openCaseDetail(c: WelfareCase) {
    setSelectedCase(c);
    setUpdateForm({
      status: c.status,
      amount_approved: String(c.amount_approved || 0),
      materials_provided: c.materials_provided || '',
      assigned_officer_name: c.assigned_officer_name || '',
      confidential_notes: c.confidential_notes || '',
      assistance_notes: c.assistance_notes || '',
      visit_date: c.visit_date || '',
    });
  }

  async function handleUpdateCase(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedCase) return;
    try {
      await apiFetch(`/api/welfare/${selectedCase.id}`, {
        method: 'PUT',
        body: JSON.stringify(updateForm),
      });
      onNotify('success', `Updated ${selectedCase.case_code} (${updateForm.status}).`);
      setSelectedCase(null);
      loadCases();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function quickStatus(c: WelfareCase, status: 'Approved' | 'Rejected' | 'Completed') {
    try {
      await apiFetch(`/api/welfare/${c.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          status,
          amount_approved: status === 'Approved' && c.amount_approved === 0 ? c.amount_requested : c.amount_approved,
        }),
      });
      onNotify('success', `${c.case_code} marked as ${status}.`);
      loadCases();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  const filtered = cases.filter((c) => {
    const matchesStatus = statusFilter === 'All' || c.status === statusFilter;
    const q = search.trim().toLowerCase();
    const matchesSearch =
      !q ||
      c.case_code.toLowerCase().includes(q) ||
      c.member_name.toLowerCase().includes(q) ||
      c.category.toLowerCase().includes(q);
    return matchesStatus && matchesSearch;
  });

  const totalDisbursed = cases.reduce((acc, c) => acc + Number(c.amount_approved || 0), 0);
  const activeCount = cases.filter((c) => ['Pending', 'In Progress', 'Approved'].includes(c.status)).length;
  const completedCount = cases.filter((c) => c.status === 'Completed').length;

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Confidential Welfare & Benevolence Desk"
        description="Strictly access-controlled pastoral care for hospital visits, bereavement support, emergency aid, and material donations."
        actions={
          <>
            <button
              type="button"
              onClick={() => {
                exportToExcel(
                  'Church_Connect_Welfare_Report',
                  'Welfare Cases',
                  filtered.map((c) => ({
                    'Case Code': c.case_code,
                    Member: c.member_name,
                    Category: c.category,
                    Urgency: c.urgency,
                    Requested: c.amount_requested,
                    Approved: c.amount_approved,
                    Materials: c.materials_provided,
                    Officer: c.assigned_officer_name,
                    Status: c.status,
                  }))
                );
                onNotify('success', 'Welfare report downloaded as Excel.');
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              Excel Report
            </button>
            <button
              type="button"
              onClick={() => {
                exportToPdf(
                  'Church_Connect_Welfare_Report',
                  'CHURCH CONNECT — Confidential Welfare Report',
                  `Generated ${new Date().toLocaleDateString()} · Authorized Personnel Only`,
                  ['Case Code', 'Member', 'Category', 'Urgency', 'Approved ($)', 'Officer', 'Status'],
                  filtered.map((c) => [
                    c.case_code,
                    c.member_name,
                    c.category,
                    c.urgency,
                    c.amount_approved.toFixed(2),
                    c.assigned_officer_name,
                    c.status,
                  ])
                );
                onNotify('success', 'Welfare report downloaded as PDF.');
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              PDF Report
            </button>
            <button
              type="button"
              onClick={() => setCreateOpen(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675] whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              Log Welfare Case
            </button>
          </>
        }
      />

      {/* Confidential Access Notice */}
      <div className="rounded-xl border border-[#b48327]/40 bg-amber-50/70 dark:bg-amber-950/20 px-4 py-3 flex items-center gap-3 text-xs text-amber-900 dark:text-amber-200">
        <Lock className="w-4 h-4 text-[#b48327] shrink-0" />
        <span>
          <strong>Confidential Care Workspace:</strong> Sensitive case notes and benevolence disbursements are visible exclusively to authorized Welfare Officers, Pastors, and Administrators.
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <StatCard label="Total Recorded Cases" value={cases.length} accent="navy" />
        <StatCard label="Active / Open Care" value={activeCount} accent="purple" />
        <StatCard label="Total Financial Aid" value={formatCurrency(totalDisbursed)} accent="gold" />
        <StatCard label="Cases Completed" value={completedCount} accent="emerald" />
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-lg">
          {['All', 'Pending', 'In Progress', 'Approved', 'Completed', 'Rejected'].map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                statusFilter === st
                  ? 'bg-white dark:bg-[#1a2947] text-[#0f1e3d] dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search case code, member, category..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111d36] text-slate-900 dark:text-white"
          />
        </div>
      </div>

      {loading ? (
        <div className="h-48 rounded-xl bg-slate-200/60 dark:bg-slate-800/60 animate-pulse" />
      ) : filtered.length === 0 ? (
        <EmptyState
          title="No welfare cases found"
          description="Log a member care request, hospital visit, bereavement case, or food/material support entry."
          actionLabel="Log Welfare Case"
          onAction={() => setCreateOpen(true)}
        />
      ) : (
        <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-[#080f1e] border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
                <tr>
                  <th className="py-3 px-4 font-medium">Case ID</th>
                  <th className="py-3 px-4 font-medium">Member</th>
                  <th className="py-3 px-4 font-medium">Category</th>
                  <th className="py-3 px-4 font-medium">Urgency</th>
                  <th className="py-3 px-4 font-medium text-right">Requested</th>
                  <th className="py-3 px-4 font-medium text-right">Approved</th>
                  <th className="py-3 px-4 font-medium">Assigned Officer</th>
                  <th className="py-3 px-4 font-medium">Status</th>
                  {canManage && <th className="py-3 px-4 font-medium text-right">Actions</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filtered.map((c) => (
                  <tr
                    key={c.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3 px-4 font-mono font-medium text-[#4c1d95] dark:text-purple-300">
                      <button
                        type="button"
                        onClick={() => openCaseDetail(c)}
                        className="hover:underline"
                      >
                        {c.case_code}
                      </button>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-[#0f1e3d] dark:text-white">
                        {c.member_name}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">
                        {c.description}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-700 dark:text-slate-200">{c.category}</td>
                    <td className="py-3 px-4">
                      <StatusTag status={c.urgency} />
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700 dark:text-slate-200">
                      {formatCurrency(c.amount_requested)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums font-medium text-emerald-700 dark:text-emerald-400">
                      {formatCurrency(c.amount_approved)}
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-300">
                      {c.assigned_officer_name}
                    </td>
                    <td className="py-3 px-4">
                      <StatusTag status={c.status} />
                    </td>
                    {canManage && (
                      <td className="py-3 px-4 text-right whitespace-nowrap space-x-1">
                        {c.status === 'Pending' && (
                          <>
                            <button
                              type="button"
                              onClick={() => quickStatus(c, 'Approved')}
                              className="p-1.5 rounded-lg text-emerald-700 hover:bg-emerald-50 dark:text-emerald-400 dark:hover:bg-emerald-950/30"
                              title="Approve request"
                            >
                              <Check className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => quickStatus(c, 'Rejected')}
                              className="p-1.5 rounded-lg text-red-700 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/30"
                              title="Reject request"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </>
                        )}
                        <button
                          type="button"
                          onClick={() => openCaseDetail(c)}
                          className="px-2.5 py-1 text-xs font-medium rounded-md border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          Manage
                        </button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Create Welfare Case Modal */}
      <Modal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        title="Log Welfare & Assistance Case"
        subtitle="Record emergency assistance, hospital visitation, bereavement, or material care."
      >
        <form onSubmit={handleCreate} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Member / Beneficiary Name
              </label>
              <input
                type="text"
                required
                value={createForm.member_name}
                onChange={(e) => setCreateForm({ ...createForm, member_name: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Assistance Category
              </label>
              <select
                value={createForm.category}
                onChange={(e) => setCreateForm({ ...createForm, category: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              >
                {WELFARE_CATEGORIES.map((cat) => (
                  <option key={cat}>{cat}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Urgency Level
              </label>
              <select
                value={createForm.urgency}
                onChange={(e) => setCreateForm({ ...createForm, urgency: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              >
                <option>Low</option>
                <option>Medium</option>
                <option>High</option>
                <option>Critical</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Amount Requested ($)
              </label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={createForm.amount_requested}
                onChange={(e) => setCreateForm({ ...createForm, amount_requested: e.target.value })}
                className="w-full px-3 py-2 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Assigned Welfare Officer
              </label>
              <input
                type="text"
                value={createForm.assigned_officer_name}
                onChange={(e) =>
                  setCreateForm({ ...createForm, assigned_officer_name: e.target.value })
                }
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Scheduled Visit Date
              </label>
              <input
                type="date"
                value={createForm.visit_date}
                onChange={(e) => setCreateForm({ ...createForm, visit_date: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Case Details
            </label>
            <textarea
              rows={3}
              required
              value={createForm.description}
              onChange={(e) => setCreateForm({ ...createForm, description: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Food / Material Items Needed
            </label>
            <input
              type="text"
              value={createForm.materials_provided}
              onChange={(e) => setCreateForm({ ...createForm, materials_provided: e.target.value })}
              placeholder="e.g. Family grocery hamper, winter coats, medical supplies"
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Confidential Pastoral Notes
            </label>
            <textarea
              rows={2}
              value={createForm.confidential_notes}
              onChange={(e) => setCreateForm({ ...createForm, confidential_notes: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setCreateOpen(false)}
              className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
            >
              Submit Welfare Case
            </button>
          </div>
        </form>
      </Modal>

      {/* Case Management & Confidential Detail Modal */}
      <Modal
        open={Boolean(selectedCase)}
        onClose={() => setSelectedCase(null)}
        title={selectedCase ? `${selectedCase.case_code} · ${selectedCase.member_name}` : ''}
        subtitle={
          selectedCase
            ? `${selectedCase.category} · Logged ${formatShortDate(selectedCase.created_at)}`
            : ''
        }
      >
        {selectedCase && (
          <form onSubmit={handleUpdateCase} className="space-y-4">
            <div className="p-3.5 rounded-lg bg-slate-50 dark:bg-[#080f1e] border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300">
              <div className="font-semibold text-[#0f1e3d] dark:text-white mb-1">
                Case Description
              </div>
              <p>{selectedCase.description}</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Case Status
                </label>
                <select
                  disabled={!canManage}
                  value={updateForm.status}
                  onChange={(e) => setUpdateForm({ ...updateForm, status: e.target.value })}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                >
                  <option>Pending</option>
                  <option>In Progress</option>
                  <option>Approved</option>
                  <option>Completed</option>
                  <option>Rejected</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Approved Financial Assistance ($)
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  disabled={!canManage}
                  value={updateForm.amount_approved}
                  onChange={(e) => setUpdateForm({ ...updateForm, amount_approved: e.target.value })}
                  className="w-full px-3 py-2 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Assigned Officer
                </label>
                <input
                  type="text"
                  disabled={!canManage}
                  value={updateForm.assigned_officer_name}
                  onChange={(e) =>
                    setUpdateForm({ ...updateForm, assigned_officer_name: e.target.value })
                  }
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Visit / Follow-up Date
                </label>
                <input
                  type="date"
                  disabled={!canManage}
                  value={updateForm.visit_date}
                  onChange={(e) => setUpdateForm({ ...updateForm, visit_date: e.target.value })}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Food & Material Donations Provided
              </label>
              <input
                type="text"
                disabled={!canManage}
                value={updateForm.materials_provided}
                onChange={(e) =>
                  setUpdateForm({ ...updateForm, materials_provided: e.target.value })
                }
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Assistance Provided Record
              </label>
              <textarea
                rows={2}
                disabled={!canManage}
                value={updateForm.assistance_notes}
                onChange={(e) => setUpdateForm({ ...updateForm, assistance_notes: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="flex items-center gap-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                <ShieldAlert className="w-3.5 h-3.5 text-[#b48327]" />
                Confidential Officer Notes
              </label>
              <textarea
                rows={2}
                disabled={!canManage}
                value={updateForm.confidential_notes}
                onChange={(e) =>
                  setUpdateForm({ ...updateForm, confidential_notes: e.target.value })
                }
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSelectedCase(null)}
                className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300"
              >
                Close
              </button>
              {canManage && (
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
                >
                  Save Case Update
                </button>
              )}
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
}
