import React, { useEffect, useState } from 'react';
import {
  Download,
  Edit3,
  Plus,
  Search,
  Upload,
  UserCheck,
  UserX,
} from 'lucide-react';
import {
  apiFetch,
  exportToExcel,
  exportToPdf,
  formatShortDate,
  readFileAsDataUrl,
} from '../lib/api';
import { Modal, ResilientImage, SectionHeader, StatCard, StatusTag } from '../components/ui/ChurchUI';
import { ALL_ROLES, type UserAccount, type UserRole } from '../types';

const DEPARTMENTS_LIST = [
  'General Congregation',
  'Choir Department',
  'Ushering Department',
  'Youth Department',
  "Men's Ministry",
  "Women's Ministry",
  "Children's Ministry",
  'Evangelism Department',
  'Media Department',
  'Prayer Department',
  'Welfare Department',
];

export default function MembersPage({
  user,
  onNotify,
}: {
  user: UserAccount;
  onNotify: (type: 'success' | 'error', message: string) => void;
}) {
  const [members, setMembers] = useState<UserAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<UserAccount | null>(null);

  const [form, setForm] = useState({
    full_name: '',
    email: '',
    phone: '',
    password: '',
    role: 'Church Member' as UserRole,
    department: 'General Congregation',
    status: 'Active' as 'Active' | 'Inactive' | 'Suspended',
    avatar_url: '',
    date_of_birth: '',
    date_joined: new Date().toISOString().slice(0, 10),
    address: '',
    gender: 'Female',
    marital_status: 'Single',
    occupation: '',
    emergency_contact: '',
  });

  const canManage = [
    'Super Administrator',
    'Church Administrator',
    'Church Secretary',
    'Senior Pastor',
  ].includes(user.role);

  const canAssignRole = ['Super Administrator', 'Church Administrator'].includes(user.role);

  async function loadMembers() {
    try {
      const res = await apiFetch<UserAccount[]>('/api/members');
      setMembers(res);
    } catch (err) {
      onNotify('error', (err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadMembers();
  }, []);

  function openCreate() {
    setEditing(null);
    setForm({
      full_name: '',
      email: '',
      phone: '',
      password: '',
      role: 'Church Member',
      department: 'General Congregation',
      status: 'Active',
      avatar_url: '',
      date_of_birth: '',
      date_joined: new Date().toISOString().slice(0, 10),
      address: '',
      gender: 'Female',
      marital_status: 'Single',
      occupation: '',
      emergency_contact: '',
    });
    setModalOpen(true);
  }

  function openEdit(m: UserAccount) {
    setEditing(m);
    setForm({
      full_name: m.full_name,
      email: m.email || '',
      phone: m.phone || '',
      password: '',
      role: m.role,
      department: m.department || 'General Congregation',
      status: m.status,
      avatar_url: m.avatar_url || '',
      date_of_birth: m.date_of_birth || '',
      date_joined: m.date_joined || '',
      address: m.address || '',
      gender: m.gender || '',
      marital_status: m.marital_status || '',
      occupation: m.occupation || '',
      emergency_contact: m.emergency_contact || '',
    });
    setModalOpen(true);
  }

  async function handleAvatarUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await readFileAsDataUrl(file, 2);
      setForm((prev) => ({ ...prev, avatar_url: dataUrl }));
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    try {
      if (editing) {
        await apiFetch(`/api/members/${editing.id}`, {
          method: 'PUT',
          body: JSON.stringify(form),
        });
        onNotify('success', `Member record updated for ${form.full_name}.`);
      } else {
        await apiFetch('/api/members', {
          method: 'POST',
          body: JSON.stringify(form),
        });
        onNotify('success', `Registered ${form.full_name} into church directory.`);
      }
      setModalOpen(false);
      loadMembers();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function toggleStatus(m: UserAccount) {
    const nextStatus = m.status === 'Active' ? 'Inactive' : 'Active';
    try {
      await apiFetch(`/api/members/${m.id}`, {
        method: 'PUT',
        body: JSON.stringify({ status: nextStatus }),
      });
      onNotify('success', `${m.full_name} marked as ${nextStatus}.`);
      loadMembers();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  const filtered = members.filter((m) => {
    const matchesDept = deptFilter === 'All' || m.department === deptFilter;
    const matchesStatus = statusFilter === 'All' || m.status === statusFilter;
    const q = search.trim().toLowerCase();
    const matchesQuery =
      !q ||
      m.full_name.toLowerCase().includes(q) ||
      (m.member_code || '').toLowerCase().includes(q) ||
      (m.email || '').toLowerCase().includes(q) ||
      (m.department || '').toLowerCase().includes(q);
    return matchesDept && matchesStatus && matchesQuery;
  });

  function handleExportExcel() {
    exportToExcel(
      'Church_Connect_Membership_Registry',
      'Members',
      filtered.map((m) => ({
        'Member ID': m.member_code,
        'Full Name': m.full_name,
        Role: m.role,
        Department: m.department,
        Email: m.email || '—',
        Phone: m.phone || '—',
        Status: m.status,
        'Date Joined': m.date_joined || '—',
      }))
    );
    onNotify('success', 'Membership directory exported to Excel.');
  }

  function handleExportPdf() {
    exportToPdf(
      'Church_Connect_Membership_Registry',
      'CHURCH CONNECT — Membership Directory',
      `Exported ${new Date().toLocaleDateString()} · ${filtered.length} records`,
      ['Member ID', 'Full Name', 'Role', 'Department', 'Email', 'Status'],
      filtered.map((m) => [
        m.member_code,
        m.full_name,
        m.role,
        m.department,
        m.email || '—',
        m.status,
      ])
    );
    onNotify('success', 'Membership directory exported to PDF.');
  }

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Church Membership Directory"
        description="Maintain official congregation profiles, member identification codes, department placements, and membership status."
        actions={
          <>
            <button
              type="button"
              onClick={handleExportExcel}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              Export Excel
            </button>
            <button
              type="button"
              onClick={handleExportPdf}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              Export PDF
            </button>
            {canManage && (
              <button
                type="button"
                onClick={openCreate}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675] whitespace-nowrap"
              >
                <Plus className="w-4 h-4" />
                Register Member
              </button>
            )}
          </>
        }
      />

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <StatCard label="Total Directory" value={members.length} accent="navy" />
        <StatCard
          label="Active Members"
          value={members.filter((m) => m.status === 'Active').length}
          accent="emerald"
        />
        <StatCard
          label="Ministry Leaders"
          value={members.filter((m) => m.role !== 'Church Member').length}
          accent="purple"
        />
        <StatCard
          label="Inactive / Suspended"
          value={members.filter((m) => m.status !== 'Active').length}
          accent="gold"
        />
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by member name, ID (CC-2026-...), email, or department..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
          />
        </div>
        <select
          value={deptFilter}
          onChange={(e) => setDeptFilter(e.target.value)}
          className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
        >
          <option value="All">All Departments</option>
          {DEPARTMENTS_LIST.map((d) => (
            <option key={d} value={d}>
              {d}
            </option>
          ))}
        </select>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
        >
          <option value="All">All Statuses</option>
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
          <option value="Suspended">Suspended</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-[#080f1e] border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
              <tr>
                <th className="py-3 px-4 font-medium">Member</th>
                <th className="py-3 px-4 font-medium">Member ID</th>
                <th className="py-3 px-4 font-medium">Role</th>
                <th className="py-3 px-4 font-medium">Department</th>
                <th className="py-3 px-4 font-medium">Contact</th>
                <th className="py-3 px-4 font-medium">Joined</th>
                <th className="py-3 px-4 font-medium">Status</th>
                {canManage && <th className="py-3 px-4 font-medium text-right">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {loading ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    Loading membership records...
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    No matching members found.
                  </td>
                </tr>
              ) : (
                filtered.map((m) => (
                  <tr
                    key={m.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full overflow-hidden bg-[#4c1d95]/10 text-[#4c1d95] dark:text-purple-300 flex items-center justify-center font-semibold shrink-0">
                          {m.avatar_url ? (
                            <ResilientImage
                              src={m.avatar_url}
                              alt={m.full_name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            m.full_name
                              .split(' ')
                              .map((x) => x[0])
                              .slice(0, 2)
                              .join('')
                          )}
                        </div>
                        <div className="font-medium text-[#0f1e3d] dark:text-white">
                          {m.full_name}
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-slate-600 dark:text-slate-300">
                      {m.member_code}
                    </td>
                    <td className="py-3 px-4 text-slate-700 dark:text-slate-200">{m.role}</td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{m.department}</td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-300">
                      <div>{m.email || '—'}</div>
                      <div className="text-[11px] text-slate-400">{m.phone || ''}</div>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-500 dark:text-slate-400">
                      {formatShortDate(m.date_joined)}
                    </td>
                    <td className="py-3 px-4">
                      <StatusTag status={m.status} />
                    </td>
                    {canManage && (
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => openEdit(m)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-[#4c1d95] hover:bg-slate-100 dark:hover:bg-slate-800"
                          title="Edit member"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => toggleStatus(m)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950/30 ml-1"
                          title={m.status === 'Active' ? 'Deactivate member' : 'Activate member'}
                        >
                          {m.status === 'Active' ? (
                            <UserX className="w-4 h-4" />
                          ) : (
                            <UserCheck className="w-4 h-4" />
                          )}
                        </button>
                      </td>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Register / Edit Member Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? `Edit Member · ${editing.member_code}` : 'Register New Church Member'}
        subtitle="Member profiles are persisted permanently in the congregation database."
      >
        <form onSubmit={handleSave} className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full overflow-hidden border border-slate-300 dark:border-slate-700 bg-slate-100 dark:bg-[#080f1e] shrink-0">
              {form.avatar_url ? (
                <ResilientImage
                  src={form.avatar_url}
                  alt={form.full_name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-xs text-slate-400">
                  Photo
                </div>
              )}
            </div>
            <label className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
              <Upload className="w-3.5 h-3.5" />
              Upload Member Photo
              <input type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} />
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Full Name
              </label>
              <input
                type="text"
                required
                value={form.full_name}
                onChange={(e) => setForm({ ...form, full_name: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Email Address
              </label>
              <input
                type="email"
                required
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Phone Number
              </label>
              <input
                type="tel"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Department
              </label>
              <select
                value={form.department}
                onChange={(e) => setForm({ ...form, department: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              >
                {DEPARTMENTS_LIST.map((d) => (
                  <option key={d}>{d}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Account Role
              </label>
              <select
                disabled={!canAssignRole}
                value={form.role}
                onChange={(e) => setForm({ ...form, role: e.target.value as UserRole })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white disabled:opacity-60"
              >
                {ALL_ROLES.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Membership Status
              </label>
              <select
                value={form.status}
                onChange={(e) =>
                  setForm({ ...form, status: e.target.value as 'Active' | 'Inactive' | 'Suspended' })
                }
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
                <option value="Suspended">Suspended</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Date of Birth
              </label>
              <input
                type="date"
                value={form.date_of_birth}
                onChange={(e) => setForm({ ...form, date_of_birth: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Date Joined
              </label>
              <input
                type="date"
                value={form.date_joined}
                onChange={(e) => setForm({ ...form, date_joined: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Address
              </label>
              <input
                type="text"
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Emergency Contact
              </label>
              <input
                type="text"
                value={form.emergency_contact}
                onChange={(e) => setForm({ ...form, emergency_contact: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {!editing && (
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Initial Password (defaults to ChurchConnect2026! if empty)
              </label>
              <input
                type="password"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
            >
              {editing ? 'Update Member' : 'Register Member'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
