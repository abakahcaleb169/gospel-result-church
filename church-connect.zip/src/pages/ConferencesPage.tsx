import React, { useEffect, useState } from 'react';
import {
  Calendar,
  Check,
  Download,
  MapPin,
  Plus,
  Upload,
  Users,
} from 'lucide-react';
import {
  apiFetch,
  exportToExcel,
  exportToPdf,
  formatCurrency,
  formatShortDate,
  readFileAsDataUrl,
} from '../lib/api';
import { EmptyState, Modal, ResilientImage, SectionHeader, StatusTag } from '../components/ui/ChurchUI';
import type {
  Conference,
  ConferenceRegistration,
  FinancialTransaction,
  UserAccount,
} from '../types';

export default function ConferencesPage({
  user,
  onNotify,
}: {
  user: UserAccount;
  onNotify: (type: 'success' | 'error', message: string) => void;
}) {
  const [conferences, setConferences] = useState<Conference[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Conference | null>(null);
  const [registrations, setRegistrations] = useState<ConferenceRegistration[]>([]);
  const [confFinance, setConfFinance] = useState<FinancialTransaction[]>([]);

  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({
    title: '',
    description: '',
    poster_url: '/src/assets/images/conference_banner_1794690387986.jpg',
    start_date: '',
    end_date: '',
    venue: '',
    theme: '',
    budget: '15000',
    speakers_text: 'Pastor Samuel Osei | Senior Pastor | Kingdom Stewardship',
    programme_text: 'Day 1 | 6:00 PM | Opening Worship & Keynote | Pastor Samuel Osei',
    committees_text: 'Hospitality Committee | Victoria Sterling | Ushering Team',
  });

  const canManage = [
    'Super Administrator',
    'Church Administrator',
    'Senior Pastor',
    'Assistant Pastor',
    'Church Secretary',
  ].includes(user.role);

  const canSeeFinance = [
    'Super Administrator',
    'Church Administrator',
    'Senior Pastor',
    'Financial Secretary',
  ].includes(user.role);

  async function loadConferences() {
    try {
      const res = await apiFetch<Conference[]>('/api/conferences');
      setConferences(res);
      if (canSeeFinance) {
        const txns = await apiFetch<FinancialTransaction[]>('/api/finance');
        setConfFinance(txns.filter((t) => t.conference_id !== null));
      }
    } catch (err) {
      onNotify('error', (err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadConferences();
  }, []);

  async function openDetails(conf: Conference) {
    setSelected(conf);
    try {
      const regs = await apiFetch<ConferenceRegistration[]>(`/api/conferences/${conf.id}/registrations`);
      setRegistrations(regs);
    } catch {
      setRegistrations([]);
    }
  }

  async function handleRegister(conf: Conference) {
    try {
      await apiFetch(`/api/conferences/${conf.id}/register`, {
        method: 'POST',
        body: JSON.stringify({
          full_name: user.full_name,
          email: user.email,
          phone: user.phone,
          department: user.department,
        }),
      });
      onNotify('success', `You are now registered for ${conf.title}!`);
      loadConferences();
      if (selected?.id === conf.id) openDetails(conf);
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function toggleAttendance(reg: ConferenceRegistration) {
    try {
      await apiFetch(`/api/conferences/registrations/${reg.id}/attendance`, {
        method: 'PUT',
        body: JSON.stringify({ attended: !reg.attended }),
      });
      if (selected) openDetails(selected);
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function handlePosterUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const url = await readFileAsDataUrl(file, 3);
      setForm((prev) => ({ ...prev, poster_url: url }));
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    const speakers = form.speakers_text
      .split('\n')
      .filter(Boolean)
      .map((line) => {
        const [name = '', role = '', topic = ''] = line.split('|').map((s) => s.trim());
        return { name, role, topic };
      });
    const programme = form.programme_text
      .split('\n')
      .filter(Boolean)
      .map((line) => {
        const [day = '', time = '', session = '', speaker = ''] = line.split('|').map((s) => s.trim());
        return { day, time, session, speaker };
      });
    const committees = form.committees_text
      .split('\n')
      .filter(Boolean)
      .map((line) => {
        const [name = '', lead = '', members = ''] = line.split('|').map((s) => s.trim());
        return { name, lead, members };
      });

    try {
      await apiFetch('/api/conferences', {
        method: 'POST',
        body: JSON.stringify({
          title: form.title,
          description: form.description,
          poster_url: form.poster_url,
          start_date: form.start_date,
          end_date: form.end_date,
          venue: form.venue,
          theme: form.theme,
          budget: Number(form.budget || 0),
          speakers,
          programme,
          committees,
        }),
      });
      onNotify('success', `Conference "${form.title}" published.`);
      setCreateOpen(false);
      loadConferences();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Conference & Convocation Management"
        description="Organize major church convocations, manage speaker programmes, committees, budgets, and direct member registrations."
        actions={
          <>
            <button
              type="button"
              onClick={() => {
                exportToExcel(
                  'Church_Connect_Conferences',
                  'Conferences',
                  conferences.map((c) => ({
                    Title: c.title,
                    Theme: c.theme,
                    Start: c.start_date,
                    End: c.end_date,
                    Venue: c.venue,
                    Budget: c.budget,
                    Registrations: c.registrations_count || 0,
                    Status: c.status,
                  }))
                );
                onNotify('success', 'Conference report exported to Excel.');
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              Excel Report
            </button>
            <button
              type="button"
              onClick={() => {
                exportToPdf(
                  'Church_Connect_Conferences',
                  'CHURCH CONNECT — Conference Summary Report',
                  `Generated ${new Date().toLocaleDateString()}`,
                  ['Title', 'Dates', 'Venue', 'Registrations', 'Budget', 'Status'],
                  conferences.map((c) => [
                    c.title,
                    `${c.start_date} to ${c.end_date}`,
                    c.venue,
                    c.registrations_count || 0,
                    formatCurrency(c.budget),
                    c.status,
                  ])
                );
                onNotify('success', 'Conference report exported to PDF.');
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              PDF Report
            </button>
            {canManage && (
              <button
                type="button"
                onClick={() => setCreateOpen(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675] whitespace-nowrap"
              >
                <Plus className="w-4 h-4" />
                Create Conference
              </button>
            )}
          </>
        }
      />

      {loading ? (
        <div className="grid md:grid-cols-2 gap-6">
          {[1, 2].map((n) => (
            <div key={n} className="h-80 rounded-xl bg-slate-200/60 dark:bg-slate-800/60 animate-pulse" />
          ))}
        </div>
      ) : conferences.length === 0 ? (
        <EmptyState
          title="No conferences scheduled yet"
          description="Create your upcoming convocation or summit to begin accepting member registrations."
          actionLabel={canManage ? 'Create Conference' : undefined}
          onAction={canManage ? () => setCreateOpen(true) : undefined}
        />
      ) : (
        <div className="grid lg:grid-cols-2 gap-6">
          {conferences.map((conf) => {
            const income = confFinance
              .filter((t) => t.conference_id === conf.id && t.type === 'Income')
              .reduce((s, t) => s + t.amount, 0);
            const expense = confFinance
              .filter((t) => t.conference_id === conf.id && t.type === 'Expense')
              .reduce((s, t) => s + t.amount, 0);

            return (
              <div
                key={conf.id}
                className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden flex flex-col"
              >
                <div className="h-52 relative">
                  <ResilientImage
                    src={conf.poster_url}
                    alt={conf.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-transparent" />
                  <div className="absolute bottom-4 left-5 right-5 text-white">
                    <div className="text-xs font-medium text-[#e5c158]">
                      Theme: {conf.theme || 'Spiritual Renewal'}
                    </div>
                    <h2 className="mt-1 font-display text-xl font-semibold leading-snug">
                      {conf.title}
                    </h2>
                  </div>
                </div>

                <div className="p-6 flex-1 flex flex-col justify-between space-y-5">
                  <div className="space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 dark:text-slate-300">
                        <span className="inline-flex items-center gap-1 font-mono">
                          <Calendar className="w-3.5 h-3.5 text-[#b48327]" />
                          {formatShortDate(conf.start_date)} – {formatShortDate(conf.end_date)}
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-[#4c1d95] dark:text-purple-300" />
                          {conf.venue}
                        </span>
                      </div>
                      <StatusTag status={conf.status} />
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      {conf.description}
                    </p>

                    <div className="grid grid-cols-3 gap-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                      <div>
                        <div className="text-slate-500 dark:text-slate-400">Speakers</div>
                        <div className="font-mono font-semibold text-[#0f1e3d] dark:text-white">
                          {conf.speakers.length}
                        </div>
                      </div>
                      <div>
                        <div className="text-slate-500 dark:text-slate-400">Registered</div>
                        <div className="font-mono font-semibold text-[#4c1d95] dark:text-purple-300">
                          {conf.registrations_count || 0}
                        </div>
                      </div>
                      <div>
                        <div className="text-slate-500 dark:text-slate-400">
                          {canSeeFinance ? 'Income / Exp' : 'Sessions'}
                        </div>
                        <div className="font-mono font-semibold text-[#9a6b16] dark:text-[#e5c158]">
                          {canSeeFinance
                            ? `${formatCurrency(income)} / ${formatCurrency(expense)}`
                            : conf.programme.length}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                    <button
                      type="button"
                      onClick={() => openDetails(conf)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                    >
                      <Users className="w-3.5 h-3.5" />
                      Programme, Speakers & Attendance
                    </button>

                    {conf.is_registered ? (
                      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-400">
                        <Check className="w-4 h-4" />
                        Registered
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleRegister(conf)}
                        className="px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
                      >
                        Register as Participant
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Conference Detail Modal */}
      <Modal
        open={Boolean(selected)}
        onClose={() => setSelected(null)}
        title={selected?.title || ''}
        subtitle={
          selected
            ? `${formatShortDate(selected.start_date)} – ${formatShortDate(selected.end_date)} · ${selected.venue}`
            : ''
        }
        maxWidth="max-w-3xl"
      >
        {selected && (
          <div className="space-y-6">
            {/* Speakers */}
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                Guest & Host Speakers
              </h3>
              <div className="grid sm:grid-cols-3 gap-3">
                {selected.speakers.map((sp, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#080f1e]"
                  >
                    <div className="text-xs font-semibold text-[#0f1e3d] dark:text-white">
                      {sp.name}
                    </div>
                    <div className="text-[11px] text-[#9a6b16] dark:text-[#e5c158]">{sp.role}</div>
                    <div className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
                      {sp.topic}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Programme */}
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                Conference Programme
              </h3>
              <div className="border border-slate-200 dark:border-slate-800 rounded-lg divide-y divide-slate-100 dark:divide-slate-800">
                {selected.programme.map((p, idx) => (
                  <div key={idx} className="p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                    <div>
                      <span className="font-mono font-medium text-[#4c1d95] dark:text-purple-300">
                        {p.day} · {p.time}
                      </span>
                      <div className="font-medium text-[#0f1e3d] dark:text-white mt-0.5">
                        {p.session}
                      </div>
                    </div>
                    <span className="text-slate-500 dark:text-slate-400">{p.speaker}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Committees */}
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                Organizing Committees
              </h3>
              <div className="grid sm:grid-cols-3 gap-3">
                {selected.committees.map((cm, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 text-xs"
                  >
                    <div className="font-semibold text-[#0f1e3d] dark:text-white">{cm.name}</div>
                    <div className="text-slate-600 dark:text-slate-300 mt-0.5">Lead: {cm.lead}</div>
                    <div className="text-slate-500 dark:text-slate-400 mt-0.5">{cm.members}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Participants & Attendance */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Registered Participants ({registrations.length})
                </h3>
                {!selected.is_registered && (
                  <button
                    type="button"
                    onClick={() => handleRegister(selected)}
                    className="px-3 py-1.5 text-xs font-medium rounded-lg bg-[#4c1d95] text-white"
                  >
                    Register Me
                  </button>
                )}
              </div>
              <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 dark:bg-[#080f1e] border-b border-slate-200 dark:border-slate-800 text-slate-500">
                    <tr>
                      <th className="py-2 px-3">Participant</th>
                      <th className="py-2 px-3">Department</th>
                      <th className="py-2 px-3 text-right">Attendance</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {registrations.map((r) => (
                      <tr key={r.id}>
                        <td className="py-2 px-3 font-medium text-[#0f1e3d] dark:text-white">
                          {r.full_name}
                          <div className="text-[11px] font-normal text-slate-400">{r.email}</div>
                        </td>
                        <td className="py-2 px-3 text-slate-600 dark:text-slate-300">
                          {r.department}
                        </td>
                        <td className="py-2 px-3 text-right">
                          {canManage ? (
                            <button
                              type="button"
                              onClick={() => toggleAttendance(r)}
                              className={`px-2.5 py-1 text-[11px] font-medium rounded border ${
                                r.attended
                                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800 dark:bg-emerald-950/40 dark:border-emerald-700 dark:text-emerald-300'
                                  : 'border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                              }`}
                            >
                              {r.attended ? 'Checked In' : 'Mark Attended'}
                            </button>
                          ) : (
                            <StatusTag status={r.attended ? 'Completed' : 'Upcoming'} />
                          )}
                        </td>
                      </tr>
                    ))}
                    {registrations.length === 0 && (
                      <tr>
                        <td colSpan={3} className="py-4 text-center text-slate-500">
                          No participants registered yet.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* Create Conference Modal */}
      <Modal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        title="Create New Conference"
        subtitle="Configure schedule, speakers, organizing committees, and conference poster."
      >
        <form onSubmit={handleCreate} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Conference Title
              </label>
              <input
                type="text"
                required
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Theme
              </label>
              <input
                type="text"
                value={form.theme}
                onChange={(e) => setForm({ ...form, theme: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Start Date
              </label>
              <input
                type="date"
                required
                value={form.start_date}
                onChange={(e) => setForm({ ...form, start_date: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                End Date
              </label>
              <input
                type="date"
                required
                value={form.end_date}
                onChange={(e) => setForm({ ...form, end_date: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Venue
              </label>
              <input
                type="text"
                required
                value={form.venue}
                onChange={(e) => setForm({ ...form, venue: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Budget ($)
              </label>
              <input
                type="number"
                value={form.budget}
                onChange={(e) => setForm({ ...form, budget: e.target.value })}
                className="w-full px-3 py-2 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Description
            </label>
            <textarea
              rows={2}
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Conference Poster
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={form.poster_url}
                onChange={(e) => setForm({ ...form, poster_url: e.target.value })}
                className="flex-1 px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
              <label className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 cursor-pointer">
                <Upload className="w-3.5 h-3.5" />
                Upload
                <input type="file" accept="image/*" className="hidden" onChange={handlePosterUpload} />
              </label>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Speakers (Name | Role | Topic per line)
              </label>
              <textarea
                rows={2}
                value={form.speakers_text}
                onChange={(e) => setForm({ ...form, speakers_text: e.target.value })}
                className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Programme (Day | Time | Session | Speaker)
              </label>
              <textarea
                rows={2}
                value={form.programme_text}
                onChange={(e) => setForm({ ...form, programme_text: e.target.value })}
                className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setCreateOpen(false)}
              className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
            >
              Publish Conference
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
