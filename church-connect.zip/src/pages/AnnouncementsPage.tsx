import React, { useEffect, useState } from 'react';
import {
  Edit3,
  MessageSquare,
  Pin,
  Plus,
  Search,
  Trash2,
  Upload,
} from 'lucide-react';
import { apiFetch, formatShortDate, readFileAsDataUrl } from '../lib/api';
import { EmptyState, Modal, ResilientImage, SectionHeader } from '../components/ui/ChurchUI';
import type { Announcement, UserAccount } from '../types';

export default function AnnouncementsPage({
  user,
  onNotify,
}: {
  user: UserAccount;
  onNotify: (type: 'success' | 'error', message: string) => void;
}) {
  const [items, setItems] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Announcement | null>(null);
  const [commentText, setCommentText] = useState<Record<number, string>>({});

  const [form, setForm] = useState({
    title: '',
    description: '',
    image_url: '',
    category: 'General',
    is_important: false,
    is_pinned: false,
    is_emergency: false,
    allow_comments: true,
    publication_date: new Date().toISOString().slice(0, 10),
    event_date: '',
    push_notification: true,
  });

  const canPublish = [
    'Super Administrator',
    'Church Administrator',
    'Senior Pastor',
    'Assistant Pastor',
    'Church Secretary',
    'Department Leader',
  ].includes(user.role);

  const canDelete = [
    'Super Administrator',
    'Church Administrator',
    'Senior Pastor',
    'Church Secretary',
  ].includes(user.role);

  async function loadAnnouncements() {
    try {
      const res = await apiFetch<Announcement[]>('/api/announcements');
      setItems(res);
    } catch (err) {
      onNotify('error', (err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAnnouncements();
  }, []);

  function openCreate() {
    setEditing(null);
    setForm({
      title: '',
      description: '',
      image_url: '',
      category: 'General',
      is_important: false,
      is_pinned: false,
      is_emergency: false,
      allow_comments: true,
      publication_date: new Date().toISOString().slice(0, 10),
      event_date: '',
      push_notification: true,
    });
    setModalOpen(true);
  }

  function openEdit(ann: Announcement) {
    setEditing(ann);
    setForm({
      title: ann.title,
      description: ann.description,
      image_url: ann.image_url,
      category: ann.category,
      is_important: ann.is_important,
      is_pinned: ann.is_pinned,
      is_emergency: ann.is_emergency,
      allow_comments: ann.allow_comments,
      publication_date: ann.publication_date,
      event_date: ann.event_date,
      push_notification: false,
    });
    setModalOpen(true);
  }

  async function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await readFileAsDataUrl(file, 3);
      setForm((prev) => ({ ...prev, image_url: dataUrl }));
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    try {
      if (editing) {
        await apiFetch(`/api/announcements/${editing.id}`, {
          method: 'PUT',
          body: JSON.stringify(form),
        });
        onNotify('success', 'Announcement updated.');
      } else {
        await apiFetch('/api/announcements', {
          method: 'POST',
          body: JSON.stringify(form),
        });
        onNotify('success', 'Announcement published and notifications dispatched.');
      }
      setModalOpen(false);
      loadAnnouncements();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function handleDelete(id: number) {
    try {
      await apiFetch(`/api/announcements/${id}`, { method: 'DELETE' });
      onNotify('success', 'Announcement removed.');
      loadAnnouncements();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function handleComment(announcementId: number) {
    const text = (commentText[announcementId] || '').trim();
    if (!text) return;
    try {
      await apiFetch(`/api/announcements/${announcementId}/comments`, {
        method: 'POST',
        body: JSON.stringify({ content: text }),
      });
      setCommentText((prev) => ({ ...prev, [announcementId]: '' }));
      loadAnnouncements();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  const categories = ['All', 'General', 'Worship Service', 'Conference', 'Welfare', 'Pastoral Message', 'Departmental'];

  const filtered = items.filter((a) => {
    const matchesCat = categoryFilter === 'All' || a.category === categoryFilter;
    const matchesQuery =
      !search.trim() ||
      a.title.toLowerCase().includes(search.toLowerCase()) ||
      a.description.toLowerCase().includes(search.toLowerCase());
    return matchesCat && matchesQuery;
  });

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Church Announcements & Notices"
        description="Official parish bulletins, pinned notices, emergency communications, and congregation discussions."
        actions={
          canPublish && (
            <button
              type="button"
              onClick={openCreate}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675] whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              Publish Announcement
            </button>
          )
        }
      />

      {/* Filter & Search Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-[#111d36] rounded-lg border border-slate-200 dark:border-slate-800">
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                categoryFilter === cat
                  ? 'bg-white dark:bg-[#1a2947] text-[#0f1e3d] dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search announcements..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111d36] text-slate-900 dark:text-white"
          />
        </div>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((n) => (
            <div key={n} className="h-40 rounded-xl bg-slate-200/60 dark:bg-slate-800/60 animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <EmptyState
          title="No announcements match your filter"
          description="Try clearing the search query or selecting All categories."
          actionLabel={canPublish ? 'Publish First Announcement' : undefined}
          onAction={canPublish ? openCreate : undefined}
        />
      ) : (
        <div className="space-y-5">
          {filtered.map((ann) => (
            <article
              key={ann.id}
              className={`bg-white dark:bg-[#111d36] border rounded-xl overflow-hidden ${
                ann.is_emergency
                  ? 'border-red-300 dark:border-red-800'
                  : ann.is_pinned
                  ? 'border-[#b48327]/60'
                  : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              <div className="grid md:grid-cols-12">
                {ann.image_url && (
                  <div className="md:col-span-4 h-52 md:h-auto border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-800">
                    <ResilientImage
                      src={ann.image_url}
                      alt={ann.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <div className={`${ann.image_url ? 'md:col-span-8' : 'md:col-span-12'} p-6`}>
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <span className="font-medium text-[#4c1d95] dark:text-purple-300">
                        {ann.category}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono">Published {formatShortDate(ann.publication_date)}</span>
                      {ann.event_date && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono">Event {formatShortDate(ann.event_date)}</span>
                        </>
                      )}
                      <span aria-hidden="true">·</span>
                      <span>By {ann.author_name}</span>
                      {ann.is_pinned && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="inline-flex items-center gap-1 font-semibold text-[#9a6b16] dark:text-[#e5c158]">
                            <Pin className="w-3 h-3" /> Pinned
                          </span>
                        </>
                      )}
                      {ann.is_important && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-semibold text-[#4c1d95] dark:text-purple-300">
                            Important Notice
                          </span>
                        </>
                      )}
                      {ann.is_emergency && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-semibold text-red-700 dark:text-red-400">
                            Emergency Alert
                          </span>
                        </>
                      )}
                    </div>

                    {canPublish && (
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => openEdit(ann)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-[#4c1d95] hover:bg-slate-100 dark:hover:bg-slate-800"
                          title="Edit announcement"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        {canDelete && (
                          <button
                            type="button"
                            onClick={() => handleDelete(ann.id)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30"
                            title="Delete announcement"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    )}
                  </div>

                  <h2 className="mt-2 font-display text-xl font-semibold text-[#0f1e3d] dark:text-white">
                    {ann.title}
                  </h2>
                  <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                    {ann.description}
                  </p>

                  {/* Comments Section */}
                  {ann.allow_comments && (
                    <div className="mt-5 pt-4 border-t border-slate-200 dark:border-slate-800">
                      <div className="flex items-center gap-1.5 text-xs font-medium text-slate-600 dark:text-slate-300 mb-3">
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Member Responses ({ann.comments?.length || 0})</span>
                      </div>

                      {ann.comments && ann.comments.length > 0 && (
                        <div className="space-y-2.5 mb-3">
                          {ann.comments.map((c) => (
                            <div
                              key={c.id}
                              className="text-xs bg-slate-50 dark:bg-[#080f1e] border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2"
                            >
                              <div className="flex items-center justify-between gap-2">
                                <span className="font-semibold text-[#0f1e3d] dark:text-white">
                                  {c.author_name} ·{' '}
                                  <span className="font-normal text-slate-500">{c.author_role}</span>
                                </span>
                                <span className="font-mono text-[11px] text-slate-400">
                                  {formatShortDate(c.created_at)}
                                </span>
                              </div>
                              <p className="mt-1 text-slate-700 dark:text-slate-300">{c.content}</p>
                            </div>
                          ))}
                        </div>
                      )}

                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={commentText[ann.id] || ''}
                          onChange={(e) =>
                            setCommentText((prev) => ({ ...prev, [ann.id]: e.target.value }))
                          }
                          placeholder="Add a respectful congregation comment..."
                          className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                        />
                        <button
                          type="button"
                          onClick={() => handleComment(ann.id)}
                          className="px-3 py-1.5 text-xs font-medium rounded-lg bg-[#0f1e3d] text-white hover:bg-[#1b3366]"
                        >
                          Post
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </article>
          ))}
        </div>
      )}

      {/* Create / Edit Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? 'Edit Announcement' : 'Publish New Announcement'}
        subtitle="Announcements appear immediately on member dashboards."
      >
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Announcement Title
            </label>
            <input
              type="text"
              required
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Category
              </label>
              <select
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              >
                <option>General</option>
                <option>Worship Service</option>
                <option>Conference</option>
                <option>Welfare</option>
                <option>Pastoral Message</option>
                <option>Departmental</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Publication Date
              </label>
              <input
                type="date"
                value={form.publication_date}
                onChange={(e) => setForm({ ...form, publication_date: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Event Date (Optional)
              </label>
              <input
                type="date"
                value={form.event_date}
                onChange={(e) => setForm({ ...form, event_date: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Description
            </label>
            <textarea
              rows={4}
              required
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Announcement Image (Upload or URL)
            </label>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={form.image_url}
                onChange={(e) => setForm({ ...form, image_url: e.target.value })}
                placeholder="/src/assets/images/... or upload image"
                className="flex-1 px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
              <label className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
                <Upload className="w-3.5 h-3.5" />
                Upload File
                <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
              </label>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1 text-xs">
            <label className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={form.is_important}
                onChange={(e) => setForm({ ...form, is_important: e.target.checked })}
              />
              Important Label
            </label>
            <label className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={form.is_pinned}
                onChange={(e) => setForm({ ...form, is_pinned: e.target.checked })}
              />
              Pin to Top
            </label>
            <label className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={form.is_emergency}
                onChange={(e) => setForm({ ...form, is_emergency: e.target.checked })}
              />
              Emergency Alert
            </label>
            <label className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={form.allow_comments}
                onChange={(e) => setForm({ ...form, allow_comments: e.target.checked })}
              />
              Allow Comments
            </label>
          </div>

          {!editing && (
            <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={form.push_notification}
                onChange={(e) => setForm({ ...form, push_notification: e.target.checked })}
              />
              Push immediate notification to all church members
            </label>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
            >
              {editing ? 'Save Changes' : 'Publish Announcement'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
