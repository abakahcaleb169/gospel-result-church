import React, { useState } from 'react';
import {
  ArrowRight,
  Building2,
  KeyRound,
  Lock,
  Mail,
  ShieldCheck,
  UserPlus,
  Users,
} from 'lucide-react';
import { apiFetch, setStoredToken } from '../lib/api';
import { Modal, ResilientImage } from '../components/ui/ChurchUI';
import type { AppSettings, UserAccount } from '../types';

const DEMO_ACCOUNTS = [
  { label: 'Super Admin', email: 'admin@churchconnect.org', role: 'Super Administrator' },
  { label: 'Senior Pastor', email: 'pastor@churchconnect.org', role: 'Senior Pastor' },
  { label: 'Church Admin', email: 'church.admin@churchconnect.org', role: 'Church Administrator' },
  { label: 'Church Secretary', email: 'secretary@churchconnect.org', role: 'Church Secretary' },
  { label: 'Financial Sec.', email: 'finance@churchconnect.org', role: 'Financial Secretary' },
  { label: 'Welfare Officer', email: 'welfare@churchconnect.org', role: 'Welfare Officer' },
  { label: 'Dept. Leader', email: 'leader@churchconnect.org', role: 'Department Leader' },
  { label: 'Church Member', email: 'member@churchconnect.org', role: 'Church Member' },
];

export default function AuthPortal({
  settings,
  onAuthenticated,
  onNotify,
}: {
  settings: AppSettings;
  onAuthenticated: (user: UserAccount) => void;
  onNotify: (type: 'success' | 'error', message: string) => void;
}) {
  const [mode, setMode] = useState<'login' | 'register' | 'forgot' | 'reset'>('login');
  const [email, setEmail] = useState('admin@churchconnect.org');
  const [password, setPassword] = useState('ChurchConnect2026!');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [department, setDepartment] = useState('General Congregation');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [resetCode, setResetCode] = useState('');
  const [resetPreview, setResetPreview] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const [visitorOpen, setVisitorOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [visitorForm, setVisitorForm] = useState({
    full_name: '',
    email: '',
    phone: '',
    service_attended: 'Sunday 9:00 AM Service',
    invited_by: '',
    prayer_need: '',
  });

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await apiFetch<{ token: string; user: UserAccount }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      });
      setStoredToken(res.token);
      onAuthenticated(res.user);
      onNotify('success', `Welcome back, ${res.user.full_name}`);
    } catch (err) {
      onNotify('error', (err as Error).message);
    } finally {
      setSubmitting(false);
    }
  }

  async function handleQuickDemo(demoEmail: string) {
    setEmail(demoEmail);
    setPassword('ChurchConnect2026!');
    setSubmitting(true);
    try {
      const res = await apiFetch<{ token: string; user: UserAccount }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email: demoEmail, password: 'ChurchConnect2026!' }),
      });
      setStoredToken(res.token);
      onAuthenticated(res.user);
      onNotify('success', `Signed in as ${res.user.full_name} (${res.user.role})`);
    } catch (err) {
      onNotify('error', (err as Error).message);
    } finally {
      setSubmitting(false);
    }
  }

  async function handleRegister(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await apiFetch<{ token: string; user: UserAccount }>('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify({
          full_name: fullName,
          email,
          phone,
          password,
          department,
          date_of_birth: dateOfBirth,
        }),
      });
      setStoredToken(res.token);
      onAuthenticated(res.user);
      onNotify('success', `Account created! Member ID: ${res.user.member_code}`);
    } catch (err) {
      onNotify('error', (err as Error).message);
    } finally {
      setSubmitting(false);
    }
  }

  async function handleForgot(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await apiFetch<{ message: string; reset_code_preview: string }>(
        '/api/auth/forgot-password',
        {
          method: 'POST',
          body: JSON.stringify({ email }),
        }
      );
      setResetPreview(res.reset_code_preview);
      setResetCode(res.reset_code_preview);
      setMode('reset');
      onNotify('success', res.message);
    } catch (err) {
      onNotify('error', (err as Error).message);
    } finally {
      setSubmitting(false);
    }
  }

  async function handleReset(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await apiFetch<{ message: string }>('/api/auth/reset-password', {
        method: 'POST',
        body: JSON.stringify({ email, reset_code: resetCode, new_password: newPassword }),
      });
      onNotify('success', res.message);
      setPassword(newPassword);
      setMode('login');
    } catch (err) {
      onNotify('error', (err as Error).message);
    } finally {
      setSubmitting(false);
    }
  }

  async function handleVisitorSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      await apiFetch('/api/public/visitors', {
        method: 'POST',
        body: JSON.stringify(visitorForm),
      });
      onNotify('success', 'Thank you! Your visitor card has been received by our pastoral hospitality team.');
      setVisitorOpen(false);
      setVisitorForm({
        full_name: '',
        email: '',
        phone: '',
        service_attended: 'Sunday 9:00 AM Service',
        invited_by: '',
        prayer_need: '',
      });
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  return (
    <div className="min-h-screen grid lg:grid-cols-12 bg-slate-50 dark:bg-[#080f1e]">
      {/* Left Architectural Sanctuary Showcase */}
      <div className="lg:col-span-6 relative flex flex-col justify-between p-8 sm:p-12 bg-[#0f1e3d] text-white overflow-hidden">
        <ResilientImage
          src="/src/assets/images/church_sanctuary_hero_1794690388207.jpg"
          alt="Church Connect Sanctuary"
          className="absolute inset-0 w-full h-full object-cover opacity-35"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#080f1e] via-[#0f1e3d]/80 to-[#2e1065]/65" />

        <div className="relative z-10 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-14 h-14 rounded-full overflow-hidden border border-[#d4af37]/60 bg-[#0f1e3d] shrink-0">
              <ResilientImage
                src={settings.logo_url || '/assets/aistudio/IMG_0954_b4f1f733.jpeg'}
                alt={settings.app_name}
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <div className="font-display text-lg sm:text-xl font-bold tracking-tight text-white">
                {settings.app_name}
              </div>
              <div className="text-xs text-[#e5c158]">{settings.church_name}</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setAboutOpen(true)}
              className="px-3 py-1.5 text-xs font-medium rounded-lg border border-white/20 text-white hover:bg-white/10 transition-colors whitespace-nowrap"
            >
              Our Heritage
            </button>
            <button
              type="button"
              onClick={() => setVisitorOpen(true)}
              className="px-3 py-1.5 text-xs font-medium rounded-lg bg-[#d4af37] text-[#0f1e3d] hover:bg-[#e5c158] transition-colors whitespace-nowrap"
            >
              Visitor Card
            </button>
          </div>
        </div>

        <div className="relative z-10 my-12 max-w-xl">
          <p className="text-xs font-medium tracking-wider text-[#e5c158]">
            Digital Parish & Ministry Platform
          </p>
          <h1 className="mt-3 font-display text-3xl sm:text-4xl lg:text-5xl font-semibold leading-tight text-white text-balance">
            {settings.tagline}
          </h1>
          <p className="mt-4 text-sm sm:text-base text-slate-200 leading-relaxed max-w-lg">
            Unifying congregation care, pastoral leadership, welfare stewardship, conference registration,
            financial accountability, and departmental ministry in one secure sanctuary workspace.
          </p>

          {settings.daily_verse_text && (
            <div className="mt-8 p-5 rounded-xl bg-white/8 border border-white/15 backdrop-blur-xs">
              <p className="font-display italic text-base text-slate-100 leading-relaxed">
                “{settings.daily_verse_text}”
              </p>
              <p className="mt-2 text-xs font-medium text-[#e5c158]">
                Daily Scripture · {settings.daily_verse_ref}
              </p>
            </div>
          )}
        </div>

        <div className="relative z-10 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-slate-300 border-t border-white/15 pt-6">
          <span>{settings.address}</span>
          <span>·</span>
          <span>{settings.contact_email}</span>
          <span>·</span>
          <span>{settings.contact_phone}</span>
        </div>
      </div>

      {/* Right Authentication Workspace */}
      <div className="lg:col-span-6 flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md space-y-6">
          <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-7 shadow-sm">
            {/* Segmented Mode Tabs */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-[#080f1e] rounded-lg mb-6">
              <button
                type="button"
                onClick={() => setMode('login')}
                className={`flex-1 py-2 px-3 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  mode === 'login'
                    ? 'bg-white dark:bg-[#1a2947] text-[#0f1e3d] dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                Member Sign In
              </button>
              {settings.allow_registration && (
                <button
                  type="button"
                  onClick={() => setMode('register')}
                  className={`flex-1 py-2 px-3 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    mode === 'register'
                      ? 'bg-white dark:bg-[#1a2947] text-[#0f1e3d] dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  New Member
                </button>
              )}
              <button
                type="button"
                onClick={() => setMode('forgot')}
                className={`flex-1 py-2 px-3 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  mode === 'forgot' || mode === 'reset'
                    ? 'bg-white dark:bg-[#1a2947] text-[#0f1e3d] dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                Reset Password
              </button>
            </div>

            {mode === 'login' && (
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <h2 className="font-display text-2xl font-semibold text-[#0f1e3d] dark:text-white">
                    Sign in to your account
                  </h2>
                  <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                    Access your role-authorized ministry dashboard and church updates.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full pl-9 pr-3 py-2.5 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#4c1d95]"
                      placeholder="name@churchconnect.org"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-9 pr-3 py-2.5 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#4c1d95]"
                      placeholder="Enter password"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-sm font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675] disabled:opacity-60 transition-colors"
                >
                  {submitting ? 'Signing in...' : 'Sign In'}
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            )}

            {mode === 'register' && (
              <form onSubmit={handleRegister} className="space-y-3.5">
                <div>
                  <h2 className="font-display text-2xl font-semibold text-[#0f1e3d] dark:text-white">
                    Create Member Account
                  </h2>
                  <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                    Register to join church departments, events, conferences, and prayer fellowship.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                    placeholder="e.g. Samuel Boateng"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                      placeholder="+1 (555) 000-0000"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Preferred Department
                    </label>
                    <select
                      value={department}
                      onChange={(e) => setDepartment(e.target.value)}
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                    >
                      <option>General Congregation</option>
                      <option>Choir Department</option>
                      <option>Ushering Department</option>
                      <option>Youth Department</option>
                      <option>Men's Ministry</option>
                      <option>Women's Ministry</option>
                      <option>Children's Ministry</option>
                      <option>Evangelism Department</option>
                      <option>Media Department</option>
                      <option>Prayer Department</option>
                      <option>Welfare Department</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Date of Birth
                    </label>
                    <input
                      type="date"
                      value={dateOfBirth}
                      onChange={(e) => setDateOfBirth(e.target.value)}
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Password (min 6 characters)
                  </label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                  />
                </div>
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-sm font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675] disabled:opacity-60 transition-colors"
                >
                  <UserPlus className="w-4 h-4" />
                  {submitting ? 'Creating Account...' : 'Complete Registration'}
                </button>
              </form>
            )}

            {mode === 'forgot' && (
              <form onSubmit={handleForgot} className="space-y-4">
                <div>
                  <h2 className="font-display text-2xl font-semibold text-[#0f1e3d] dark:text-white">
                    Forgot Password
                  </h2>
                  <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                    Enter your registered email to generate a secure verification reset code.
                  </p>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    Registered Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3 py-2.5 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                  />
                </div>
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-sm font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675] transition-colors"
                >
                  <KeyRound className="w-4 h-4" />
                  Generate Reset Code
                </button>
              </form>
            )}

            {mode === 'reset' && (
              <form onSubmit={handleReset} className="space-y-4">
                <div>
                  <h2 className="font-display text-2xl font-semibold text-[#0f1e3d] dark:text-white">
                    Set New Password
                  </h2>
                  {resetPreview && (
                    <p className="mt-2 p-2.5 rounded-lg bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200">
                      Verification code issued: <strong className="font-mono">{resetPreview}</strong>
                    </p>
                  )}
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Reset Code
                  </label>
                  <input
                    type="text"
                    required
                    value={resetCode}
                    onChange={(e) => setResetCode(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    New Password
                  </label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                  />
                </div>
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-2.5 px-4 text-sm font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675] transition-colors"
                >
                  Update Password
                </button>
              </form>
            )}
          </div>

          {/* Role-Based Quick Sign-In Panel */}
          <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-5">
            <div className="flex items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#0f1e3d] dark:text-white">
                <ShieldCheck className="w-4 h-4 text-[#b48327]" />
                <span>Quick Role Access (Demo Accounts)</span>
              </div>
              <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                Pw: ChurchConnect2026!
              </span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {DEMO_ACCOUNTS.map((acc) => (
                <button
                  key={acc.email}
                  type="button"
                  disabled={submitting}
                  onClick={() => handleQuickDemo(acc.email)}
                  className="text-left px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:border-[#4c1d95] dark:hover:border-purple-400 hover:bg-purple-50/50 dark:hover:bg-purple-950/30 transition-colors"
                >
                  <div className="text-xs font-medium text-[#0f1e3d] dark:text-white truncate">
                    {acc.label}
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                    {acc.role.split(' ')[0]}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Visitor Registration Modal */}
      <Modal
        open={visitorOpen}
        onClose={() => setVisitorOpen(false)}
        title="Welcome — New Visitor Card"
        subtitle="We are honored to worship with you. Share your details so our hospitality team can connect."
      >
        <form onSubmit={handleVisitorSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Full Name
              </label>
              <input
                type="text"
                required
                value={visitorForm.full_name}
                onChange={(e) => setVisitorForm({ ...visitorForm, full_name: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Service Attended
              </label>
              <select
                value={visitorForm.service_attended}
                onChange={(e) => setVisitorForm({ ...visitorForm, service_attended: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              >
                <option>Sunday 9:00 AM Service</option>
                <option>Sunday 11:00 AM Service</option>
                <option>Midweek Prayer & Bible Study</option>
                <option>Special Convocation</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={visitorForm.email}
                onChange={(e) => setVisitorForm({ ...visitorForm, email: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Phone Number
              </label>
              <input
                type="tel"
                value={visitorForm.phone}
                onChange={(e) => setVisitorForm({ ...visitorForm, phone: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Invited By (Optional)
            </label>
            <input
              type="text"
              value={visitorForm.invited_by}
              onChange={(e) => setVisitorForm({ ...visitorForm, invited_by: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              How Can We Pray For You?
            </label>
            <textarea
              rows={3}
              value={visitorForm.prayer_need}
              onChange={(e) => setVisitorForm({ ...visitorForm, prayer_need: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setVisitorOpen(false)}
              className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
            >
              Submit Visitor Card
            </button>
          </div>
        </form>
      </Modal>

      {/* Church History & About Modal */}
      <Modal
        open={aboutOpen}
        onClose={() => setAboutOpen(false)}
        title={settings.church_name}
        subtitle={settings.tagline}
      >
        <div className="space-y-5">
          <div className="h-48 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-800">
            <ResilientImage
              src="/src/assets/images/community_fellowship_1794690387540.jpg"
              alt={settings.church_name}
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-[#0f1e3d] dark:text-white flex items-center gap-2">
              <Building2 className="w-4 h-4 text-[#b48327]" />
              Church History & Mission
            </h3>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              {settings.about_history}
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300">
            <div>
              <div className="font-semibold text-[#0f1e3d] dark:text-white">Sanctuary Address</div>
              <div className="mt-1">{settings.address}</div>
            </div>
            <div>
              <div className="font-semibold text-[#0f1e3d] dark:text-white">Parish Office</div>
              <div className="mt-1">
                {settings.contact_email} · {settings.contact_phone}
              </div>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
}
