import React, { useEffect, useState } from 'react';
import { Download, Plus, Trash2 } from 'lucide-react';
import {
  apiFetch,
  exportToExcel,
  exportToPdf,
  formatCurrency,
  formatShortDate,
} from '../lib/api';
import { Modal, SectionHeader, StatCard, StatusTag } from '../components/ui/ChurchUI';
import type { FinancialTransaction, UserAccount } from '../types';

const INCOME_CATEGORIES = [
  'Tithe',
  'Offering',
  'Donation',
  'Special Contribution',
  'Welfare Contribution',
  'Conference Income',
];

const EXPENSE_CATEGORIES = [
  'Utility & Maintenance',
  'Ministry Outreach',
  'Welfare Disbursement',
  'Conference Expense',
  'Departmental Allocation',
  'Staff & Operations',
];

export default function FinancePage({
  user,
  onNotify,
}: {
  user: UserAccount;
  onNotify: (type: 'success' | 'error', message: string) => void;
}) {
  const [txns, setTxns] = useState<FinancialTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [typeFilter, setTypeFilter] = useState<'All' | 'Income' | 'Expense'>('All');
  const [catFilter, setCatFilter] = useState('All');
  const [modalOpen, setModalOpen] = useState(false);

  const [form, setForm] = useState({
    type: 'Income' as 'Income' | 'Expense',
    category: 'Tithe',
    amount: '',
    department: 'General Church',
    member_name: '',
    payment_method: 'Bank Transfer',
    reference_no: '',
    description: '',
    txn_date: new Date().toISOString().slice(0, 10),
  });

  const canWrite = ['Super Administrator', 'Church Administrator', 'Financial Secretary'].includes(
    user.role
  );

  async function loadFinance() {
    try {
      const res = await apiFetch<FinancialTransaction[]>('/api/finance');
      setTxns(res);
    } catch (err) {
      onNotify('error', (err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadFinance();
  }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    try {
      await apiFetch('/api/finance', {
        method: 'POST',
        body: JSON.stringify(form),
      });
      onNotify('success', 'Financial transaction recorded in ledger.');
      setModalOpen(false);
      setForm({
        type: 'Income',
        category: 'Tithe',
        amount: '',
        department: 'General Church',
        member_name: '',
        payment_method: 'Bank Transfer',
        reference_no: '',
        description: '',
        txn_date: new Date().toISOString().slice(0, 10),
      });
      loadFinance();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function handleDelete(id: number) {
    try {
      await apiFetch(`/api/finance/${id}`, { method: 'DELETE' });
      onNotify('success', 'Transaction removed.');
      loadFinance();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  const totalIncome = txns
    .filter((t) => t.type === 'Income')
    .reduce((s, t) => s + Number(t.amount), 0);
  const totalExpense = txns
    .filter((t) => t.type === 'Expense')
    .reduce((s, t) => s + Number(t.amount), 0);
  const netBalance = totalIncome - totalExpense;
  const totalTithes = txns
    .filter((t) => t.category === 'Tithe')
    .reduce((s, t) => s + Number(t.amount), 0);

  // Monthly grouping for bar chart
  const monthMap = new Map<string, { income: number; expense: number }>();
  for (const t of txns) {
    const month = (t.txn_date || '').slice(0, 7) || '2026-11';
    const curr = monthMap.get(month) || { income: 0, expense: 0 };
    if (t.type === 'Income') curr.income += Number(t.amount);
    else curr.expense += Number(t.amount);
    monthMap.set(month, curr);
  }
  const monthlySeries = Array.from(monthMap.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  const maxMonthVal = Math.max(
    1,
    ...monthlySeries.map(([, v]) => Math.max(v.income, v.expense))
  );

  // Category breakdown
  const catMap = new Map<string, number>();
  for (const t of txns) {
    catMap.set(t.category, (catMap.get(t.category) || 0) + Number(t.amount));
  }
  const catBreakdown = Array.from(catMap.entries()).sort((a, b) => b[1] - a[1]);

  const filtered = txns.filter((t) => {
    const okType = typeFilter === 'All' || t.type === typeFilter;
    const okCat = catFilter === 'All' || t.category === catFilter;
    return okType && okCat;
  });

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Church Financial Stewardship & Ledger"
        description="Restricted financial console for tithes, offerings, welfare funds, conference income, departmental allocations, and monthly expenditure reports."
        actions={
          <>
            <button
              type="button"
              onClick={() => {
                exportToExcel(
                  'Church_Connect_Financial_Report',
                  'Ledger',
                  filtered.map((t) => ({
                    Code: t.txn_code,
                    Date: t.txn_date,
                    Type: t.type,
                    Category: t.category,
                    Department: t.department,
                    Source: t.member_name,
                    Amount: t.amount,
                    Method: t.payment_method,
                    Reference: t.reference_no,
                  }))
                );
                onNotify('success', 'Financial ledger exported to Excel.');
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              <Download className="w-3.5 h-3.5" />
              Excel Report
            </button>
            <button
              type="button"
              onClick={() => {
                exportToPdf(
                  'Church_Connect_Financial_Report',
                  'CHURCH CONNECT — Financial Income & Expenditure Report',
                  `Income: ${formatCurrency(totalIncome)} · Expenses: ${formatCurrency(totalExpense)} · Net: ${formatCurrency(netBalance)}`,
                  ['Code', 'Date', 'Type', 'Category', 'Department', 'Amount'],
                  filtered.map((t) => [
                    t.txn_code,
                    t.txn_date,
                    t.type,
                    t.category,
                    t.department,
                    formatCurrency(t.amount),
                  ])
                );
                onNotify('success', 'Financial report exported to PDF.');
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              <Download className="w-3.5 h-3.5" />
              PDF Report
            </button>
            {canWrite && (
              <button
                type="button"
                onClick={() => setModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
              >
                <Plus className="w-4 h-4" />
                Record Transaction
              </button>
            )}
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Income" value={formatCurrency(totalIncome)} accent="emerald" />
        <StatCard label="Total Expenditure" value={formatCurrency(totalExpense)} accent="gold" />
        <StatCard label="Net Treasury Balance" value={formatCurrency(netBalance)} accent="purple" />
        <StatCard label="Total Tithes" value={formatCurrency(totalTithes)} accent="navy" />
      </div>

      {/* Charts Row: Monthly Income vs Expenditure + Category Breakdown */}
      <div className="grid lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="font-display text-lg font-semibold text-[#0f1e3d] dark:text-white">
                Monthly Income vs. Expenditure
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Comparative stewardship cashflow across recent months
              </p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
                <span className="w-2.5 h-2.5 rounded-xs bg-[#4c1d95]" /> Income
              </span>
              <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
                <span className="w-2.5 h-2.5 rounded-xs bg-[#b48327]" /> Expense
              </span>
            </div>
          </div>

          <div className="space-y-4">
            {monthlySeries.map(([month, vals]) => (
              <div key={month} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-mono font-medium text-[#0f1e3d] dark:text-white">
                    {month}
                  </span>
                  <span className="font-mono tabular-nums text-slate-600 dark:text-slate-300">
                    In: {formatCurrency(vals.income)} · Out: {formatCurrency(vals.expense)}
                  </span>
                </div>
                <div className="space-y-1">
                  <div className="h-2.5 w-full rounded bg-slate-100 dark:bg-[#080f1e] overflow-hidden">
                    <div
                      className="h-full bg-[#4c1d95] rounded"
                      style={{ width: `${Math.round((vals.income / maxMonthVal) * 100)}%` }}
                    />
                  </div>
                  <div className="h-2 w-full rounded bg-slate-100 dark:bg-[#080f1e] overflow-hidden">
                    <div
                      className="h-full bg-[#b48327] rounded"
                      style={{ width: `${Math.round((vals.expense / maxMonthVal) * 100)}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-5 bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6">
          <h2 className="font-display text-lg font-semibold text-[#0f1e3d] dark:text-white mb-4">
            Category Distribution
          </h2>
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {catBreakdown.map(([cat, amount]) => (
              <div key={cat} className="py-2.5 flex items-center justify-between gap-2">
                <span className="text-slate-700 dark:text-slate-200 font-medium">{cat}</span>
                <span className="font-mono tabular-nums font-semibold text-[#0f1e3d] dark:text-white">
                  {formatCurrency(amount)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Filters & Ledger Table */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-lg">
          {(['All', 'Income', 'Expense'] as const).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTypeFilter(t)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md ${
                typeFilter === t
                  ? 'bg-white dark:bg-[#1a2947] text-[#0f1e3d] dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        <select
          value={catFilter}
          onChange={(e) => setCatFilter(e.target.value)}
          className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111d36]"
        >
          <option value="All">All Categories</option>
          {[...INCOME_CATEGORIES, ...EXPENSE_CATEGORIES].map((c) => (
            <option key={c}>{c}</option>
          ))}
        </select>
      </div>

      <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-[#080f1e] border-b border-slate-200 dark:border-slate-800 text-slate-500">
              <tr>
                <th className="py-3 px-4 font-medium">Txn ID</th>
                <th className="py-3 px-4 font-medium">Date</th>
                <th className="py-3 px-4 font-medium">Type</th>
                <th className="py-3 px-4 font-medium">Category</th>
                <th className="py-3 px-4 font-medium">Department / Source</th>
                <th className="py-3 px-4 font-medium">Method</th>
                <th className="py-3 px-4 font-medium text-right">Amount</th>
                {canWrite && <th className="py-3 px-4 font-medium text-right">Action</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {loading ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    Loading financial ledger...
                  </td>
                </tr>
              ) : (
                filtered.map((t) => (
                  <tr key={t.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4 font-mono text-slate-600 dark:text-slate-300">
                      {t.txn_code}
                    </td>
                    <td className="py-3 px-4 font-mono">{formatShortDate(t.txn_date)}</td>
                    <td className="py-3 px-4">
                      <StatusTag status={t.type} />
                    </td>
                    <td className="py-3 px-4 font-medium text-[#0f1e3d] dark:text-white">
                      {t.category}
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-300">
                      <div>{t.department}</div>
                      <div className="text-[11px] text-slate-400">{t.member_name || t.description}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-500">{t.payment_method}</td>
                    <td
                      className={`py-3 px-4 text-right font-mono tabular-nums font-semibold ${
                        t.type === 'Income'
                          ? 'text-emerald-700 dark:text-emerald-400'
                          : 'text-red-700 dark:text-red-400'
                      }`}
                    >
                      {t.type === 'Income' ? '+' : '-'}
                      {formatCurrency(t.amount)}
                    </td>
                    {canWrite && (
                      <td className="py-3 px-4 text-right">
                        <button
                          type="button"
                          onClick={() => handleDelete(t.id)}
                          className="p-1.5 rounded text-slate-400 hover:text-red-600"
                          title="Delete entry"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Record Financial Transaction Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Record Financial Transaction"
        subtitle="Log tithes, offerings, donations, conference income, or church expenses."
      >
        <form onSubmit={handleCreate} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium mb-1">Transaction Type</label>
              <select
                value={form.type}
                onChange={(e) => {
                  const nextType = e.target.value as 'Income' | 'Expense';
                  setForm({
                    ...form,
                    type: nextType,
                    category: nextType === 'Income' ? 'Tithe' : 'Utility & Maintenance',
                  });
                }}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              >
                <option value="Income">Income</option>
                <option value="Expense">Expense</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Category</label>
              <select
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              >
                {(form.type === 'Income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES).map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Amount ($)</label>
              <input
                type="number"
                required
                min="0.01"
                step="0.01"
                value={form.amount}
                onChange={(e) => setForm({ ...form, amount: e.target.value })}
                className="w-full px-3 py-2 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Transaction Date</label>
              <input
                type="date"
                required
                value={form.txn_date}
                onChange={(e) => setForm({ ...form, txn_date: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Department</label>
              <select
                value={form.department}
                onChange={(e) => setForm({ ...form, department: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              >
                <option>General Church</option>
                <option>Welfare Department</option>
                <option>Choir Department</option>
                <option>Youth Department</option>
                <option>Media Department</option>
                <option>Evangelism Department</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Payment Method</label>
              <select
                value={form.payment_method}
                onChange={(e) => setForm({ ...form, payment_method: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              >
                <option>Bank Transfer</option>
                <option>Electronic Giving</option>
                <option>Cash & Card</option>
                <option>Check</option>
              </select>
            </div>
          </div>
          <input
            type="text"
            placeholder="Member / Payee / Source Name"
            value={form.member_name}
            onChange={(e) => setForm({ ...form, member_name: e.target.value })}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
          />
          <input
            type="text"
            placeholder="Description / Memo"
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
          />
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700"
            >
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white">
              Save Ledger Entry
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
