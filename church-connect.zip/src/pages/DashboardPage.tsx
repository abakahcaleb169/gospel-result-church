import React, { useEffect, useState } from 'react';
import {
  BookOpen,
  Calendar,
  ExternalLink,
  HeartHandshake,
  Radio,
  Sparkles,
  Users,
} from 'lucide-react';
import { apiFetch, formatCurrency, formatShortDate } from '../lib/api';
import { Modal, ResilientImage, StatCard, StatusTag } from '../components/ui/ChurchUI';
import type {
  Announcement,
  AppSettings,
  AttendanceRecord,
  ChurchEvent,
  Conference,
  Meeting,
  NavSectionId,
  NotificationItem,
  UserAccount,
} from '../types';

interface OverviewResponse {
  stats: {
    totalMembers: number;
    totalDepartments: number;
    upcomingEventsCount: number;
    upcomingConferencesCount: number;
    upcomingMeetingsCount: number;
    welfareSummary: {
      total_cases: number;
      active_cases: number;
      total_disbursed: number;
    };
    financeSummary: {
      total_income: number;
      total_expense: number;
    } | null;
  };
  upcomingEvents: ChurchEvent[];
  upcomingConferences: Conference[];
  upcomingMeetings: Meeting[];
  recentAnnouncements: Announcement[];
  birthdays: Array<{
    id: number;
    full_name: string;
    department: string;
    date_of_birth: string;
    avatar_url: string;
    role: string;
  }>;
  notifications: NotificationItem[];
  attendanceLatest: AttendanceRecord[];
}

export default function DashboardPage({
  user,
  settings,
  onNavigate,
  onNotify,
}: {
  user: UserAccount;
  settings: AppSettings;
  onNavigate: (section: NavSectionId) => void;
  onNotify: (type: 'success' | 'error', message: string) => void;
}) {
  const [data, setData] = useState<OverviewResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [givingOpen, setGivingOpen] = useState(false);
  const [givingForm, setGivingForm] = useState({
    category: 'Tithe',
    amount: '100',
    payment_method: 'Online Card',
    description: '',
  });
  const [givingBusy, setGivingBusy] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);

  async function loadOverview() {
    try {
      const res = await apiFetch<OverviewResponse>('/api/dashboard/overview');
      setData(res);
    } catch (err) {
      onNotify('error', (err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadOverview();
  }, []);

  async function handleGiveOnline(e: React.FormEvent) {
    e.preventDefault();
    setGivingBusy(true);
    try {
      await apiFetch('/api/finance/give', {
        method: 'POST',
        body: JSON.stringify(givingForm),
      });
      onNotify('success', `Thank you! Your ${givingForm.category} of $${givingForm.amount} has been recorded.`);
      setGivingOpen(false);
      loadOverview();
    } catch (err) {
      onNotify('error', (err as Error).message);
    } finally {
      setGivingBusy(false);
    }
  }

  const emergencyAlert = data?.recentAnnouncements.find((a) => a.is_emergency);

  return (
    <div className="space-y-8">
      {/* Emergency Announcement Banner (if active) */}
      {emergencyAlert && (
        <div className="rounded-xl border border-red-300 dark:border-red-800 bg-red-50 dark:bg-red-950/40 px-5 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="text-xs font-semibold text-red-800 dark:text-red-300">
              Emergency Church Notice · {formatShortDate(emergencyAlert.publication_date)}
            </div>
            <div className="mt-0.5 text-sm font-semibold text-red-950 dark:text-white">
              {emergencyAlert.title}
            </div>
            <p className="mt-1 text-xs text-red-800 dark:text-red-200 line-clamp-2">
              {emergencyAlert.description}
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('announcements')}
            className="px-3.5 py-2 text-xs font-medium rounded-lg bg-red-700 text-white hover:bg-red-800 whitespace-nowrap shrink-0"
          >
            Read Notice
          </button>
        </div>
      )}

      {/* Hero Welcome & Church Identity Banner */}
      <div className="grid lg:grid-cols-12 gap-6 items-stretch">
        <div className="lg:col-span-8 bg-[#0f1e3d] text-white rounded-xl border border-slate-800 overflow-hidden relative flex flex-col justify-between p-6 sm:p-8">
          <ResilientImage
            src="/src/assets/images/church_sanctuary_hero_1794690388207.jpg"
            alt={settings.church_name}
            className="absolute inset-0 w-full h-full object-cover opacity-25"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0f1e3d] via-[#0f1e3d]/90 to-[#4c1d95]/70" />

          <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-14 h-14 rounded-full overflow-hidden border border-[#d4af37]/60 bg-[#080f1e] shrink-0">
                <ResilientImage
                  src={settings.logo_url || '/assets/aistudio/IMG_0954_b4f1f733.jpeg'}
                  alt={settings.church_name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <div className="text-xs font-medium text-[#e5c158]">{settings.church_name}</div>
                <div className="text-xs text-slate-300">
                  {user.role} · {user.department}
                </div>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <a
                href={settings.live_stream_url || '#'}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg bg-white/10 hover:bg-white/20 text-white border border-white/20 transition-colors whitespace-nowrap"
              >
                <Radio className="w-3.5 h-3.5 text-[#e5c158]" />
                Watch Live Service
                <ExternalLink className="w-3 h-3" />
              </a>
              <button
                type="button"
                onClick={() => setGivingOpen(true)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg bg-[#d4af37] text-[#0f1e3d] hover:bg-[#e5c158] transition-colors whitespace-nowrap"
              >
                <HeartHandshake className="w-3.5 h-3.5" />
                Give Online
              </button>
            </div>
          </div>

          <div className="relative z-10 mt-8">
            <h1 className="font-display text-2xl sm:text-3xl font-semibold text-white text-balance">
              Peace and grace to you, {user.full_name}
            </h1>
            <p className="mt-2 text-sm text-slate-200 max-w-xl">
              {settings.tagline} Stay connected with upcoming worship gatherings, conferences,
              leadership meetings, and parish care updates.
            </p>
          </div>
        </div>

        {/* Daily Bible Verse & Quick Parish Info */}
        <div className="lg:col-span-4 bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 text-xs font-semibold text-[#4c1d95] dark:text-purple-300">
              <span className="inline-flex items-center gap-1.5">
                <BookOpen className="w-4 h-4" />
                Daily Scripture
              </span>
              <span className="text-slate-500 dark:text-slate-400 font-normal">
                {settings.daily_verse_ref}
              </span>
            </div>
            <blockquote className="mt-3 font-display italic text-base text-[#0f1e3d] dark:text-slate-100 leading-relaxed">
              “{settings.daily_verse_text}”
            </blockquote>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => setAboutOpen(true)}
              className="text-xs font-medium text-[#4c1d95] dark:text-purple-300 hover:underline"
            >
              Church History & Gallery
            </button>
            <button
              type="button"
              onClick={() => onNavigate('prayer')}
              className="px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              Submit Prayer Request
            </button>
          </div>
        </div>
      </div>

      {/* KPI Metrics Row */}
      {loading || !data ? (
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          {[1, 2, 3, 4, 5].map((n) => (
            <div
              key={n}
              className="h-28 rounded-xl bg-slate-200/60 dark:bg-slate-800/60 animate-pulse"
            />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          <StatCard
            label="Registered Members"
            value={data.stats.totalMembers}
            subtext={`${data.stats.totalDepartments} active departments`}
            accent="navy"
          />
          <StatCard
            label="Upcoming Events"
            value={data.stats.upcomingEventsCount}
            subtext="Services & fellowships"
            accent="purple"
          />
          <StatCard
            label="Conferences"
            value={data.stats.upcomingConferencesCount}
            subtext="Open for registration"
            accent="gold"
          />
          <StatCard
            label="Upcoming Meetings"
            value={data.stats.upcomingMeetingsCount}
            subtext="Council & ministry syncs"
            accent="navy"
          />
          <StatCard
            label="Welfare Care"
            value={
              data.stats.welfareSummary.active_cases > 0
                ? `${data.stats.welfareSummary.active_cases} Active`
                : `${data.stats.welfareSummary.total_cases} Fulfilled`
            }
            subtext={
              data.stats.financeSummary
                ? `Net Income ${formatCurrency(
                    data.stats.financeSummary.total_income - data.stats.financeSummary.total_expense
                  )}`
                : 'Compassionate care active'
            }
            accent="emerald"
          />
        </div>
      )}

      {/* Main Two-Column Content Grid */}
      {data && (
        <div className="grid lg:grid-cols-12 gap-6">
          {/* Left 7 Cols: Announcements & Weekly Activities / Events */}
          <div className="lg:col-span-7 space-y-6">
            {/* Recent Announcements */}
            <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6">
              <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
                <div>
                  <h2 className="font-display text-xl font-semibold text-[#0f1e3d] dark:text-white">
                    Recent Announcements
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Official notices from church leadership and departments
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onNavigate('announcements')}
                  className="text-xs font-medium text-[#4c1d95] dark:text-purple-300 hover:underline whitespace-nowrap"
                >
                  View All
                </button>
              </div>

              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {data.recentAnnouncements.slice(0, 4).map((ann) => (
                  <div key={ann.id} className="py-4 first:pt-4 last:pb-0 flex gap-4">
                    {ann.image_url && (
                      <div className="w-20 h-20 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-800 shrink-0 hidden sm:block">
                        <ResilientImage
                          src={ann.image_url}
                          alt={ann.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                        <span>{ann.category}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono">{formatShortDate(ann.publication_date)}</span>
                        {ann.is_pinned ? (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="font-semibold text-[#9a6b16] dark:text-[#e5c158]">
                              Pinned
                            </span>
                          </>
                        ) : null}
                        {ann.is_important ? (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="font-semibold text-[#4c1d95] dark:text-purple-300">
                              Important
                            </span>
                          </>
                        ) : null}
                      </div>
                      <h3 className="mt-1 text-sm font-semibold text-[#0f1e3d] dark:text-white">
                        {ann.title}
                      </h3>
                      <p className="mt-1 text-xs text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed">
                        {ann.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Church Calendar & Weekly Activities */}
            <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6">
              <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
                <div>
                  <h2 className="font-display text-xl font-semibold text-[#0f1e3d] dark:text-white">
                    Church Calendar & Weekly Activities
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Upcoming worship services, Bible exposition, and fellowships
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onNavigate('events')}
                  className="text-xs font-medium text-[#4c1d95] dark:text-purple-300 hover:underline whitespace-nowrap"
                >
                  Open Calendar
                </button>
              </div>

              <div className="mt-4 space-y-3">
                {data.upcomingEvents.slice(0, 4).map((ev) => (
                  <div
                    key={ev.id}
                    className="flex items-center justify-between gap-4 py-2.5 border-b last:border-b-0 border-slate-100 dark:border-slate-800"
                  >
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-[#0f1e3d] dark:text-white truncate">
                        {ev.title}
                      </div>
                      <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                        {ev.category} · {ev.location}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-xs font-mono font-medium text-[#4c1d95] dark:text-purple-300">
                        {formatShortDate(ev.event_date)}
                      </div>
                      <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                        {ev.event_date.includes('T') ? ev.event_date.split('T')[1] : 'All Day'}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right 5 Cols: Conferences, Meetings, Birthdays & Notifications */}
          <div className="lg:col-span-5 space-y-6">
            {/* Featured Upcoming Conference */}
            {data.upcomingConferences[0] && (
              <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                <div className="h-40 relative">
                  <ResilientImage
                    src={data.upcomingConferences[0].poster_url}
                    alt={data.upcomingConferences[0].title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
                  <div className="absolute bottom-3 left-4 right-4 text-white">
                    <div className="text-[11px] font-medium text-[#e5c158]">
                      Featured Conference · {formatShortDate(data.upcomingConferences[0].start_date)}
                    </div>
                    <div className="font-display text-lg font-semibold leading-snug">
                      {data.upcomingConferences[0].title}
                    </div>
                  </div>
                </div>
                <div className="p-5 flex items-center justify-between gap-3">
                  <div className="text-xs text-slate-600 dark:text-slate-300 truncate">
                    {data.upcomingConferences[0].venue}
                  </div>
                  <button
                    type="button"
                    onClick={() => onNavigate('conferences')}
                    className="px-3.5 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675] whitespace-nowrap shrink-0"
                  >
                    Register Now
                  </button>
                </div>
              </div>
            )}

            {/* Upcoming Meetings */}
            <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-5">
              <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">
                <h2 className="font-display text-lg font-semibold text-[#0f1e3d] dark:text-white">
                  Upcoming Meetings
                </h2>
                <button
                  type="button"
                  onClick={() => onNavigate('meetings')}
                  className="text-xs font-medium text-[#4c1d95] dark:text-purple-300 hover:underline"
                >
                  Schedule
                </button>
              </div>
              <div className="mt-3 space-y-3">
                {data.upcomingMeetings.slice(0, 3).map((m) => (
                  <div key={m.id} className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-[#0f1e3d] dark:text-white truncate">
                        {m.title}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        {m.meeting_type} · {m.venue}
                      </div>
                    </div>
                    <StatusTag status={m.status} />
                  </div>
                ))}
              </div>
            </div>

            {/* Birthday Celebrations */}
            <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-5">
              <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">
                <h2 className="font-display text-lg font-semibold text-[#0f1e3d] dark:text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#b48327]" />
                  Birthday Celebrations
                </h2>
                <span className="text-xs text-slate-500 dark:text-slate-400">This Month</span>
              </div>
              <div className="mt-3 space-y-3">
                {data.birthdays.slice(0, 4).map((b) => (
                  <div key={b.id} className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-full overflow-hidden bg-[#4c1d95]/10 text-[#4c1d95] dark:text-purple-300 flex items-center justify-center text-xs font-semibold shrink-0">
                        {b.avatar_url ? (
                          <ResilientImage
                            src={b.avatar_url}
                            alt={b.full_name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          b.full_name
                            .split(' ')
                            .map((n) => n[0])
                            .slice(0, 2)
                            .join('')
                        )}
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-[#0f1e3d] dark:text-white truncate">
                          {b.full_name}
                        </div>
                        <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                          {b.department}
                        </div>
                      </div>
                    </div>
                    <span className="text-xs font-mono text-[#9a6b16] dark:text-[#e5c158] shrink-0">
                      {b.date_of_birth.slice(5)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Notifications */}
            <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-5">
              <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">
                <h2 className="font-display text-lg font-semibold text-[#0f1e3d] dark:text-white">
                  Recent Notifications
                </h2>
                <button
                  type="button"
                  onClick={() => onNavigate('notifications')}
                  className="text-xs font-medium text-[#4c1d95] dark:text-purple-300 hover:underline"
                >
                  All Alerts
                </button>
              </div>
              <div className="mt-3 space-y-2.5">
                {data.notifications.slice(0, 4).map((n) => (
                  <div
                    key={n.id}
                    className="py-1.5 border-b last:border-b-0 border-slate-100 dark:border-slate-800"
                  >
                    <div className="text-xs font-semibold text-[#0f1e3d] dark:text-white">
                      {n.title}
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">
                      {n.message}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Online Church Giving Modal */}
      <Modal
        open={givingOpen}
        onClose={() => setGivingOpen(false)}
        title="Online Church Stewardship & Giving"
        subtitle="Honor the Lord with your tithes, offerings, and benevolent contributions."
      >
        <form onSubmit={handleGiveOnline} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Contribution Category
              </label>
              <select
                value={givingForm.category}
                onChange={(e) => setGivingForm({ ...givingForm, category: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              >
                <option value="Tithe">Tithe</option>
                <option value="Offering">Sunday Offering</option>
                <option value="Welfare Contribution">Welfare Benevolence Fund</option>
                <option value="Donation">Building & Missions Donation</option>
                <option value="Special Contribution">Special Thanksgiving Seed</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Amount (USD)
              </label>
              <input
                type="number"
                min="1"
                step="0.01"
                required
                value={givingForm.amount}
                onChange={(e) => setGivingForm({ ...givingForm, amount: e.target.value })}
                className="w-full px-3 py-2 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Payment Method
            </label>
            <select
              value={givingForm.payment_method}
              onChange={(e) => setGivingForm({ ...givingForm, payment_method: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
            >
              <option>Online Card</option>
              <option>Bank Transfer / ACH</option>
              <option>Mobile Wallet</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Prayer / Dedication Note (Optional)
            </label>
            <input
              type="text"
              value={givingForm.description}
              onChange={(e) => setGivingForm({ ...givingForm, description: e.target.value })}
              placeholder="e.g. Monthly faithfulness tithe"
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setGivingOpen(false)}
              className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={givingBusy}
              className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
            >
              {givingBusy ? 'Processing...' : `Confirm $${givingForm.amount || '0'} Contribution`}
            </button>
          </div>
        </form>
      </Modal>

      {/* Church History & Gallery Modal */}
      <Modal
        open={aboutOpen}
        onClose={() => setAboutOpen(false)}
        title={`About ${settings.church_name}`}
        subtitle="Heritage, leadership mission, and parish photography gallery"
        maxWidth="max-w-3xl"
      >
        <div className="space-y-6">
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            {settings.about_history}
          </p>
          <div>
            <h3 className="text-sm font-semibold text-[#0f1e3d] dark:text-white mb-3">
              Church Gallery
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {settings.gallery_images.map((img) => (
                <div
                  key={img.id}
                  className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden bg-slate-50 dark:bg-[#080f1e]"
                >
                  <div className="h-32">
                    <ResilientImage src={img.url} alt={img.title} className="w-full h-full object-cover" />
                  </div>
                  <div className="p-3">
                    <div className="text-xs font-semibold text-[#0f1e3d] dark:text-white">
                      {img.title}
                    </div>
                    <div className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
                      {img.caption}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
}
