import React, { useEffect, useState } from 'react';
import {
  Database,
  Download,
  KeyRound,
  Plus,
  Shield,
  Trash2,
  Upload,
  UserCheck,
  UserX,
} from 'lucide-react';
import { apiFetch, formatShortDate, readFileAsDataUrl } from '../lib/api';
import { Modal, ResilientImage, SectionHeader, StatusTag } from '../components/ui/ChurchUI';
import { ReportsPage } from './OperationsPages';
import {
  ALL_ROLES,
  type AppSettings,
  type NavSectionId,
  type SystemLog,
  type UserAccount,
  type UserRole,
} from '../types';

const PERMISSION_KEYS = [
  'publish_announcements',
  'manage_members',
  'access_confidential_welfare',
  'manage_conferences',
  'manage_meetings',
  'manage_finance',
  'manage_departments',
  'export_reports',
];

export default function AdminPortalPage({
  user,
  settings,
  onSettingsUpdated,
  onNavigate,
  onNotify,
}: {
  user: UserAccount;
  settings: AppSettings;
  onSettingsUpdated: (s: AppSettings) => void;
  onNavigate: (s: NavSectionId) => void;
  onNotify: (t: 'success' | 'error', m: string) => void;
}) {
  const [tab, setTab] = useState<'settings' | 'users' | 'content' | 'system' | 'reports'>('settings');
  const [form, setForm] = useState<AppSettings>(settings);
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [logs, setLogs] = useState<SystemLog[]>([]);
  const [saving, setSaving] = useState(false);

  const [userModal, setUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState<UserAccount | null>(null);
  const [userForm, setUserForm] = useState({
    full_name: '',
    email: '',
    phone: '',
    password: '',
    role: 'Church Member' as UserRole,
    department: 'General Congregation',
    status: 'Active' as 'Active' | 'Inactive' | 'Suspended',
    permissions: [] as string[],
  });

  useEffect(() => {
    setForm(settings);
  }, [settings]);

  async function loadUsersAndLogs() {
    try {
      const [u, l] = await Promise.all([
        apiFetch<UserAccount[]>('/api/members'),
        apiFetch<SystemLog[]>('/api/admin/logs'),
      ]);
      setUsers(u);
      setLogs(l);
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  useEffect(() => {
    loadUsersAndLogs();
  }, []);

  async function saveAppSettings(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      const updated = await apiFetch<AppSettings>('/api/admin/settings', {
        method: 'PUT',
        body: JSON.stringify(form),
      });
      onSettingsUpdated(updated);
      onNotify('success', 'Application settings and church branding updated across the platform.');
    } catch (err) {
      onNotify('error', (err as Error).message);
    } finally {
      setSaving(false);
    }
  }

  async function handleLogoUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const url = await readFileAsDataUrl(file, 2);
      setForm((prev) => ({ ...prev, logo_url: url }));
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  function openNewUser() {
    setEditingUser(null);
    setUserForm({
      full_name: '',
      email: '',
      phone: '',
      password: '',
      role: 'Church Member',
      department: 'General Congregation',
      status: 'Active',
      permissions: [],
    });
    setUserModal(true);
  }

  function openEditUser(u: UserAccount) {
    setEditingUser(u);
    setUserForm({
      full_name: u.full_name,
      email: u.email,
      phone: u.phone || '',
      password: '',
      role: u.role,
      department: u.department || 'General Congregation',
      status: u.status,
      permissions: u.permissions || [],
    });
    setUserModal(true);
  }

  async function saveUser(e: React.FormEvent) {
    e.preventDefault();
    try {
      if (editingUser) {
        await apiFetch(`/api/members/${editingUser.id}`, {
          method: 'PUT',
          body: JSON.stringify(userForm),
        });
        onNotify('success', `Account updated for ${userForm.full_name}.`);
      } else {
        await apiFetch('/api/members', {
          method: 'POST',
          body: JSON.stringify(userForm),
        });
        onNotify('success', `Created user account for ${userForm.full_name}.`);
      }
      setUserModal(false);
      loadUsersAndLogs();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function adminResetPassword(u: UserAccount) {
    try {
      const res = await apiFetch<{ message: string }>(`/api/members/${u.id}/reset-password`, {
        method: 'POST',
        body: JSON.stringify({ new_password: 'ChurchConnect2026!' }),
      });
      onNotify('success', `${u.full_name}: ${res.message}`);
      loadUsersAndLogs();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function changeUserStatus(u: UserAccount, status: 'Active' | 'Suspended' | 'Inactive') {
    try {
      await apiFetch(`/api/members/${u.id}`, {
        method: 'PUT',
        body: JSON.stringify({ status }),
      });
      onNotify('success', `${u.full_name} account set to ${status}.`);
      loadUsersAndLogs();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function deleteUser(u: UserAccount) {
    try {
      await apiFetch(`/api/members/${u.id}`, { method: 'DELETE' });
      onNotify('success', `Deleted account ${u.full_name}.`);
      loadUsersAndLogs();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function downloadBackup() {
    try {
      const snapshot = await apiFetch<Record<string, unknown>>('/api/admin/backup');
      const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `church_connect_backup_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      onNotify('success', 'Full database backup downloaded.');
      loadUsersAndLogs();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function handleRestoreFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const snapshot = JSON.parse(text);
      const res = await apiFetch<{ message: string }>('/api/admin/restore', {
        method: 'POST',
        body: JSON.stringify({ snapshot }),
      });
      onNotify('success', res.message);
      loadUsersAndLogs();
    } catch (err) {
      onNotify('error', `Restore failed: ${(err as Error).message}`);
    }
  }

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Administrator Control Portal"
        description="Complete authority over CHURCH CONNECT branding, user accounts, role permissions, content, system backups, and official reports."
      />

      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-lg w-fit">
        {(
          [
            ['settings', 'A. Application Settings'],
            ['users', 'B. User Management'],
            ['content', 'C. Content Management'],
            ['system', 'D. System & Backups'],
            ['reports', 'E. Reports'],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              tab === id
                ? 'bg-white dark:bg-[#1a2947] text-[#0f1e3d] dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === 'settings' && (
        <form
          onSubmit={saveAppSettings}
          className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-6"
        >
          <div className="flex flex-col sm:flex-row sm:items-center gap-5 pb-5 border-b border-slate-200 dark:border-slate-800">
            <div className="w-16 h-16 rounded-xl overflow-hidden border border-slate-300 dark:border-slate-700 bg-[#0f1e3d] shrink-0">
              <ResilientImage src={form.logo_url} alt={form.app_name} className="w-full h-full object-cover" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-[#0f1e3d] dark:text-white">
                Church Emblem & Identity
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Changes reflect immediately in the navigation sidebar, login portal, and dashboards.
              </p>
              <label className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
                <Upload className="w-3.5 h-3.5" />
                Upload Church Logo
                <input type="file" accept="image/*" className="hidden" onChange={handleLogoUpload} />
              </label>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1">Application Name</label>
              <input
                type="text"
                required
                value={form.app_name}
                onChange={(e) => setForm({ ...form, app_name: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Church Name</label>
              <input
                type="text"
                required
                value={form.church_name}
                onChange={(e) => setForm({ ...form, church_name: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-medium mb-1">Tagline</label>
              <input
                type="text"
                value={form.tagline}
                onChange={(e) => setForm({ ...form, tagline: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Contact Email</label>
              <input
                type="email"
                value={form.contact_email}
                onChange={(e) => setForm({ ...form, contact_email: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Contact Phone</label>
              <input
                type="text"
                value={form.contact_phone}
                onChange={(e) => setForm({ ...form, contact_phone: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-medium mb-1">Church Sanctuary Address</label>
              <input
                type="text"
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-medium mb-1">Church History & Mission</label>
              <textarea
                rows={3}
                value={form.about_history}
                onChange={(e) => setForm({ ...form, about_history: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Live Stream URL</label>
              <input
                type="url"
                value={form.live_stream_url}
                onChange={(e) => setForm({ ...form, live_stream_url: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Daily Bible Verse Reference</label>
              <input
                type="text"
                value={form.daily_verse_ref}
                onChange={(e) => setForm({ ...form, daily_verse_ref: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-xs font-medium mb-1">Daily Bible Verse Text</label>
              <input
                type="text"
                value={form.daily_verse_text}
                onChange={(e) => setForm({ ...form, daily_verse_text: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 pt-3 border-t border-slate-200 dark:border-slate-800">
            <div>
              <label className="block text-xs font-medium mb-1">Primary Royal Purple</label>
              <input
                type="color"
                value={form.primary_color}
                onChange={(e) => setForm({ ...form, primary_color: e.target.value })}
                className="h-9 w-full rounded border border-slate-300 dark:border-slate-700"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Accent Gold</label>
              <input
                type="color"
                value={form.accent_color}
                onChange={(e) => setForm({ ...form, accent_color: e.target.value })}
                className="h-9 w-full rounded border border-slate-300 dark:border-slate-700"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Default Theme Mode</label>
              <select
                value={form.theme_mode}
                onChange={(e) => setForm({ ...form, theme_mode: e.target.value as 'light' | 'dark' })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              >
                <option value="light">Light Mode</option>
                <option value="dark">Dark Mode</option>
              </select>
            </div>
            <div className="flex items-end">
              <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 pb-2">
                <input
                  type="checkbox"
                  checked={form.dark_mode_enabled}
                  onChange={(e) => setForm({ ...form, dark_mode_enabled: e.target.checked })}
                />
                Enable Dark Mode Toggle
              </label>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
            <input
              type="text"
              placeholder="Facebook URL"
              value={form.social_links?.facebook || ''}
              onChange={(e) =>
                setForm({ ...form, social_links: { ...form.social_links, facebook: e.target.value } })
              }
              className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            />
            <input
              type="text"
              placeholder="YouTube URL"
              value={form.social_links?.youtube || ''}
              onChange={(e) =>
                setForm({ ...form, social_links: { ...form.social_links, youtube: e.target.value } })
              }
              className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            />
            <input
              type="text"
              placeholder="Instagram URL"
              value={form.social_links?.instagram || ''}
              onChange={(e) =>
                setForm({ ...form, social_links: { ...form.social_links, instagram: e.target.value } })
              }
              className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            />
            <input
              type="text"
              placeholder="Official Website URL"
              value={form.social_links?.website || ''}
              onChange={(e) =>
                setForm({ ...form, social_links: { ...form.social_links, website: e.target.value } })
              }
              className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            />
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2.5 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
            >
              {saving ? 'Saving Settings...' : 'Save Application Settings'}
            </button>
          </div>
        </form>
      )}

      {tab === 'users' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="text-xs text-slate-600 dark:text-slate-300">
              Total registered user accounts: <strong className="font-mono">{users.length}</strong>
            </div>
            <button
              type="button"
              onClick={openNewUser}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
            >
              <Plus className="w-4 h-4" />
              Create User Account
            </button>
          </div>

          <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-[#080f1e] border-b border-slate-200 dark:border-slate-800 text-slate-500">
                  <tr>
                    <th className="py-3 px-4 font-medium">User</th>
                    <th className="py-3 px-4 font-medium">Role</th>
                    <th className="py-3 px-4 font-medium">Department</th>
                    <th className="py-3 px-4 font-medium">Status</th>
                    <th className="py-3 px-4 font-medium text-right">Admin Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {users.map((u) => (
                    <tr key={u.id}>
                      <td className="py-3 px-4">
                        <div className="font-medium text-[#0f1e3d] dark:text-white">{u.full_name}</div>
                        <div className="text-[11px] text-slate-400">
                          {u.member_code} · {u.email}
                        </div>
                      </td>
                      <td className="py-3 px-4 font-medium text-[#4c1d95] dark:text-purple-300">
                        {u.role}
                      </td>
                      <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{u.department}</td>
                      <td className="py-3 px-4">
                        <StatusTag status={u.status} />
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap space-x-1">
                        <button
                          type="button"
                          onClick={() => openEditUser(u)}
                          className="px-2.5 py-1 rounded border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          Edit / Role
                        </button>
                        <button
                          type="button"
                          onClick={() => adminResetPassword(u)}
                          className="p-1.5 rounded text-slate-500 hover:text-[#4c1d95]"
                          title="Reset password to default"
                        >
                          <KeyRound className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            changeUserStatus(u, u.status === 'Active' ? 'Suspended' : 'Active')
                          }
                          className="p-1.5 rounded text-slate-500 hover:text-amber-600"
                          title={u.status === 'Active' ? 'Suspend account' : 'Activate account'}
                        >
                          {u.status === 'Active' ? (
                            <UserX className="w-3.5 h-3.5" />
                          ) : (
                            <UserCheck className="w-3.5 h-3.5" />
                          )}
                        </button>
                        {u.id !== user.id && (
                          <button
                            type="button"
                            onClick={() => deleteUser(u)}
                            className="p-1.5 rounded text-slate-500 hover:text-red-600"
                            title="Delete user account"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {tab === 'content' && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {[
            ['Announcements & Church News', 'Publish, pin, edit, and broadcast announcements.', 'announcements'],
            ['Events & Service Calendar', 'Manage services, calendar, attendance, and visitors.', 'events'],
            ['Conferences & Summits', 'Edit conference posters, speakers, and committees.', 'conferences'],
            ['Meetings & Minutes', 'Manage agendas, minutes, and action tasks.', 'meetings'],
            ['Church Documents', 'Manage constitution, policies, and study materials.', 'documents'],
            ['Departments & Ministries', 'Assign department leaders and track ministry health.', 'departments'],
          ].map(([title, desc, target]) => (
            <div
              key={target}
              className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-5 flex flex-col justify-between space-y-4"
            >
              <div>
                <h3 className="font-display text-lg font-semibold text-[#0f1e3d] dark:text-white">
                  {title}
                </h3>
                <p className="mt-1 text-xs text-slate-600 dark:text-slate-300">{desc}</p>
              </div>
              <button
                type="button"
                onClick={() => onNavigate(target as NavSectionId)}
                className="w-fit px-3.5 py-2 text-xs font-medium rounded-lg bg-[#0f1e3d] text-white hover:bg-[#1b3366]"
              >
                Open Manager
              </button>
            </div>
          ))}
        </div>
      )}

      {tab === 'system' && (
        <div className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Security & Registration Policies */}
            <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
              <h3 className="font-display text-lg font-semibold text-[#0f1e3d] dark:text-white flex items-center gap-2">
                <Shield className="w-4 h-4 text-[#b48327]" />
                Security, Registration & Notification Policies
              </h3>
              <div className="space-y-3 text-xs">
                <label className="flex items-center justify-between gap-3">
                  <span>Allow Public Member Registration</span>
                  <input
                    type="checkbox"
                    checked={form.allow_registration}
                    onChange={(e) => setForm({ ...form, allow_registration: e.target.checked })}
                  />
                </label>
                <label className="flex items-center justify-between gap-3">
                  <span>Require Email/Phone Verification</span>
                  <input
                    type="checkbox"
                    checked={form.require_verification}
                    onChange={(e) => setForm({ ...form, require_verification: e.target.checked })}
                  />
                </label>
                <label className="flex items-center justify-between gap-3">
                  <span>Enable Email Notification Dispatch</span>
                  <input
                    type="checkbox"
                    checked={form.email_notifications_enabled}
                    onChange={(e) =>
                      setForm({ ...form, email_notifications_enabled: e.target.checked })
                    }
                  />
                </label>
              </div>
              <button
                type="button"
                onClick={saveAppSettings}
                className="px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white"
              >
                Apply Security Settings
              </button>
            </div>

            {/* Database Backup & Restore */}
            <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
              <h3 className="font-display text-lg font-semibold text-[#0f1e3d] dark:text-white flex items-center gap-2">
                <Database className="w-4 h-4 text-[#4c1d95] dark:text-purple-300" />
                Database Backup & Restore
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300">
                Export an archive of all church tables (members, finances, welfare, conferences, meetings, events) or verify/restore from a snapshot.
              </p>
              <div className="flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={downloadBackup}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#0f1e3d] text-white hover:bg-[#1a2f5c]"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download Full Backup (.json)
                </button>
                <label className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
                  <Upload className="w-3.5 h-3.5" />
                  Restore from Backup
                  <input type="file" accept=".json" className="hidden" onChange={handleRestoreFile} />
                </label>
              </div>
            </div>
          </div>

          {/* System Activity Logs */}
          <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold text-[#0f1e3d] dark:text-white">
                System Audit & Activity Logs
              </h3>
              <span className="text-xs font-mono text-slate-500">{logs.length} recent events</span>
            </div>
            <div className="overflow-x-auto max-h-96">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-[#080f1e] border-b border-slate-200 dark:border-slate-800 text-slate-500">
                  <tr>
                    <th className="py-2.5 px-4 font-medium">Timestamp</th>
                    <th className="py-2.5 px-4 font-medium">User</th>
                    <th className="py-2.5 px-4 font-medium">Module</th>
                    <th className="py-2.5 px-4 font-medium">Action</th>
                    <th className="py-2.5 px-4 font-medium">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {logs.map((l) => (
                    <tr key={l.id}>
                      <td className="py-2.5 px-4 font-mono text-[11px] text-slate-500">
                        {formatShortDate(l.created_at)}
                      </td>
                      <td className="py-2.5 px-4 font-medium text-[#0f1e3d] dark:text-white">
                        {l.user_name}
                      </td>
                      <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300">{l.module}</td>
                      <td className="py-2.5 px-4 font-mono text-[11px] text-[#4c1d95] dark:text-purple-300">
                        {l.action}
                      </td>
                      <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300">{l.details}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {tab === 'reports' && <ReportsPage onNotify={onNotify} />}

      {/* Create / Edit User Account Modal */}
      <Modal
        open={userModal}
        onClose={() => setUserModal(false)}
        title={editingUser ? `Edit User Account · ${editingUser.full_name}` : 'Create New User Account'}
      >
        <form onSubmit={saveUser} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              type="text"
              required
              placeholder="Full Name"
              value={userForm.full_name}
              onChange={(e) => setUserForm({ ...userForm, full_name: e.target.value })}
              className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            />
            <input
              type="email"
              required
              placeholder="Email Address"
              value={userForm.email}
              onChange={(e) => setUserForm({ ...userForm, email: e.target.value })}
              className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            />
            <select
              value={userForm.role}
              onChange={(e) => setUserForm({ ...userForm, role: e.target.value as UserRole })}
              className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            >
              {ALL_ROLES.map((r) => (
                <option key={r}>{r}</option>
              ))}
            </select>
            <select
              value={userForm.status}
              onChange={(e) =>
                setUserForm({ ...userForm, status: e.target.value as 'Active' | 'Inactive' | 'Suspended' })
              }
              className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            >
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
              <option value="Suspended">Suspended</option>
            </select>
          </div>
          {!editingUser && (
            <input
              type="password"
              placeholder="Initial Password (default: ChurchConnect2026!)"
              value={userForm.password}
              onChange={(e) => setUserForm({ ...userForm, password: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            />
          )}
          <div>
            <div className="text-xs font-medium mb-2">Granular Permission Overrides</div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {PERMISSION_KEYS.map((perm) => (
                <label key={perm} className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={userForm.permissions.includes(perm)}
                    onChange={(e) => {
                      const next = e.target.checked
                        ? [...userForm.permissions, perm]
                        : userForm.permissions.filter((p) => p !== perm);
                      setUserForm({ ...userForm, permissions: next });
                    }}
                  />
                  <span className="font-mono text-[11px]">{perm}</span>
                </label>
              ))}
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setUserModal(false)}
              className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700"
            >
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white">
              {editingUser ? 'Save Account' : 'Create Account'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
