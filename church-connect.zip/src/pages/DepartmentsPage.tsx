import React, { useEffect, useState } from 'react';
import {
  Plus,
  UserPlus,
  Users,
} from 'lucide-react';
import { apiFetch, formatCurrency, formatShortDate } from '../lib/api';
import { Modal, SectionHeader, StatCard } from '../components/ui/ChurchUI';
import type {
  Department,
  DepartmentAnnouncement,
  DepartmentMember,
  UserAccount,
} from '../types';

interface EnrichedDepartment extends Department {
  members: DepartmentMember[];
  announcements: DepartmentAnnouncement[];
}

export default function DepartmentsPage({
  user,
  onNotify,
}: {
  user: UserAccount;
  onNotify: (type: 'success' | 'error', message: string) => void;
}) {
  const [departments, setDepartments] = useState<EnrichedDepartment[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<EnrichedDepartment | null>(null);
  const [createOpen, setCreateOpen] = useState(false);

  const [newDept, setNewDept] = useState({
    name: '',
    description: '',
    leader_name: '',
    meeting_schedule: '',
    budget_allocation: '5000',
  });

  const [deptEdit, setDeptEdit] = useState({
    leader_name: '',
    meeting_schedule: '',
    budget_allocation: '0',
    performance_notes: '',
  });
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberRole, setNewMemberRole] = useState('Member');
  const [deptAnn, setDeptAnn] = useState({ title: '', content: '' });

  const canCreate = ['Super Administrator', 'Church Administrator', 'Senior Pastor', 'Church Secretary'].includes(user.role);
  const canManageDept = canCreate || ['Assistant Pastor', 'Department Leader'].includes(user.role);

  async function loadDepartments() {
    try {
      const res = await apiFetch<EnrichedDepartment[]>('/api/departments');
      setDepartments(res);
      if (selected) {
        const refreshed = res.find((d) => d.id === selected.id) || null;
        setSelected(refreshed);
      }
    } catch (err) {
      onNotify('error', (err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadDepartments();
  }, []);

  function openDept(d: EnrichedDepartment) {
    setSelected(d);
    setDeptEdit({
      leader_name: d.leader_name,
      meeting_schedule: d.meeting_schedule,
      budget_allocation: String(d.budget_allocation),
      performance_notes: d.performance_notes,
    });
  }

  async function handleCreateDept(e: React.FormEvent) {
    e.preventDefault();
    try {
      await apiFetch('/api/departments', {
        method: 'POST',
        body: JSON.stringify(newDept),
      });
      onNotify('success', `${newDept.name} registered.`);
      setCreateOpen(false);
      setNewDept({ name: '', description: '', leader_name: '', meeting_schedule: '', budget_allocation: '5000' });
      loadDepartments();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function handleUpdateDept(e: React.FormEvent) {
    e.preventDefault();
    if (!selected) return;
    try {
      await apiFetch(`/api/departments/${selected.id}`, {
        method: 'PUT',
        body: JSON.stringify(deptEdit),
      });
      onNotify('success', `${selected.name} details updated.`);
      loadDepartments();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function handleAddMember(e: React.FormEvent) {
    e.preventDefault();
    if (!selected || !newMemberName.trim()) return;
    try {
      await apiFetch(`/api/departments/${selected.id}/members`, {
        method: 'POST',
        body: JSON.stringify({
          user_id: Math.floor(Date.now() / 1000),
          member_name: newMemberName.trim(),
          role_in_dept: newMemberRole,
        }),
      });
      setNewMemberName('');
      onNotify('success', 'Member added to department roster.');
      loadDepartments();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function handleJoinSelf(dept: EnrichedDepartment) {
    try {
      await apiFetch(`/api/departments/${dept.id}/members`, {
        method: 'POST',
        body: JSON.stringify({
          user_id: user.id,
          member_name: user.full_name,
          role_in_dept: 'Member',
        }),
      });
      onNotify('success', `You have joined ${dept.name}.`);
      loadDepartments();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function handleDeptAnn(e: React.FormEvent) {
    e.preventDefault();
    if (!selected) return;
    try {
      await apiFetch(`/api/departments/${selected.id}/announcements`, {
        method: 'POST',
        body: JSON.stringify(deptAnn),
      });
      setDeptAnn({ title: '', content: '' });
      onNotify('success', 'Department announcement posted.');
      loadDepartments();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  const totalActivities = departments.reduce((s, d) => s + (d.activities_count || 0), 0);

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Church Departments & Ministries"
        description="Coordinate ministry leaders, department rosters, weekly rehearsals, departmental announcements, and ministry performance."
        actions={
          canCreate && (
            <button
              type="button"
              onClick={() => setCreateOpen(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
            >
              <Plus className="w-4 h-4" />
              Register Department
            </button>
          )
        }
      />

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <StatCard label="Active Ministries" value={departments.length} accent="purple" />
        <StatCard label="Total Ministry Activities" value={totalActivities} accent="gold" />
        <StatCard
          label="Enrolled Volunteers"
          value={departments.reduce((s, d) => s + (d.members?.length || 0), 0)}
          accent="navy"
        />
        <StatCard
          label="Total Dept. Budgets"
          value={formatCurrency(departments.reduce((s, d) => s + Number(d.budget_allocation || 0), 0))}
          accent="emerald"
        />
      </div>

      {loading ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <div key={n} className="h-48 rounded-xl bg-slate-200/60 dark:bg-slate-800/60 animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {departments.map((d) => {
            const isMember = d.members?.some((m) => m.user_id === user.id);
            return (
              <div
                key={d.id}
                className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-5 flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <h2 className="font-display text-lg font-semibold text-[#0f1e3d] dark:text-white">
                      {d.name}
                    </h2>
                    <span className="font-mono text-xs font-medium text-[#4c1d95] dark:text-purple-300 shrink-0">
                      {d.members?.length || 0} members
                    </span>
                  </div>
                  <p className="mt-1.5 text-xs text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed">
                    {d.description}
                  </p>
                  <div className="mt-3 space-y-1 text-xs text-slate-500 dark:text-slate-400">
                    <div>
                      <span className="font-medium text-slate-700 dark:text-slate-200">Leader:</span>{' '}
                      {d.leader_name || 'Unassigned'}
                    </div>
                    <div>
                      <span className="font-medium text-slate-700 dark:text-slate-200">Schedule:</span>{' '}
                      {d.meeting_schedule || 'Flexible'}
                    </div>
                    <div>
                      <span className="font-medium text-slate-700 dark:text-slate-200">Activities:</span>{' '}
                      <span className="font-mono">{d.activities_count}</span> completed
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => openDept(d)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                  >
                    <Users className="w-3.5 h-3.5" />
                    Workspace
                  </button>
                  {!isMember ? (
                    <button
                      type="button"
                      onClick={() => handleJoinSelf(d)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      Join
                    </button>
                  ) : (
                    <span className="text-xs font-medium text-emerald-700 dark:text-emerald-400">
                      Enrolled
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Department Workspace Modal */}
      <Modal
        open={Boolean(selected)}
        onClose={() => setSelected(null)}
        title={selected?.name || ''}
        subtitle={selected?.description}
        maxWidth="max-w-3xl"
      >
        {selected && (
          <div className="space-y-6">
            {canManageDept && (
              <form onSubmit={handleUpdateDept} className="space-y-3 pb-4 border-b border-slate-200 dark:border-slate-800">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-medium mb-1">Department Leader</label>
                    <input
                      type="text"
                      value={deptEdit.leader_name}
                      onChange={(e) => setDeptEdit({ ...deptEdit, leader_name: e.target.value })}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium mb-1">Meeting Schedule</label>
                    <input
                      type="text"
                      value={deptEdit.meeting_schedule}
                      onChange={(e) => setDeptEdit({ ...deptEdit, meeting_schedule: e.target.value })}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium mb-1">Annual Budget ($)</label>
                    <input
                      type="number"
                      value={deptEdit.budget_allocation}
                      onChange={(e) => setDeptEdit({ ...deptEdit, budget_allocation: e.target.value })}
                      className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium mb-1">Performance & Ministry Report Notes</label>
                  <textarea
                    rows={2}
                    value={deptEdit.performance_notes}
                    onChange={(e) => setDeptEdit({ ...deptEdit, performance_notes: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
                  />
                </div>
                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-3.5 py-1.5 text-xs font-medium rounded-lg bg-[#0f1e3d] text-white"
                  >
                    Save Department Settings
                  </button>
                </div>
              </form>
            )}

            {/* Members */}
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">
                Department Roster ({selected.members.length})
              </h3>
              <div className="grid sm:grid-cols-2 gap-2">
                {selected.members.map((m) => (
                  <div
                    key={m.id}
                    className="flex items-center justify-between px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 text-xs"
                  >
                    <span className="font-medium text-[#0f1e3d] dark:text-white">{m.member_name}</span>
                    <span className="text-slate-500">{m.role_in_dept}</span>
                  </div>
                ))}
              </div>
              {canManageDept && (
                <form onSubmit={handleAddMember} className="flex gap-2 mt-3">
                  <input
                    type="text"
                    required
                    value={newMemberName}
                    onChange={(e) => setNewMemberName(e.target.value)}
                    placeholder="Add member full name..."
                    className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
                  />
                  <input
                    type="text"
                    value={newMemberRole}
                    onChange={(e) => setNewMemberRole(e.target.value)}
                    placeholder="Role (e.g. Vocalist)"
                    className="w-36 px-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1.5 text-xs font-medium rounded-lg bg-[#4c1d95] text-white"
                  >
                    Add
                  </button>
                </form>
              )}
            </div>

            {/* Department Announcements */}
            <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-3">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Department Announcements
              </h3>
              {selected.announcements.map((a) => (
                <div
                  key={a.id}
                  className="p-3 rounded-lg bg-slate-50 dark:bg-[#080f1e] border border-slate-200 dark:border-slate-800 text-xs"
                >
                  <div className="flex justify-between font-semibold text-[#0f1e3d] dark:text-white">
                    <span>{a.title}</span>
                    <span className="font-mono font-normal text-slate-400">
                      {formatShortDate(a.created_at)}
                    </span>
                  </div>
                  <p className="mt-1 text-slate-600 dark:text-slate-300">{a.content}</p>
                </div>
              ))}
              {canManageDept && (
                <form onSubmit={handleDeptAnn} className="space-y-2 pt-2">
                  <input
                    type="text"
                    required
                    value={deptAnn.title}
                    onChange={(e) => setDeptAnn({ ...deptAnn, title: e.target.value })}
                    placeholder="Department notice title..."
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
                  />
                  <div className="flex gap-2">
                    <input
                      type="text"
                      required
                      value={deptAnn.content}
                      onChange={(e) => setDeptAnn({ ...deptAnn, content: e.target.value })}
                      placeholder="Announcement details..."
                      className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
                    />
                    <button
                      type="submit"
                      className="px-3.5 py-1.5 text-xs font-medium rounded-lg bg-[#4c1d95] text-white"
                    >
                      Post
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        )}
      </Modal>

      {/* Create Department Modal */}
      <Modal open={createOpen} onClose={() => setCreateOpen(false)} title="Register New Department">
        <form onSubmit={handleCreateDept} className="space-y-4">
          <input
            type="text"
            required
            placeholder="Department Name"
            value={newDept.name}
            onChange={(e) => setNewDept({ ...newDept, name: e.target.value })}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
          />
          <textarea
            rows={2}
            placeholder="Ministry Description"
            value={newDept.description}
            onChange={(e) => setNewDept({ ...newDept, description: e.target.value })}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
          />
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <input
              type="text"
              placeholder="Leader Name"
              value={newDept.leader_name}
              onChange={(e) => setNewDept({ ...newDept, leader_name: e.target.value })}
              className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            />
            <input
              type="text"
              placeholder="Meeting Schedule"
              value={newDept.meeting_schedule}
              onChange={(e) => setNewDept({ ...newDept, meeting_schedule: e.target.value })}
              className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            />
            <input
              type="number"
              placeholder="Budget ($)"
              value={newDept.budget_allocation}
              onChange={(e) => setNewDept({ ...newDept, budget_allocation: e.target.value })}
              className="px-3 py-2 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            />
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setCreateOpen(false)}
              className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700"
            >
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white">
              Create Department
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
