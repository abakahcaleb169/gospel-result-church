import React, { useEffect, useState } from 'react';
import {
  Check,
  CheckCheck,
  Download,
  FileText,
  KeyRound,
  Mail,
  Moon,
  Plus,
  Search,
  Send,
  ShieldCheck,
  Sun,
  Upload,
} from 'lucide-react';
import {
  apiFetch,
  exportToExcel,
  exportToPdf,
  formatCurrency,
  formatShortDate,
  readFileAsDataUrl,
} from '../lib/api';
import {
  EmptyState,
  Modal,
  ResilientImage,
  SectionHeader,
  StatusTag,
} from '../components/ui/ChurchUI';
import type {
  ChurchDocument,
  ChurchMessage,
  NavSectionId,
  NotificationItem,
  PrayerRequest,
  UserAccount,
} from '../types';

// ============================================================================
// NOTIFICATIONS PAGE
// ============================================================================

export function NotificationsPage({
  user,
  onNavigate,
  onNotify,
  onRefreshUnread,
}: {
  user: UserAccount;
  onNavigate: (s: NavSectionId) => void;
  onNotify: (t: 'success' | 'error', m: string) => void;
  onRefreshUnread: () => void;
}) {
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [composeOpen, setComposeOpen] = useState(false);
  const [form, setForm] = useState({ title: '', message: '', type: 'Admin', link_page: 'dashboard' });

  const canBroadcast = ['Super Administrator', 'Church Administrator', 'Senior Pastor', 'Church Secretary'].includes(
    user.role
  );

  async function load() {
    try {
      const res = await apiFetch<NotificationItem[]>('/api/notifications');
      setItems(res);
      onRefreshUnread();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function markRead(id: number) {
    await apiFetch(`/api/notifications/${id}/read`, { method: 'PUT' });
    load();
  }

  async function markAll() {
    await apiFetch('/api/notifications/read-all', { method: 'PUT' });
    onNotify('success', 'All notifications marked as read.');
    load();
  }

  async function sendNotice(e: React.FormEvent) {
    e.preventDefault();
    try {
      await apiFetch('/api/notifications', { method: 'POST', body: JSON.stringify(form) });
      onNotify('success', 'Broadcast notification sent to all members.');
      setComposeOpen(false);
      setForm({ title: '', message: '', type: 'Admin', link_page: 'dashboard' });
      load();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Notification Center"
        description="In-app and email-dispatched alerts for church announcements, services, conferences, meetings, and welfare updates."
        actions={
          <>
            <button
              type="button"
              onClick={markAll}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              Mark All Read
            </button>
            {canBroadcast && (
              <button
                type="button"
                onClick={() => setComposeOpen(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
              >
                <Plus className="w-4 h-4" />
                Send Broadcast Notice
              </button>
            )}
          </>
        }
      />

      {items.length === 0 ? (
        <EmptyState title="No notifications yet" description="New alerts will appear here automatically." />
      ) : (
        <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl divide-y divide-slate-100 dark:divide-slate-800">
          {items.map((n) => (
            <div
              key={n.id}
              className={`p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                n.is_read ? 'opacity-75' : 'bg-purple-50/30 dark:bg-purple-950/15'
              }`}
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                  <span className="font-semibold text-[#4c1d95] dark:text-purple-300">{n.type}</span>
                  <span>·</span>
                  <span className="font-mono">{formatShortDate(n.created_at)}</span>
                  {n.email_dispatched && (
                    <>
                      <span>·</span>
                      <span>Email Dispatched</span>
                    </>
                  )}
                </div>
                <div className="text-sm font-semibold text-[#0f1e3d] dark:text-white">{n.title}</div>
                <p className="text-xs text-slate-600 dark:text-slate-300">{n.message}</p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => onNavigate((n.link_page as NavSectionId) || 'dashboard')}
                  className="px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700"
                >
                  Open
                </button>
                {!n.is_read && (
                  <button
                    type="button"
                    onClick={() => markRead(n.id)}
                    className="px-3 py-1.5 text-xs font-medium rounded-lg bg-[#0f1e3d] text-white"
                  >
                    Mark Read
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal open={composeOpen} onClose={() => setComposeOpen(false)} title="Broadcast Church Notification">
        <form onSubmit={sendNotice} className="space-y-4">
          <input
            type="text"
            required
            placeholder="Notification Title"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
          />
          <textarea
            rows={3}
            required
            placeholder="Message body..."
            value={form.message}
            onChange={(e) => setForm({ ...form, message: e.target.value })}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
          />
          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => setComposeOpen(false)} className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700">
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white">
              Dispatch Now
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

// ============================================================================
// DOCUMENTS & RESOURCES PAGE
// ============================================================================

export function DocumentsPage({
  user,
  onNotify,
}: {
  user: UserAccount;
  onNotify: (t: 'success' | 'error', m: string) => void;
}) {
  const [docs, setDocs] = useState<ChurchDocument[]>([]);
  const [search, setSearch] = useState('');
  const [cat, setCat] = useState('All');
  const [uploadOpen, setUploadOpen] = useState(false);

  const [form, setForm] = useState({
    title: '',
    category: 'Church Constitution',
    description: '',
    access_level: 'All Members',
    file_name: '',
    file_size: '',
    mime_type: '',
    file_data: '',
  });

  const canUpload = user.role !== 'Church Member';

  async function load() {
    try {
      const res = await apiFetch<ChurchDocument[]>('/api/documents');
      setDocs(res);
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await readFileAsDataUrl(file, 4);
      setForm((prev) => ({
        ...prev,
        file_name: file.name,
        file_size: `${Math.max(1, Math.round(file.size / 1024))} KB`,
        mime_type: file.type || 'application/octet-stream',
        file_data: dataUrl,
      }));
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function handleUpload(e: React.FormEvent) {
    e.preventDefault();
    try {
      await apiFetch('/api/documents', { method: 'POST', body: JSON.stringify(form) });
      onNotify('success', 'Document uploaded and shared.');
      setUploadOpen(false);
      load();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  const categories = [
    'All',
    'Church Constitution',
    'Meeting Minutes',
    'Church Policy',
    'Conference Document',
    'Report',
    'Programme',
    'Church Notice',
    'Bible Study Material',
  ];

  const filtered = docs.filter((d) => {
    const okCat = cat === 'All' || d.category === cat;
    const okQ =
      !search.trim() ||
      d.title.toLowerCase().includes(search.toLowerCase()) ||
      d.description.toLowerCase().includes(search.toLowerCase());
    return okCat && okQ;
  });

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Church Documents & Study Resources"
        description="Access the church constitution, policies, conference programmes, meeting minutes, and Bible study guides."
        actions={
          canUpload && (
            <button
              type="button"
              onClick={() => setUploadOpen(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
            >
              <Upload className="w-4 h-4" />
              Upload Document
            </button>
          )
        }
      />

      <div className="flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search documents..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111d36]"
          />
        </div>
        <select
          value={cat}
          onChange={(e) => setCat(e.target.value)}
          className="px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111d36]"
        >
          {categories.map((c) => (
            <option key={c}>{c}</option>
          ))}
        </select>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {filtered.map((d) => (
          <div
            key={d.id}
            className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-5 flex items-start justify-between gap-4"
          >
            <div className="space-y-1.5 min-w-0">
              <div className="text-xs text-slate-500 dark:text-slate-400">
                <span className="font-medium text-[#4c1d95] dark:text-purple-300">{d.category}</span>
                {' · '}
                <span>{d.access_level}</span>
                {' · '}
                <span className="font-mono">{d.file_size}</span>
              </div>
              <h3 className="text-sm font-semibold text-[#0f1e3d] dark:text-white flex items-center gap-2">
                <FileText className="w-4 h-4 text-[#b48327] shrink-0" />
                <span className="truncate">{d.title}</span>
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300">{d.description}</p>
              <div className="text-[11px] text-slate-400">
                Uploaded by {d.uploaded_by} · {formatShortDate(d.created_at)}
              </div>
            </div>
            <a
              href={d.file_data}
              download={d.file_name}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              Download
            </a>
          </div>
        ))}
      </div>

      <Modal open={uploadOpen} onClose={() => setUploadOpen(false)} title="Upload Church Document">
        <form onSubmit={handleUpload} className="space-y-4">
          <input
            type="text"
            required
            placeholder="Document Title"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <select
              value={form.category}
              onChange={(e) => setForm({ ...form, category: e.target.value })}
              className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            >
              {categories.slice(1).map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
            <select
              value={form.access_level}
              onChange={(e) => setForm({ ...form, access_level: e.target.value })}
              className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            >
              <option>All Members</option>
              <option>Leaders</option>
              <option>Pastors & Admins</option>
            </select>
          </div>
          <textarea
            rows={2}
            placeholder="Short description"
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
          />
          <label className="inline-flex items-center gap-2 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 cursor-pointer">
            <Upload className="w-3.5 h-3.5" />
            {form.file_name ? `Selected: ${form.file_name}` : 'Select Document File (PDF, DOCX, TXT, Image)'}
            <input type="file" required className="hidden" onChange={handleFileSelect} />
          </label>
          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => setUploadOpen(false)} className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700">
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white">
              Upload & Share
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

// ============================================================================
// COMMUNICATION & MESSAGING PAGE
// ============================================================================

export function MessagesPage({
  user,
  onNotify,
}: {
  user: UserAccount;
  onNotify: (t: 'success' | 'error', m: string) => void;
}) {
  const [messages, setMessages] = useState<ChurchMessage[]>([]);
  const [members, setMembers] = useState<UserAccount[]>([]);
  const [channelFilter, setChannelFilter] = useState('All');
  const [composeOpen, setComposeOpen] = useState(false);

  const [form, setForm] = useState({
    channel: 'Direct',
    recipient_id: '',
    department: user.department,
    subject: '',
    body: '',
  });

  async function load() {
    try {
      const [msgs, mems] = await Promise.all([
        apiFetch<ChurchMessage[]>('/api/messages'),
        apiFetch<UserAccount[]>('/api/members'),
      ]);
      setMessages(msgs);
      setMembers(mems);
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function sendMessage(e: React.FormEvent) {
    e.preventDefault();
    const rec = members.find((m) => String(m.id) === form.recipient_id);
    try {
      await apiFetch('/api/messages', {
        method: 'POST',
        body: JSON.stringify({
          ...form,
          recipient_id: form.channel === 'Direct' && form.recipient_id ? Number(form.recipient_id) : null,
          recipient_name:
            form.channel === 'Direct'
              ? rec?.full_name || 'Member'
              : form.channel === 'Department'
              ? form.department
              : form.channel,
        }),
      });
      onNotify('success', 'Message sent successfully.');
      setComposeOpen(false);
      setForm({ channel: 'Direct', recipient_id: '', department: user.department, subject: '', body: '' });
      load();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  const filtered = messages.filter(
    (m) => channelFilter === 'All' || m.channel === channelFilter
  );

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Internal Communication & Messaging"
        description="Direct pastoral/admin messaging, department group threads, and leadership briefs."
        actions={
          <button
            type="button"
            onClick={() => setComposeOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
          >
            <Send className="w-3.5 h-3.5" />
            Compose Message
          </button>
        }
      />

      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-lg w-fit">
        {['All', 'Direct', 'Department', 'Leadership', 'Pastoral', 'Broadcast'].map((ch) => (
          <button
            key={ch}
            type="button"
            onClick={() => setChannelFilter(ch)}
            className={`px-3 py-1.5 text-xs font-medium rounded-md ${
              channelFilter === ch
                ? 'bg-white dark:bg-[#1a2947] text-[#0f1e3d] dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {ch}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {filtered.map((m) => (
          <div
            key={m.id}
            className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-2"
          >
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
              <div>
                <span className="font-semibold text-[#4c1d95] dark:text-purple-300">{m.channel}</span>
                {' · '}
                <span>
                  From <strong className="text-[#0f1e3d] dark:text-white">{m.sender_name}</strong> ({m.sender_role})
                </span>
                {' → '}
                <span>{m.recipient_name}</span>
              </div>
              <span className="font-mono">{formatShortDate(m.created_at)}</span>
            </div>
            <h3 className="text-sm font-semibold text-[#0f1e3d] dark:text-white">{m.subject}</h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed whitespace-pre-line">
              {m.body}
            </p>
          </div>
        ))}
      </div>

      <Modal open={composeOpen} onClose={() => setComposeOpen(false)} title="Compose Church Message">
        <form onSubmit={sendMessage} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium mb-1">Channel</label>
              <select
                value={form.channel}
                onChange={(e) => setForm({ ...form, channel: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              >
                <option value="Direct">Direct Member Message</option>
                <option value="Department">Department Group</option>
                {user.role !== 'Church Member' && <option value="Leadership">Leadership Channel</option>}
                {['Super Administrator', 'Church Administrator', 'Senior Pastor', 'Assistant Pastor'].includes(user.role) && (
                  <option value="Broadcast">Congregation Broadcast</option>
                )}
              </select>
            </div>
            {form.channel === 'Direct' ? (
              <div>
                <label className="block text-xs font-medium mb-1">Recipient</label>
                <select
                  required
                  value={form.recipient_id}
                  onChange={(e) => setForm({ ...form, recipient_id: e.target.value })}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
                >
                  <option value="">Select member...</option>
                  {members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.full_name} ({m.role})
                    </option>
                  ))}
                </select>
              </div>
            ) : form.channel === 'Department' ? (
              <div>
                <label className="block text-xs font-medium mb-1">Department</label>
                <input
                  type="text"
                  value={form.department}
                  onChange={(e) => setForm({ ...form, department: e.target.value })}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
                />
              </div>
            ) : null}
          </div>
          <input
            type="text"
            required
            placeholder="Subject"
            value={form.subject}
            onChange={(e) => setForm({ ...form, subject: e.target.value })}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
          />
          <textarea
            rows={4}
            required
            placeholder="Write your message..."
            value={form.body}
            onChange={(e) => setForm({ ...form, body: e.target.value })}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
          />
          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => setComposeOpen(false)} className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700">
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white">
              Send Message
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

// ============================================================================
// PRAYER REQUESTS, TESTIMONIES & COUNSELLING PAGE
// ============================================================================

export function PrayerRequestsPage({
  user,
  onNotify,
}: {
  user: UserAccount;
  onNotify: (t: 'success' | 'error', m: string) => void;
}) {
  const [items, setItems] = useState<PrayerRequest[]>([]);
  const [catTab, setCatTab] = useState<'All' | 'Prayer Request' | 'Testimony' | 'Counselling Request'>('All');
  const [open, setOpen] = useState(false);
  const [replyItem, setReplyItem] = useState<PrayerRequest | null>(null);
  const [replyStatus, setReplyStatus] = useState('Praying');
  const [replyText, setReplyText] = useState('');

  const [form, setForm] = useState({
    category: 'Prayer Request',
    title: '',
    details: '',
    is_confidential: false,
    preferred_date: '',
  });

  const canRespond = [
    'Super Administrator',
    'Church Administrator',
    'Senior Pastor',
    'Assistant Pastor',
    'Welfare Officer',
  ].includes(user.role);

  async function load() {
    try {
      const res = await apiFetch<PrayerRequest[]>('/api/prayers');
      setItems(res);
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function submitPrayer(e: React.FormEvent) {
    e.preventDefault();
    try {
      await apiFetch('/api/prayers', { method: 'POST', body: JSON.stringify(form) });
      onNotify('success', `${form.category} submitted to pastoral care.`);
      setOpen(false);
      setForm({ category: 'Prayer Request', title: '', details: '', is_confidential: false, preferred_date: '' });
      load();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function submitResponse(e: React.FormEvent) {
    e.preventDefault();
    if (!replyItem) return;
    try {
      await apiFetch(`/api/prayers/${replyItem.id}`, {
        method: 'PUT',
        body: JSON.stringify({ status: replyStatus, pastor_response: replyText }),
      });
      onNotify('success', 'Pastoral response saved.');
      setReplyItem(null);
      load();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  const filtered = items.filter((p) => catTab === 'All' || p.category === catTab);

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Prayer Requests, Testimonies & Counselling"
        description="Submit prayer needs, share answered-prayer testimonies, and book confidential pastoral counselling appointments."
        actions={
          <button
            type="button"
            onClick={() => setOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
          >
            <Plus className="w-4 h-4" />
            New Submission
          </button>
        }
      />

      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-lg w-fit">
        {(['All', 'Prayer Request', 'Testimony', 'Counselling Request'] as const).map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => setCatTab(c)}
            className={`px-3 py-1.5 text-xs font-medium rounded-md ${
              catTab === c
                ? 'bg-white dark:bg-[#1a2947] text-[#0f1e3d] dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {filtered.map((p) => (
          <div
            key={p.id}
            className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-5 flex flex-col justify-between space-y-3"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-medium text-[#4c1d95] dark:text-purple-300">
                  {p.category} · {p.requester_name}
                </span>
                <StatusTag status={p.status} />
              </div>
              <h3 className="font-display text-base font-semibold text-[#0f1e3d] dark:text-white">
                {p.title}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {p.details}
              </p>
              {p.preferred_date && (
                <div className="text-xs font-mono text-[#9a6b16] dark:text-[#e5c158]">
                  Requested Date: {formatShortDate(p.preferred_date)}
                </div>
              )}
              {p.pastor_response && (
                <div className="p-3 rounded-lg bg-slate-50 dark:bg-[#080f1e] border border-slate-200 dark:border-slate-800 text-xs">
                  <span className="font-semibold text-[#0f1e3d] dark:text-white">Pastoral Note: </span>
                  {p.pastor_response}
                </div>
              )}
            </div>
            {canRespond && (
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-end">
                <button
                  type="button"
                  onClick={() => {
                    setReplyItem(p);
                    setReplyStatus(p.status);
                    setReplyText(p.pastor_response || '');
                  }}
                  className="px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700"
                >
                  Update & Respond
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title="Submit Prayer, Testimony, or Counselling Request">
        <form onSubmit={submitPrayer} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <select
              value={form.category}
              onChange={(e) => setForm({ ...form, category: e.target.value })}
              className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            >
              <option>Prayer Request</option>
              <option>Testimony</option>
              <option>Counselling Request</option>
            </select>
            {form.category === 'Counselling Request' && (
              <input
                type="date"
                value={form.preferred_date}
                onChange={(e) => setForm({ ...form, preferred_date: e.target.value })}
                className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            )}
          </div>
          <input
            type="text"
            required
            placeholder="Title / Subject"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
          />
          <textarea
            rows={4}
            required
            placeholder="Share details..."
            value={form.details}
            onChange={(e) => setForm({ ...form, details: e.target.value })}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
          />
          <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300">
            <input
              type="checkbox"
              checked={form.is_confidential}
              onChange={(e) => setForm({ ...form, is_confidential: e.target.checked })}
            />
            Keep strictly confidential (Pastors & Welfare Officer only)
          </label>
          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => setOpen(false)} className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700">
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white">
              Submit
            </button>
          </div>
        </form>
      </Modal>

      <Modal open={Boolean(replyItem)} onClose={() => setReplyItem(null)} title="Pastoral Response">
        <form onSubmit={submitResponse} className="space-y-4">
          <select
            value={replyStatus}
            onChange={(e) => setReplyStatus(e.target.value)}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
          >
            <option>Submitted</option>
            <option>Praying</option>
            <option>Scheduled</option>
            <option>Answered</option>
            <option>Completed</option>
          </select>
          <textarea
            rows={3}
            placeholder="Pastoral note or appointment confirmation..."
            value={replyText}
            onChange={(e) => setReplyText(e.target.value)}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
          />
          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => setReplyItem(null)} className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700">
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white">
              Save Response
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

// ============================================================================
// REPORTS CENTER PAGE (PDF & EXCEL EXPORTS)
// ============================================================================

export function ReportsPage({
  onNotify,
}: {
  onNotify: (t: 'success' | 'error', m: string) => void;
}) {
  const [summary, setSummary] = useState<Record<string, Array<Record<string, unknown>>> | null>(null);

  useEffect(() => {
    apiFetch<Record<string, Array<Record<string, unknown>>>>('/api/reports/summary')
      .then(setSummary)
      .catch((err) => onNotify('error', (err as Error).message));
  }, []);

  const reportDefs = [
    {
      key: 'members',
      title: 'Membership Directory Report',
      desc: 'Complete roster with member IDs, roles, departments, status, and joining dates.',
      cols: ['member_code', 'full_name', 'role', 'department', 'status', 'date_joined'],
    },
    {
      key: 'finance',
      title: 'Financial Stewardship Report',
      desc: 'Tithes, offerings, donations, welfare funds, and church expenditure ledger.',
      cols: ['txn_code', 'txn_date', 'type', 'category', 'department', 'amount'],
    },
    {
      key: 'welfare',
      title: 'Welfare & Benevolence Report',
      desc: 'Welfare cases, urgency levels, approved aid, and officer assignments.',
      cols: ['case_code', 'member_name', 'category', 'urgency', 'amount_approved', 'status'],
    },
    {
      key: 'conferences',
      title: 'Conferences Report',
      desc: 'Convocations, schedules, venues, budgets, and registration status.',
      cols: ['title', 'start_date', 'end_date', 'venue', 'budget', 'status'],
    },
    {
      key: 'attendance',
      title: 'Service Attendance Report',
      desc: 'Men, women, youth, children, and visitor attendance counts by service.',
      cols: ['service_date', 'service_name', 'men_count', 'women_count', 'visitors_count', 'total_count'],
    },
    {
      key: 'departments',
      title: 'Departmental Performance Report',
      desc: 'Ministry leaders, schedules, budgets, and activities completed.',
      cols: ['name', 'leader_name', 'meeting_schedule', 'budget_allocation', 'activities_count'],
    },
    {
      key: 'events',
      title: 'Church Events Report',
      desc: 'Scheduled services, outreach events, dates, and locations.',
      cols: ['title', 'category', 'event_date', 'location'],
    },
  ];

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Official Church Reports Center"
        description="Generate and download audit-ready PDF and Excel (.xlsx) reports from live church database records."
      />

      {!summary ? (
        <div className="h-48 rounded-xl bg-slate-200/60 dark:bg-slate-800/60 animate-pulse" />
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {reportDefs.map((rep) => {
            const rows = summary[rep.key] || [];
            return (
              <div
                key={rep.key}
                className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-5 flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-medium text-[#4c1d95] dark:text-purple-300">
                      {rows.length} records
                    </span>
                  </div>
                  <h3 className="mt-1.5 font-display text-lg font-semibold text-[#0f1e3d] dark:text-white">
                    {rep.title}
                  </h3>
                  <p className="mt-1 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {rep.desc}
                  </p>
                </div>
                <div className="flex items-center gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => {
                      exportToExcel(`Church_Connect_${rep.key}`, rep.title, rows);
                      onNotify('success', `${rep.title} downloaded (Excel).`);
                    }}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Excel (.xlsx)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      exportToPdf(
                        `Church_Connect_${rep.key}`,
                        `CHURCH CONNECT — ${rep.title}`,
                        `Generated ${new Date().toLocaleDateString()} · ${rows.length} records`,
                        rep.cols,
                        rows.map((r) =>
                          rep.cols.map((c) => {
                            const val = r[c];
                            if (c === 'amount' || c === 'budget' || c === 'budget_allocation' || c === 'amount_approved') {
                              return formatCurrency(Number(val || 0));
                            }
                            return String(val ?? '—');
                          })
                        )
                      );
                      onNotify('success', `${rep.title} downloaded (PDF).`);
                    }}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
                  >
                    <Download className="w-3.5 h-3.5" />
                    PDF
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ============================================================================
// MEMBER SETTINGS & PROFILE PAGE
// ============================================================================

export function SettingsPage({
  user,
  darkMode,
  onToggleDarkMode,
  onUserUpdated,
  onNotify,
}: {
  user: UserAccount;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onUserUpdated: (u: UserAccount) => void;
  onNotify: (t: 'success' | 'error', m: string) => void;
}) {
  const [profile, setProfile] = useState({
    full_name: user.full_name,
    phone: user.phone || '',
    department: user.department || '',
    avatar_url: user.avatar_url || '',
    date_of_birth: user.date_of_birth || '',
    address: user.address || '',
    gender: user.gender || '',
    marital_status: user.marital_status || '',
    occupation: user.occupation || '',
    emergency_contact: user.emergency_contact || '',
  });
  const [passwords, setPasswords] = useState({ current_password: '', new_password: '' });
  const [verifyCode, setVerifyCode] = useState('');
  const [verifyPreview, setVerifyPreview] = useState('');
  const [verifyChannel, setVerifyChannel] = useState<'email' | 'phone'>('email');

  async function handleAvatarUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const url = await readFileAsDataUrl(file, 2);
      setProfile((p) => ({ ...p, avatar_url: url }));
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault();
    try {
      const updated = await apiFetch<UserAccount>('/api/auth/profile', {
        method: 'PUT',
        body: JSON.stringify(profile),
      });
      onUserUpdated(updated);
      onNotify('success', 'Profile information updated.');
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    try {
      const res = await apiFetch<{ message: string }>('/api/auth/change-password', {
        method: 'PUT',
        body: JSON.stringify(passwords),
      });
      setPasswords({ current_password: '', new_password: '' });
      onNotify('success', res.message);
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function requestVerification(channel: 'email' | 'phone') {
    setVerifyChannel(channel);
    try {
      const res = await apiFetch<{ message: string; verification_code_preview: string }>(
        '/api/auth/request-verification',
        { method: 'POST', body: JSON.stringify({ channel }) }
      );
      setVerifyPreview(res.verification_code_preview);
      setVerifyCode(res.verification_code_preview);
      onNotify('success', res.message);
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function confirmVerification(e: React.FormEvent) {
    e.preventDefault();
    try {
      const updated = await apiFetch<UserAccount>('/api/auth/confirm-verification', {
        method: 'POST',
        body: JSON.stringify({ channel: verifyChannel, code: verifyCode }),
      });
      onUserUpdated(updated);
      setVerifyPreview('');
      onNotify('success', `${verifyChannel === 'email' ? 'Email' : 'Phone'} verified!`);
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Account Profile & Security Settings"
        description="Manage your member profile, profile photograph, password security, email/phone verification, and display theme."
        actions={
          <button
            type="button"
            onClick={onToggleDarkMode}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800"
          >
            {darkMode ? <Sun className="w-4 h-4 text-[#e5c158]" /> : <Moon className="w-4 h-4 text-[#4c1d95]" />}
            {darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          </button>
        }
      />

      <div className="grid lg:grid-cols-12 gap-6">
        <form
          onSubmit={saveProfile}
          className="lg:col-span-7 bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4"
        >
          <div className="flex items-center gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
            <div className="w-16 h-16 rounded-full overflow-hidden border border-slate-300 dark:border-slate-700 bg-slate-100 dark:bg-[#080f1e] shrink-0">
              <ResilientImage
                src={profile.avatar_url}
                alt={profile.full_name}
                className="w-full h-full object-cover"
                fallbackTitle={profile.full_name.slice(0, 2)}
              />
            </div>
            <div>
              <div className="text-sm font-semibold text-[#0f1e3d] dark:text-white">
                {user.member_code} · {user.role}
              </div>
              <label className="mt-1.5 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
                <Upload className="w-3.5 h-3.5" />
                Upload Profile Photo
                <input type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} />
              </label>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium mb-1">Full Name</label>
              <input
                type="text"
                required
                value={profile.full_name}
                onChange={(e) => setProfile({ ...profile, full_name: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Phone Number</label>
              <input
                type="tel"
                value={profile.phone}
                onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Date of Birth</label>
              <input
                type="date"
                value={profile.date_of_birth}
                onChange={(e) => setProfile({ ...profile, date_of_birth: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Occupation</label>
              <input
                type="text"
                value={profile.occupation}
                onChange={(e) => setProfile({ ...profile, occupation: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium mb-1">Residential Address</label>
            <input
              type="text"
              value={profile.address}
              onChange={(e) => setProfile({ ...profile, address: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            />
          </div>

          <div>
            <label className="block text-xs font-medium mb-1">Emergency Contact</label>
            <input
              type="text"
              value={profile.emergency_contact}
              onChange={(e) => setProfile({ ...profile, emergency_contact: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            />
          </div>

          <button
            type="submit"
            className="px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
          >
            Save Profile Changes
          </button>
        </form>

        <div className="lg:col-span-5 space-y-6">
          {/* Verification Status */}
          <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
            <h3 className="font-display text-lg font-semibold text-[#0f1e3d] dark:text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#b48327]" />
              Contact Verification
            </h3>
            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <div className="font-medium text-[#0f1e3d] dark:text-white">Email Address</div>
                  <div className="text-slate-500">{user.email}</div>
                </div>
                {user.email_verified ? (
                  <StatusTag status="Verified" />
                ) : (
                  <button
                    type="button"
                    onClick={() => requestVerification('email')}
                    className="px-3 py-1.5 rounded-lg bg-[#0f1e3d] text-white"
                  >
                    Verify Email
                  </button>
                )}
              </div>
              <div className="flex items-center justify-between gap-2">
                <div>
                  <div className="font-medium text-[#0f1e3d] dark:text-white">Phone Number</div>
                  <div className="text-slate-500">{user.phone || 'Not provided'}</div>
                </div>
                {user.phone_verified ? (
                  <StatusTag status="Verified" />
                ) : (
                  <button
                    type="button"
                    onClick={() => requestVerification('phone')}
                    className="px-3 py-1.5 rounded-lg bg-[#0f1e3d] text-white"
                  >
                    Verify Phone
                  </button>
                )}
              </div>

              {verifyPreview && (
                <form onSubmit={confirmVerification} className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-2">
                  <div className="p-2 rounded bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200">
                    Code sent: <strong className="font-mono">{verifyPreview}</strong>
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={verifyCode}
                      onChange={(e) => setVerifyCode(e.target.value)}
                      className="flex-1 px-3 py-1.5 font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
                    />
                    <button type="submit" className="px-3 py-1.5 rounded-lg bg-[#4c1d95] text-white">
                      Confirm
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>

          {/* Change Password */}
          <form
            onSubmit={changePassword}
            className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3"
          >
            <h3 className="font-display text-lg font-semibold text-[#0f1e3d] dark:text-white flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-[#4c1d95] dark:text-purple-300" />
              Change Password
            </h3>
            <input
              type="password"
              required
              placeholder="Current Password"
              value={passwords.current_password}
              onChange={(e) => setPasswords({ ...passwords, current_password: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            />
            <input
              type="password"
              required
              minLength={6}
              placeholder="New Password (min 6 chars)"
              value={passwords.new_password}
              onChange={(e) => setPasswords({ ...passwords, new_password: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            />
            <button
              type="submit"
              className="px-4 py-2 text-xs font-medium rounded-lg bg-[#0f1e3d] text-white hover:bg-[#1b3366]"
            >
              Update Password
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
