import React, { useEffect, useState } from 'react';
import {
  Bell,
  CheckSquare,
  FileText,
  Plus,
  Square,
  Upload,
} from 'lucide-react';
import { apiFetch, formatShortDate, readFileAsDataUrl } from '../lib/api';
import { EmptyState, Modal, SectionHeader, StatusTag } from '../components/ui/ChurchUI';
import type { Meeting, MeetingTask, UserAccount } from '../types';

export default function MeetingsPage({
  user,
  onNotify,
}: {
  user: UserAccount;
  onNotify: (type: 'success' | 'error', message: string) => void;
}) {
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [loading, setLoading] = useState(true);
  const [typeFilter, setTypeFilter] = useState('All');

  const [createOpen, setCreateOpen] = useState(false);
  const [activeMeeting, setActiveMeeting] = useState<Meeting | null>(null);

  const [createForm, setCreateForm] = useState({
    title: '',
    meeting_type: 'Church Meeting',
    department: '',
    meeting_date: '',
    venue: '',
    agenda: '',
    invitees_text: 'Pastor Samuel Osei, Victoria Sterling, Hannah Thompson',
    document_name: '',
    document_url: '',
  });

  const [minutesDraft, setMinutesDraft] = useState('');
  const [attendeesDraft, setAttendeesDraft] = useState('');
  const [statusDraft, setStatusDraft] = useState('Scheduled');
  const [newTask, setNewTask] = useState({ title: '', assigned_to_name: '', due_date: '' });

  const canManage = [
    'Super Administrator',
    'Church Administrator',
    'Senior Pastor',
    'Assistant Pastor',
    'Church Secretary',
    'Department Leader',
  ].includes(user.role);

  async function loadMeetings() {
    try {
      const res = await apiFetch<Meeting[]>('/api/meetings');
      setMeetings(res);
      if (activeMeeting) {
        const refreshed = res.find((m) => m.id === activeMeeting.id) || null;
        setActiveMeeting(refreshed);
      }
    } catch (err) {
      onNotify('error', (err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadMeetings();
  }, []);

  function openWorkspace(m: Meeting) {
    setActiveMeeting(m);
    setMinutesDraft(m.minutes || '');
    setAttendeesDraft((m.attendees || []).join(', '));
    setStatusDraft(m.status);
  }

  async function handleDocUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const url = await readFileAsDataUrl(file, 3);
      setCreateForm((prev) => ({
        ...prev,
        document_name: file.name,
        document_url: url,
      }));
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    try {
      await apiFetch('/api/meetings', {
        method: 'POST',
        body: JSON.stringify({
          ...createForm,
          invitees: createForm.invitees_text
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean),
        }),
      });
      onNotify('success', 'Meeting scheduled and invitations dispatched.');
      setCreateOpen(false);
      loadMeetings();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function handleUpdateMinutes(e: React.FormEvent) {
    e.preventDefault();
    if (!activeMeeting) return;
    try {
      await apiFetch(`/api/meetings/${activeMeeting.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          minutes: minutesDraft,
          status: statusDraft,
          attendees: attendeesDraft
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean),
        }),
      });
      onNotify('success', 'Meeting minutes and attendance saved.');
      loadMeetings();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function handleAddTask(e: React.FormEvent) {
    e.preventDefault();
    if (!activeMeeting) return;
    try {
      await apiFetch(`/api/meetings/${activeMeeting.id}/tasks`, {
        method: 'POST',
        body: JSON.stringify(newTask),
      });
      setNewTask({ title: '', assigned_to_name: '', due_date: '' });
      onNotify('success', 'Action item assigned.');
      loadMeetings();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function toggleTask(task: MeetingTask) {
    try {
      await apiFetch(`/api/meetings/tasks/${task.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          status: task.status === 'Completed' ? 'Pending' : 'Completed',
        }),
      });
      loadMeetings();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function sendReminder(id: number) {
    try {
      const res = await apiFetch<{ message: string }>(`/api/meetings/${id}/remind`, {
        method: 'POST',
      });
      onNotify('success', res.message);
      loadMeetings();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  const filtered = meetings.filter(
    (m) => typeFilter === 'All' || m.meeting_type === typeFilter
  );

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Meeting & Action-Task Management"
        description="Schedule church, leadership, departmental, and emergency meetings with agendas, minutes, attendance, and follow-up action items."
        actions={
          canManage && (
            <button
              type="button"
              onClick={() => setCreateOpen(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675] whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              Schedule Meeting
            </button>
          )
        }
      />

      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-lg w-fit">
        {['All', 'Church Meeting', 'Leadership Meeting', 'Departmental Meeting', 'Emergency Meeting'].map(
          (t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTypeFilter(t)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                typeFilter === t
                  ? 'bg-white dark:bg-[#1a2947] text-[#0f1e3d] dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {t}
            </button>
          )
        )}
      </div>

      {loading ? (
        <div className="h-48 rounded-xl bg-slate-200/60 dark:bg-slate-800/60 animate-pulse" />
      ) : filtered.length === 0 ? (
        <EmptyState
          title="No meetings scheduled"
          description="Schedule a leadership council, departmental sync, or general church meeting."
          actionLabel={canManage ? 'Schedule Meeting' : undefined}
          onAction={canManage ? () => setCreateOpen(true) : undefined}
        />
      ) : (
        <div className="grid lg:grid-cols-2 gap-6">
          {filtered.map((m) => {
            const pendingTasks = (m.tasks || []).filter((t) => t.status === 'Pending').length;
            const completedTasks = (m.tasks || []).filter((t) => t.status === 'Completed').length;

            return (
              <div
                key={m.id}
                className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6 flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-xs font-medium text-[#4c1d95] dark:text-purple-300">
                        {m.meeting_type} {m.department ? `· ${m.department}` : ''}
                      </div>
                      <h2 className="mt-1 font-display text-lg font-semibold text-[#0f1e3d] dark:text-white">
                        {m.title}
                      </h2>
                    </div>
                    <StatusTag status={m.status} />
                  </div>

                  <div className="text-xs text-slate-600 dark:text-slate-300 font-mono">
                    {formatShortDate(m.meeting_date)} ·{' '}
                    {m.meeting_date.includes('T') ? m.meeting_date.split('T')[1] : ''} · {m.venue}
                  </div>

                  <div className="p-3 rounded-lg bg-slate-50 dark:bg-[#080f1e] border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 whitespace-pre-line">
                    <div className="font-semibold text-[#0f1e3d] dark:text-white mb-1">Agenda</div>
                    {m.agenda || 'No agenda items added yet.'}
                  </div>

                  <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 dark:text-slate-400">
                    <span>Invitees: {m.invitees.length}</span>
                    <span>Attended: {m.attendees.length}</span>
                    <span>
                      Tasks: {completedTasks} done / {pendingTasks} pending
                    </span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => openWorkspace(m)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg bg-[#0f1e3d] text-white hover:bg-[#1a2f5c]"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      Minutes, Tasks & Attendance
                    </button>
                    {m.document_url && (
                      <a
                        href={m.document_url}
                        download={m.document_name || 'meeting-doc'}
                        className="px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200"
                      >
                        Document
                      </a>
                    )}
                  </div>
                  {canManage && (
                    <button
                      type="button"
                      onClick={() => sendReminder(m.id)}
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                    >
                      <Bell className="w-3.5 h-3.5 text-[#b48327]" />
                      {m.reminder_sent ? 'Resend Reminder' : 'Send Reminder'}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Meeting Minutes & Tasks Modal */}
      <Modal
        open={Boolean(activeMeeting)}
        onClose={() => setActiveMeeting(null)}
        title={activeMeeting?.title || ''}
        subtitle={activeMeeting ? `${activeMeeting.meeting_type} · ${activeMeeting.venue}` : ''}
        maxWidth="max-w-3xl"
      >
        {activeMeeting && (
          <div className="space-y-6">
            <form onSubmit={handleUpdateMinutes} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Meeting Status
                  </label>
                  <select
                    disabled={!canManage}
                    value={statusDraft}
                    onChange={(e) => setStatusDraft(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                  >
                    <option>Scheduled</option>
                    <option>In Progress</option>
                    <option>Completed</option>
                    <option>Cancelled</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Recorded Attendees (comma-separated)
                  </label>
                  <input
                    type="text"
                    disabled={!canManage}
                    value={attendeesDraft}
                    onChange={(e) => setAttendeesDraft(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Official Meeting Minutes & Resolutions
                </label>
                <textarea
                  rows={4}
                  disabled={!canManage}
                  value={minutesDraft}
                  onChange={(e) => setMinutesDraft(e.target.value)}
                  placeholder="Record discussion summary, resolutions, and prayer points..."
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                />
              </div>

              {canManage && (
                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
                  >
                    Save Minutes & Attendance
                  </button>
                </div>
              )}
            </form>

            {/* Post-Meeting Action Tasks */}
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Action Items & Assigned Tasks
              </h3>

              <div className="space-y-2">
                {(activeMeeting.tasks || []).map((t) => (
                  <div
                    key={t.id}
                    className="flex items-center justify-between gap-3 p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#080f1e]"
                  >
                    <button
                      type="button"
                      onClick={() => toggleTask(t)}
                      className="flex items-center gap-2.5 text-left min-w-0"
                    >
                      {t.status === 'Completed' ? (
                        <CheckSquare className="w-4 h-4 text-emerald-600 shrink-0" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-400 shrink-0" />
                      )}
                      <div>
                        <div
                          className={`text-xs font-medium ${
                            t.status === 'Completed'
                              ? 'line-through text-slate-400'
                              : 'text-[#0f1e3d] dark:text-white'
                          }`}
                        >
                          {t.title}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          Assigned to {t.assigned_to_name}{' '}
                          {t.due_date ? `· Due ${formatShortDate(t.due_date)}` : ''}
                        </div>
                      </div>
                    </button>
                    <StatusTag status={t.status} />
                  </div>
                ))}
                {(activeMeeting.tasks || []).length === 0 && (
                  <p className="text-xs text-slate-500">No tasks assigned from this meeting yet.</p>
                )}
              </div>

              {canManage && (
                <form onSubmit={handleAddTask} className="grid grid-cols-1 sm:grid-cols-12 gap-2 pt-2">
                  <input
                    type="text"
                    required
                    value={newTask.title}
                    onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                    placeholder="New action task..."
                    className="sm:col-span-5 px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                  />
                  <input
                    type="text"
                    required
                    value={newTask.assigned_to_name}
                    onChange={(e) => setNewTask({ ...newTask, assigned_to_name: e.target.value })}
                    placeholder="Assignee name"
                    className="sm:col-span-3 px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                  />
                  <input
                    type="date"
                    value={newTask.due_date}
                    onChange={(e) => setNewTask({ ...newTask, due_date: e.target.value })}
                    className="sm:col-span-2 px-2 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
                  />
                  <button
                    type="submit"
                    className="sm:col-span-2 px-3 py-2 text-xs font-medium rounded-lg bg-[#0f1e3d] text-white hover:bg-[#1a2f5c]"
                  >
                    Assign
                  </button>
                </form>
              )}
            </div>
          </div>
        )}
      </Modal>

      {/* Schedule Meeting Modal */}
      <Modal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        title="Schedule Church Meeting"
        subtitle="Create agenda, upload briefing document, and send invitations."
      >
        <form onSubmit={handleCreate} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Meeting Title
              </label>
              <input
                type="text"
                required
                value={createForm.title}
                onChange={(e) => setCreateForm({ ...createForm, title: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Meeting Type
              </label>
              <select
                value={createForm.meeting_type}
                onChange={(e) => setCreateForm({ ...createForm, meeting_type: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              >
                <option>Church Meeting</option>
                <option>Leadership Meeting</option>
                <option>Departmental Meeting</option>
                <option>Emergency Meeting</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Date & Time
              </label>
              <input
                type="datetime-local"
                required
                value={createForm.meeting_date}
                onChange={(e) => setCreateForm({ ...createForm, meeting_date: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Venue / Room
              </label>
              <input
                type="text"
                required
                value={createForm.venue}
                onChange={(e) => setCreateForm({ ...createForm, venue: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Invitees (comma-separated)
            </label>
            <input
              type="text"
              value={createForm.invitees_text}
              onChange={(e) => setCreateForm({ ...createForm, invitees_text: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Meeting Agenda
            </label>
            <textarea
              rows={3}
              value={createForm.agenda}
              onChange={(e) => setCreateForm({ ...createForm, agenda: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="inline-flex items-center gap-2 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 cursor-pointer">
              <Upload className="w-3.5 h-3.5" />
              {createForm.document_name ? `Attached: ${createForm.document_name}` : 'Upload Agenda / Briefing Document'}
              <input type="file" className="hidden" onChange={handleDocUpload} />
            </label>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setCreateOpen(false)}
              className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
            >
              Schedule & Invite
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
