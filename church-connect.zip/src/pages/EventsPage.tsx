import React, { useEffect, useState } from 'react';
import {
  Bell,
  Calendar as CalendarIcon,
  Check,
  MapPin,
  Plus,
  Upload,
} from 'lucide-react';
import { apiFetch, formatShortDate, readFileAsDataUrl } from '../lib/api';
import { Modal, ResilientImage, SectionHeader, StatCard, StatusTag } from '../components/ui/ChurchUI';
import type {
  AppSettings,
  AttendanceRecord,
  ChurchEvent,
  UserAccount,
  VisitorRecord,
} from '../types';

export default function EventsPage({
  user,
  settings,
  onNotify,
}: {
  user: UserAccount;
  settings: AppSettings;
  onNotify: (type: 'success' | 'error', message: string) => void;
}) {
  const [tab, setTab] = useState<'events' | 'calendar' | 'attendance' | 'visitors' | 'gallery'>('events');
  const [events, setEvents] = useState<ChurchEvent[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [visitors, setVisitors] = useState<VisitorRecord[]>([]);
  const [loading, setLoading] = useState(true);

  const [eventModal, setEventModal] = useState(false);
  const [attModal, setAttModal] = useState(false);
  const [visitorModal, setVisitorModal] = useState(false);

  const [eventForm, setEventForm] = useState({
    title: '',
    description: '',
    category: 'Worship Service',
    event_date: '',
    end_date: '',
    location: 'Main Sanctuary',
    poster_url: '',
  });

  const [attForm, setAttForm] = useState({
    service_date: new Date().toISOString().slice(0, 10),
    service_name: 'Sunday Celebration Service',
    men_count: '190',
    women_count: '245',
    youth_count: '125',
    children_count: '98',
    visitors_count: '20',
  });

  const [visitorForm, setVisitorForm] = useState({
    full_name: '',
    email: '',
    phone: '',
    visit_date: new Date().toISOString().slice(0, 10),
    service_attended: 'Sunday 9:00 AM Service',
    invited_by: '',
    prayer_need: '',
  });

  const canManage = [
    'Super Administrator',
    'Church Administrator',
    'Senior Pastor',
    'Assistant Pastor',
    'Church Secretary',
    'Department Leader',
  ].includes(user.role);

  async function loadAll() {
    try {
      const [ev, at, vis] = await Promise.all([
        apiFetch<ChurchEvent[]>('/api/events'),
        apiFetch<AttendanceRecord[]>('/api/attendance'),
        apiFetch<VisitorRecord[]>('/api/visitors'),
      ]);
      setEvents(ev);
      setAttendance(at);
      setVisitors(vis);
    } catch (err) {
      onNotify('error', (err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAll();
  }, []);

  async function handleEventPoster(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const url = await readFileAsDataUrl(file, 3);
      setEventForm((prev) => ({ ...prev, poster_url: url }));
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function createEvent(e: React.FormEvent) {
    e.preventDefault();
    try {
      await apiFetch('/api/events', {
        method: 'POST',
        body: JSON.stringify(eventForm),
      });
      onNotify('success', 'Church event published.');
      setEventModal(false);
      loadAll();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function toggleRegister(ev: ChurchEvent) {
    try {
      const res = await apiFetch<{ registered: boolean }>(`/api/events/${ev.id}/register`, {
        method: 'POST',
      });
      onNotify(
        'success',
        res.registered ? `Registered for ${ev.title}.` : `Cancelled RSVP for ${ev.title}.`
      );
      loadAll();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function sendReminder(id: number) {
    try {
      const res = await apiFetch<{ message: string }>(`/api/events/${id}/remind`, { method: 'POST' });
      onNotify('success', res.message);
      loadAll();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function createAttendance(e: React.FormEvent) {
    e.preventDefault();
    try {
      await apiFetch('/api/attendance', {
        method: 'POST',
        body: JSON.stringify(attForm),
      });
      onNotify('success', 'Service attendance recorded.');
      setAttModal(false);
      loadAll();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function createVisitor(e: React.FormEvent) {
    e.preventDefault();
    try {
      await apiFetch('/api/visitors', {
        method: 'POST',
        body: JSON.stringify(visitorForm),
      });
      onNotify('success', 'New visitor registered for pastoral follow-up.');
      setVisitorModal(false);
      loadAll();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  async function updateVisitorStatus(v: VisitorRecord, follow_up_status: 'New' | 'Contacted' | 'Joined') {
    try {
      await apiFetch(`/api/visitors/${v.id}`, {
        method: 'PUT',
        body: JSON.stringify({ follow_up_status, notes: v.notes }),
      });
      onNotify('success', `${v.full_name} status updated to ${follow_up_status}.`);
      loadAll();
    } catch (err) {
      onNotify('error', (err as Error).message);
    }
  }

  // Monthly Calendar Builder (November 2026 default or current month)
  const calYear = 2026;
  const calMonth = 10; // November (0-indexed)
  const firstDay = new Date(calYear, calMonth, 1).getDay();
  const daysInMonth = new Date(calYear, calMonth + 1, 0).getDate();
  const calCells = Array.from({ length: firstDay + daysInMonth }, (_, idx) =>
    idx < firstDay ? null : idx - firstDay + 1
  );

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Church Events, Calendar & Attendance"
        description="Upcoming services, monthly and weekly calendars, RSVP tracking, service attendance, visitor follow-up, and parish gallery."
        actions={
          <>
            {canManage && tab === 'events' && (
              <button
                type="button"
                onClick={() => setEventModal(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
              >
                <Plus className="w-4 h-4" />
                Add Event
              </button>
            )}
            {canManage && tab === 'attendance' && (
              <button
                type="button"
                onClick={() => setAttModal(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
              >
                <Plus className="w-4 h-4" />
                Record Service Attendance
              </button>
            )}
            {tab === 'visitors' && (
              <button
                type="button"
                onClick={() => setVisitorModal(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675]"
              >
                <Plus className="w-4 h-4" />
                Register Visitor
              </button>
            )}
          </>
        }
      />

      {/* Segmented Tabs */}
      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-lg w-fit">
        {(
          [
            ['events', 'Upcoming Events'],
            ['calendar', 'Monthly & Weekly Calendar'],
            ['attendance', 'Service Attendance'],
            ['visitors', 'Visitor Registry'],
            ['gallery', 'Gallery & Heritage'],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              tab === id
                ? 'bg-white dark:bg-[#1a2947] text-[#0f1e3d] dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="h-60 rounded-xl bg-slate-200/60 dark:bg-slate-800/60 animate-pulse" />
      ) : tab === 'events' ? (
        <div className="grid md:grid-cols-2 gap-6">
          {events.map((ev) => (
            <div
              key={ev.id}
              className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden flex flex-col justify-between"
            >
              {ev.poster_url && (
                <div className="h-44 border-b border-slate-200 dark:border-slate-800">
                  <ResilientImage
                    src={ev.poster_url}
                    alt={ev.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <div className="flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                    <span className="font-medium text-[#4c1d95] dark:text-purple-300">
                      {ev.category}
                    </span>
                    <span className="font-mono">
                      {formatShortDate(ev.event_date)} ·{' '}
                      {ev.event_date.includes('T') ? ev.event_date.split('T')[1] : ''}
                    </span>
                  </div>
                  <h3 className="mt-1.5 font-display text-lg font-semibold text-[#0f1e3d] dark:text-white">
                    {ev.title}
                  </h3>
                  <p className="mt-1.5 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {ev.description}
                  </p>
                  <div className="mt-3 flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                    <span className="inline-flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5" />
                      {ev.location}
                    </span>
                    <span>·</span>
                    <span className="font-mono">{ev.registrations_count || 0} registered</span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => toggleRegister(ev)}
                    className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg transition-colors ${
                      ev.is_registered
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-300 dark:bg-emerald-950/40 dark:border-emerald-700 dark:text-emerald-300'
                        : 'bg-[#4c1d95] text-white hover:bg-[#3b1675]'
                    }`}
                  >
                    <Check className="w-3.5 h-3.5" />
                    {ev.is_registered ? 'Registered (Cancel RSVP)' : 'Register for Event'}
                  </button>

                  {canManage && (
                    <button
                      type="button"
                      onClick={() => sendReminder(ev.id)}
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                    >
                      <Bell className="w-3.5 h-3.5 text-[#b48327]" />
                      {ev.reminder_sent ? 'Reminder Sent' : 'Send Reminder'}
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : tab === 'calendar' ? (
        <div className="grid lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-lg font-semibold text-[#0f1e3d] dark:text-white flex items-center gap-2">
                <CalendarIcon className="w-4 h-4 text-[#b48327]" />
                November 2026 Monthly Calendar
              </h2>
            </div>
            <div className="grid grid-cols-7 gap-1.5 text-center text-[11px] font-semibold text-slate-500 mb-2">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
                <div key={d} className="py-1">
                  {d}
                </div>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-1.5">
              {calCells.map((day, idx) => {
                if (!day) return <div key={idx} className="h-20 rounded-lg bg-slate-50/50 dark:bg-[#080f1e]/40" />;
                const datePrefix = `2026-11-${String(day).padStart(2, '0')}`;
                const dayEvents = events.filter((e) => e.event_date.startsWith(datePrefix));
                return (
                  <div
                    key={idx}
                    className={`h-20 p-1.5 rounded-lg border text-left overflow-hidden ${
                      dayEvents.length > 0
                        ? 'border-[#4c1d95]/40 bg-purple-50/50 dark:bg-purple-950/20'
                        : 'border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <div className="text-[11px] font-mono font-semibold text-[#0f1e3d] dark:text-white">
                      {day}
                    </div>
                    {dayEvents.map((de) => (
                      <div
                        key={de.id}
                        className="mt-1 text-[10px] leading-tight font-medium text-[#4c1d95] dark:text-purple-300 truncate"
                        title={de.title}
                      >
                        {de.title}
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="lg:col-span-4 bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
            <h3 className="font-display text-lg font-semibold text-[#0f1e3d] dark:text-white">
              Weekly Worship Rhythm
            </h3>
            <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {[
                ['Sundays · 9:00 AM & 11:00 AM', 'Celebration Worship Services · Main Sanctuary'],
                ['Tuesdays · 5:30 PM', 'Welfare & Visitation Team Sync · Care Suite'],
                ['Wednesdays · 6:00 PM', 'Corporate Prayer & Bible Exposition · Prayer Chapel'],
                ['Thursdays · 6:30 PM', 'Sanctuary Choir Rehearsal · Choir Loft'],
                ['Fridays · 6:00 PM', 'Youth Fellowship & Mentorship · Youth Chapel'],
                ['Saturdays · 9:30 AM', 'Evangelism & Neighborhood Outreach · Mission Room'],
              ].map(([time, title], i) => (
                <div key={i} className="py-2.5">
                  <div className="font-mono font-medium text-[#4c1d95] dark:text-purple-300">
                    {time}
                  </div>
                  <div className="text-slate-700 dark:text-slate-200 mt-0.5">{title}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : tab === 'attendance' ? (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <StatCard
              label="Latest Total Attendance"
              value={attendance[0]?.total_count || 0}
              subtext={attendance[0]?.service_date || ''}
              accent="purple"
            />
            <StatCard
              label="Latest Visitors"
              value={attendance[0]?.visitors_count || 0}
              accent="gold"
            />
            <StatCard
              label="Avg Service Attendance"
              value={
                attendance.length
                  ? Math.round(
                      attendance.reduce((s, a) => s + a.total_count, 0) / attendance.length
                    )
                  : 0
              }
              accent="navy"
            />
            <StatCard label="Services Logged" value={attendance.length} accent="emerald" />
          </div>

          <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-[#080f1e] border-b border-slate-200 dark:border-slate-800 text-slate-500">
                  <tr>
                    <th className="py-3 px-4 font-medium">Date</th>
                    <th className="py-3 px-4 font-medium">Service</th>
                    <th className="py-3 px-4 font-medium text-right">Men</th>
                    <th className="py-3 px-4 font-medium text-right">Women</th>
                    <th className="py-3 px-4 font-medium text-right">Youth</th>
                    <th className="py-3 px-4 font-medium text-right">Children</th>
                    <th className="py-3 px-4 font-medium text-right">Visitors</th>
                    <th className="py-3 px-4 font-medium text-right">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {attendance.map((a) => (
                    <tr key={a.id}>
                      <td className="py-3 px-4 font-mono">{formatShortDate(a.service_date)}</td>
                      <td className="py-3 px-4 font-medium text-[#0f1e3d] dark:text-white">
                        {a.service_name}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">{a.men_count}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">{a.women_count}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">{a.youth_count}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums">{a.children_count}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-[#9a6b16] dark:text-[#e5c158]">
                        {a.visitors_count}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-[#4c1d95] dark:text-purple-300">
                        {a.total_count}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : tab === 'visitors' ? (
        <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-[#080f1e] border-b border-slate-200 dark:border-slate-800 text-slate-500">
                <tr>
                  <th className="py-3 px-4 font-medium">Visitor Name</th>
                  <th className="py-3 px-4 font-medium">Visit Date</th>
                  <th className="py-3 px-4 font-medium">Service</th>
                  <th className="py-3 px-4 font-medium">Contact</th>
                  <th className="py-3 px-4 font-medium">Prayer / Interest</th>
                  <th className="py-3 px-4 font-medium">Follow-up</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {visitors.map((v) => (
                  <tr key={v.id}>
                    <td className="py-3 px-4 font-medium text-[#0f1e3d] dark:text-white">
                      {v.full_name}
                      {v.invited_by && (
                        <div className="text-[11px] font-normal text-slate-400">
                          Invited by {v.invited_by}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4 font-mono">{formatShortDate(v.visit_date)}</td>
                    <td className="py-3 px-4">{v.service_attended}</td>
                    <td className="py-3 px-4">
                      <div>{v.email || '—'}</div>
                      <div className="text-[11px] text-slate-400">{v.phone}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-300 max-w-xs">
                      {v.prayer_need || '—'}
                    </td>
                    <td className="py-3 px-4">
                      {canManage ? (
                        <select
                          value={v.follow_up_status}
                          onChange={(e) =>
                            updateVisitorStatus(v, e.target.value as 'New' | 'Contacted' | 'Joined')
                          }
                          className="px-2 py-1 text-xs rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
                        >
                          <option value="New">New</option>
                          <option value="Contacted">Contacted</option>
                          <option value="Joined">Joined</option>
                        </select>
                      ) : (
                        <StatusTag status={v.follow_up_status} />
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-6">
            <h2 className="font-display text-xl font-semibold text-[#0f1e3d] dark:text-white">
              {settings.church_name} — Heritage & Vision
            </h2>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              {settings.about_history}
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {settings.gallery_images.map((img) => (
              <div
                key={img.id}
                className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden"
              >
                <div className="h-52">
                  <ResilientImage
                    src={img.url}
                    alt={img.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-4">
                  <div className="text-xs font-mono text-slate-500">{formatShortDate(img.date)}</div>
                  <div className="mt-1 text-sm font-semibold text-[#0f1e3d] dark:text-white">
                    {img.title}
                  </div>
                  <p className="mt-1 text-xs text-slate-600 dark:text-slate-300">{img.caption}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add Event Modal */}
      <Modal open={eventModal} onClose={() => setEventModal(false)} title="Add Church Event">
        <form onSubmit={createEvent} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Event Title
              </label>
              <input
                type="text"
                required
                value={eventForm.title}
                onChange={(e) => setEventForm({ ...eventForm, title: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Category
              </label>
              <select
                value={eventForm.category}
                onChange={(e) => setEventForm({ ...eventForm, category: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              >
                <option>Worship Service</option>
                <option>Prayer & Study</option>
                <option>Fellowship</option>
                <option>Outreach</option>
                <option>Special Service</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Start Date & Time
              </label>
              <input
                type="datetime-local"
                required
                value={eventForm.event_date}
                onChange={(e) => setEventForm({ ...eventForm, event_date: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Location
              </label>
              <input
                type="text"
                required
                value={eventForm.location}
                onChange={(e) => setEventForm({ ...eventForm, location: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Description
            </label>
            <textarea
              rows={3}
              value={eventForm.description}
              onChange={(e) => setEventForm({ ...eventForm, description: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e] text-slate-900 dark:text-white"
            />
          </div>
          <label className="inline-flex items-center gap-2 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 cursor-pointer">
            <Upload className="w-3.5 h-3.5" />
            Upload Event Poster
            <input type="file" accept="image/*" className="hidden" onChange={handleEventPoster} />
          </label>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setEventModal(false)}
              className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white"
            >
              Publish Event
            </button>
          </div>
        </form>
      </Modal>

      {/* Record Service Attendance Modal */}
      <Modal open={attModal} onClose={() => setAttModal(false)} title="Record Church Service Attendance">
        <form onSubmit={createAttendance} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium mb-1">Service Date</label>
              <input
                type="date"
                required
                value={attForm.service_date}
                onChange={(e) => setAttForm({ ...attForm, service_date: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Service Name</label>
              <input
                type="text"
                required
                value={attForm.service_name}
                onChange={(e) => setAttForm({ ...attForm, service_name: e.target.value })}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {(
              [
                ['men_count', 'Men'],
                ['women_count', 'Women'],
                ['youth_count', 'Youth'],
                ['children_count', 'Children'],
                ['visitors_count', 'Visitors'],
              ] as const
            ).map(([key, label]) => (
              <div key={key}>
                <label className="block text-xs font-medium mb-1">{label}</label>
                <input
                  type="number"
                  min="0"
                  value={attForm[key]}
                  onChange={(e) => setAttForm({ ...attForm, [key]: e.target.value })}
                  className="w-full px-3 py-2 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
                />
              </div>
            ))}
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setAttModal(false)}
              className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700"
            >
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white">
              Save Attendance
            </button>
          </div>
        </form>
      </Modal>

      {/* Register Visitor Modal */}
      <Modal open={visitorModal} onClose={() => setVisitorModal(false)} title="Register New Visitor">
        <form onSubmit={createVisitor} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              type="text"
              required
              placeholder="Visitor Full Name"
              value={visitorForm.full_name}
              onChange={(e) => setVisitorForm({ ...visitorForm, full_name: e.target.value })}
              className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            />
            <input
              type="date"
              value={visitorForm.visit_date}
              onChange={(e) => setVisitorForm({ ...visitorForm, visit_date: e.target.value })}
              className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            />
            <input
              type="email"
              placeholder="Email"
              value={visitorForm.email}
              onChange={(e) => setVisitorForm({ ...visitorForm, email: e.target.value })}
              className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            />
            <input
              type="tel"
              placeholder="Phone"
              value={visitorForm.phone}
              onChange={(e) => setVisitorForm({ ...visitorForm, phone: e.target.value })}
              className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
            />
          </div>
          <input
            type="text"
            placeholder="Invited By"
            value={visitorForm.invited_by}
            onChange={(e) => setVisitorForm({ ...visitorForm, invited_by: e.target.value })}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
          />
          <textarea
            rows={2}
            placeholder="Prayer need or welcome notes"
            value={visitorForm.prayer_need}
            onChange={(e) => setVisitorForm({ ...visitorForm, prayer_need: e.target.value })}
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080f1e]"
          />
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setVisitorModal(false)}
              className="px-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700"
            >
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white">
              Save Visitor
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
