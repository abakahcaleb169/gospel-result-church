export type UserRole =
  | 'Super Administrator'
  | 'Church Administrator'
  | 'Senior Pastor'
  | 'Assistant Pastor'
  | 'Church Secretary'
  | 'Financial Secretary'
  | 'Welfare Officer'
  | 'Department Leader'
  | 'Church Member';

export const ALL_ROLES: UserRole[] = [
  'Super Administrator',
  'Church Administrator',
  'Senior Pastor',
  'Assistant Pastor',
  'Church Secretary',
  'Financial Secretary',
  'Welfare Officer',
  'Department Leader',
  'Church Member',
];

export type NavSectionId =
  | 'dashboard'
  | 'pastor-portal'
  | 'announcements'
  | 'members'
  | 'welfare'
  | 'conferences'
  | 'meetings'
  | 'events'
  | 'departments'
  | 'finance'
  | 'notifications'
  | 'documents'
  | 'messages'
  | 'prayer'
  | 'reports'
  | 'settings'
  | 'admin';

export const ROLE_NAV_ACCESS: Record<UserRole, NavSectionId[]> = {
  'Super Administrator': [
    'dashboard',
    'pastor-portal',
    'announcements',
    'members',
    'welfare',
    'conferences',
    'meetings',
    'events',
    'departments',
    'finance',
    'notifications',
    'documents',
    'messages',
    'prayer',
    'reports',
    'settings',
    'admin',
  ],
  'Church Administrator': [
    'dashboard',
    'pastor-portal',
    'announcements',
    'members',
    'welfare',
    'conferences',
    'meetings',
    'events',
    'departments',
    'finance',
    'notifications',
    'documents',
    'messages',
    'prayer',
    'reports',
    'settings',
    'admin',
  ],
  'Senior Pastor': [
    'dashboard',
    'pastor-portal',
    'announcements',
    'members',
    'welfare',
    'conferences',
    'meetings',
    'events',
    'departments',
    'finance',
    'notifications',
    'documents',
    'messages',
    'prayer',
    'reports',
    'settings',
  ],
  'Assistant Pastor': [
    'dashboard',
    'pastor-portal',
    'announcements',
    'members',
    'welfare',
    'conferences',
    'meetings',
    'events',
    'departments',
    'notifications',
    'documents',
    'messages',
    'prayer',
    'reports',
    'settings',
  ],
  'Church Secretary': [
    'dashboard',
    'announcements',
    'members',
    'conferences',
    'meetings',
    'events',
    'departments',
    'notifications',
    'documents',
    'messages',
    'prayer',
    'reports',
    'settings',
  ],
  'Financial Secretary': [
    'dashboard',
    'announcements',
    'conferences',
    'finance',
    'welfare',
    'notifications',
    'documents',
    'messages',
    'reports',
    'settings',
  ],
  'Welfare Officer': [
    'dashboard',
    'announcements',
    'members',
    'welfare',
    'notifications',
    'documents',
    'messages',
    'prayer',
    'reports',
    'settings',
  ],
  'Department Leader': [
    'dashboard',
    'announcements',
    'conferences',
    'meetings',
    'events',
    'departments',
    'notifications',
    'documents',
    'messages',
    'prayer',
    'settings',
  ],
  'Church Member': [
    'dashboard',
    'announcements',
    'conferences',
    'meetings',
    'events',
    'departments',
    'notifications',
    'documents',
    'messages',
    'prayer',
    'settings',
  ],
};

export interface UserAccount {
  id: number;
  member_code: string;
  full_name: string;
  email: string;
  phone: string;
  role: UserRole;
  permissions: string[];
  department: string;
  status: 'Active' | 'Inactive' | 'Suspended';
  email_verified: boolean;
  phone_verified: boolean;
  avatar_url: string;
  date_of_birth: string;
  date_joined: string;
  address: string;
  gender: string;
  marital_status: string;
  occupation: string;
  emergency_contact: string;
  created_at: string;
}

export interface AppSettings {
  id: number;
  app_name: string;
  tagline: string;
  church_name: string;
  logo_url: string;
  primary_color: string;
  accent_color: string;
  navy_color: string;
  theme_mode: 'light' | 'dark';
  dark_mode_enabled: boolean;
  allow_registration: boolean;
  require_verification: boolean;
  email_notifications_enabled: boolean;
  contact_email: string;
  contact_phone: string;
  address: string;
  about_history: string;
  live_stream_url: string;
  daily_verse_text: string;
  daily_verse_ref: string;
  social_links: {
    facebook: string;
    youtube: string;
    instagram: string;
    website: string;
  };
  gallery_images: Array<{
    id: string;
    title: string;
    caption: string;
    url: string;
    date: string;
  }>;
}

export interface Announcement {
  id: number;
  title: string;
  description: string;
  image_url: string;
  category: string;
  is_important: boolean;
  is_pinned: boolean;
  is_emergency: boolean;
  allow_comments: boolean;
  publication_date: string;
  event_date: string;
  author_id: number;
  author_name: string;
  created_at: string;
  comments?: AnnouncementComment[];
}

export interface AnnouncementComment {
  id: number;
  announcement_id: number;
  user_id: number;
  author_name: string;
  author_role: string;
  content: string;
  created_at: string;
}

export interface WelfareCase {
  id: number;
  case_code: string;
  member_id: number | null;
  member_name: string;
  category:
    | 'Emergency Assistance'
    | 'Hospital Visit'
    | 'Bereavement Support'
    | 'Financial Assistance'
    | 'Food & Material Donation'
    | 'General Welfare';
  description: string;
  urgency: 'Low' | 'Medium' | 'High' | 'Critical';
  amount_requested: number;
  amount_approved: number;
  materials_provided: string;
  status: 'Pending' | 'In Progress' | 'Approved' | 'Completed' | 'Rejected';
  assigned_officer_id: number | null;
  assigned_officer_name: string;
  confidential_notes: string;
  assistance_notes: string;
  visit_date: string;
  created_by: number;
  created_at: string;
  updated_at: string;
}

export interface Conference {
  id: number;
  title: string;
  description: string;
  poster_url: string;
  start_date: string;
  end_date: string;
  venue: string;
  theme: string;
  speakers: Array<{ name: string; role: string; topic: string }>;
  programme: Array<{ day: string; time: string; session: string; speaker: string }>;
  committees: Array<{ name: string; lead: string; members: string }>;
  budget: number;
  status: 'Upcoming' | 'Ongoing' | 'Completed';
  registrations_count?: number;
  is_registered?: boolean;
}

export interface ConferenceRegistration {
  id: number;
  conference_id: number;
  user_id: number | null;
  full_name: string;
  email: string;
  phone: string;
  department: string;
  attended: boolean;
  registered_at: string;
}

export interface Meeting {
  id: number;
  title: string;
  meeting_type: 'Church Meeting' | 'Leadership Meeting' | 'Departmental Meeting' | 'Emergency Meeting';
  department: string;
  meeting_date: string;
  venue: string;
  agenda: string;
  minutes: string;
  document_url: string;
  document_name: string;
  invitees: string[];
  attendees: string[];
  status: 'Scheduled' | 'In Progress' | 'Completed' | 'Cancelled';
  reminder_sent: boolean;
  created_by: number;
  created_at: string;
  tasks?: MeetingTask[];
}

export interface MeetingTask {
  id: number;
  meeting_id: number;
  title: string;
  assigned_to_id: number | null;
  assigned_to_name: string;
  due_date: string;
  status: 'Pending' | 'Completed';
  created_at: string;
}

export interface Department {
  id: number;
  name: string;
  description: string;
  leader_id: number | null;
  leader_name: string;
  meeting_schedule: string;
  budget_allocation: number;
  performance_notes: string;
  activities_count: number;
  created_at: string;
  members_count?: number;
}

export interface DepartmentMember {
  id: number;
  department_id: number;
  user_id: number;
  member_name: string;
  role_in_dept: string;
  joined_at: string;
}

export interface DepartmentAnnouncement {
  id: number;
  department_id: number;
  title: string;
  content: string;
  author_name: string;
  created_at: string;
}

export interface ChurchEvent {
  id: number;
  title: string;
  description: string;
  category: string;
  event_date: string;
  end_date: string;
  location: string;
  poster_url: string;
  reminder_sent: boolean;
  created_by: number;
  created_at: string;
  registrations_count?: number;
  attended_count?: number;
  is_registered?: boolean;
}

export interface FinancialTransaction {
  id: number;
  txn_code: string;
  type: 'Income' | 'Expense';
  category: string;
  amount: number;
  department: string;
  conference_id: number | null;
  member_id: number | null;
  member_name: string;
  payment_method: string;
  reference_no: string;
  description: string;
  txn_date: string;
  recorded_by: string;
  created_at: string;
}

export interface ChurchDocument {
  id: number;
  title: string;
  category: string;
  description: string;
  file_name: string;
  file_size: string;
  mime_type: string;
  file_data: string;
  uploaded_by: string;
  access_level: 'All Members' | 'Leaders' | 'Pastors & Admins';
  created_at: string;
}

export interface ChurchMessage {
  id: number;
  sender_id: number;
  sender_name: string;
  sender_role: string;
  recipient_id: number | null;
  recipient_name: string;
  channel: 'Direct' | 'Department' | 'Leadership' | 'Pastoral' | 'Broadcast';
  department: string;
  subject: string;
  body: string;
  is_read: boolean;
  created_at: string;
}

export interface NotificationItem {
  id: number;
  user_id: number | null;
  title: string;
  message: string;
  type: 'Announcement' | 'Service' | 'Conference' | 'Meeting' | 'Welfare' | 'Event' | 'Admin';
  link_page: string;
  is_read: boolean;
  email_dispatched: boolean;
  created_at: string;
}

export interface PrayerRequest {
  id: number;
  user_id: number | null;
  requester_name: string;
  category: 'Prayer Request' | 'Testimony' | 'Counselling Request';
  title: string;
  details: string;
  is_confidential: boolean;
  preferred_date: string;
  status: 'Submitted' | 'Praying' | 'Scheduled' | 'Answered' | 'Completed';
  pastor_response: string;
  created_at: string;
}

export interface VisitorRecord {
  id: number;
  full_name: string;
  email: string;
  phone: string;
  visit_date: string;
  service_attended: string;
  invited_by: string;
  prayer_need: string;
  follow_up_status: 'New' | 'Contacted' | 'Joined';
  notes: string;
  created_at: string;
}

export interface AttendanceRecord {
  id: number;
  service_date: string;
  service_name: string;
  men_count: number;
  women_count: number;
  youth_count: number;
  children_count: number;
  visitors_count: number;
  total_count: number;
  recorded_by: string;
  created_at: string;
}

export interface SystemLog {
  id: number;
  user_id: number | null;
  user_name: string;
  user_role: string;
  action: string;
  module: string;
  details: string;
  created_at: string;
}
