import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  ImageOff,
  X,
  XCircle,
} from 'lucide-react';

export function LoadingScreen({
  appName = 'GOSPEL RESULTS CHURCH GHANA',
  tagline = 'Connecting Members, Strengthening Faith, Building Community.',
  logoUrl = '/assets/aistudio/IMG_0954_b4f1f733.jpeg',
}: {
  appName?: string;
  tagline?: string;
  logoUrl?: string;
}) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#080f1e] text-white px-6">
      <div className="flex flex-col items-center max-w-md text-center">
        <div className="w-20 h-20 rounded-full overflow-hidden border border-[#b48327]/60 bg-[#0f1e3d] flex items-center justify-center mb-6 shadow-lg">
          {logoUrl ? (
            <img
              src={logoUrl}
              alt={appName}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          ) : (
            <span className="font-display text-2xl font-bold text-[#d4af37]">CC</span>
          )}
        </div>
        <h1 className="font-display text-2xl font-semibold tracking-tight text-white">
          {appName}
        </h1>
        <p className="mt-2 text-sm text-slate-300 leading-relaxed">{tagline}</p>
        <div className="mt-8 w-48 h-1 bg-slate-800 rounded-full overflow-hidden">
          <div className="h-full w-1/2 bg-gradient-to-r from-[#6d28d9] to-[#d4af37] animate-[pulse_1.2s_ease-in-out_infinite]" />
        </div>
      </div>
    </div>
  );
}

export function SectionHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
      <div className="min-w-0">
        <h1 className="font-display text-2xl sm:text-3xl font-semibold text-[#0f1e3d] dark:text-white tracking-tight text-balance">
          {title}
        </h1>
        {description && (
          <p className="mt-1.5 text-sm text-slate-600 dark:text-slate-300 max-w-2xl">
            {description}
          </p>
        )}
      </div>
      {actions && (
        <div className="flex flex-wrap items-center gap-2.5 shrink-0">{actions}</div>
      )}
    </div>
  );
}

export function StatCard({
  label,
  value,
  subtext,
  accent = 'navy',
}: {
  label: string;
  value: string | number;
  subtext?: string;
  accent?: 'purple' | 'gold' | 'navy' | 'emerald';
}) {
  const accentText =
    accent === 'purple'
      ? 'text-[#4c1d95] dark:text-purple-300'
      : accent === 'gold'
      ? 'text-[#9a6b16] dark:text-[#e5c158]'
      : accent === 'emerald'
      ? 'text-emerald-700 dark:text-emerald-400'
      : 'text-[#0f1e3d] dark:text-white';

  return (
    <div className="bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-800 rounded-xl p-5">
      <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
        {label}
      </div>
      <div className={`mt-2 text-2xl sm:text-3xl font-semibold font-mono tabular-nums ${accentText}`}>
        {value}
      </div>
      {subtext && (
        <div className="mt-1.5 text-xs text-slate-500 dark:text-slate-400 truncate">
          {subtext}
        </div>
      )}
    </div>
  );
}

export function StatusTag({
  status,
}: {
  status: string;
}) {
  const s = status.toLowerCase();
  if (
    ['active', 'approved', 'completed', 'answered', 'joined', 'paid', 'income', 'verified'].includes(s)
  ) {
    return (
      <span className="inline-flex items-center gap-1.5 rounded px-2 py-0.5 text-xs font-medium bg-emerald-50 text-emerald-800 border border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-800/60 whitespace-nowrap">
        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
        {status}
      </span>
    );
  }
  if (
    ['pending', 'in progress', 'scheduled', 'praying', 'contacted', 'upcoming', 'new', 'submitted', 'medium'].includes(s)
  ) {
    return (
      <span className="inline-flex items-center gap-1.5 rounded px-2 py-0.5 text-xs font-medium bg-amber-50 text-amber-800 border border-amber-200 dark:bg-amber-950/50 dark:text-amber-300 dark:border-amber-800/60 whitespace-nowrap">
        <Clock className="w-3.5 h-3.5 shrink-0" />
        {status}
      </span>
    );
  }
  if (['rejected', 'suspended', 'cancelled', 'critical', 'high', 'expense', 'inactive'].includes(s)) {
    return (
      <span className="inline-flex items-center gap-1.5 rounded px-2 py-0.5 text-xs font-medium bg-red-50 text-red-800 border border-red-200 dark:bg-red-950/50 dark:text-red-300 dark:border-red-800/60 whitespace-nowrap">
        <XCircle className="w-3.5 h-3.5 shrink-0" />
        {status}
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 rounded px-2 py-0.5 text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 whitespace-nowrap">
      {status}
    </span>
  );
}

export function ResilientImage({
  src,
  alt,
  className = '',
  fallbackTitle,
}: {
  src?: string;
  alt: string;
  className?: string;
  fallbackTitle?: string;
}) {
  const [failed, setFailed] = useState(false);

  if (!src || failed) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-[#0f1e3d] via-[#2e1065] to-[#1e1b4b] text-white/80 p-4 ${className}`}
      >
        <ImageOff className="w-6 h-6 text-[#d4af37] mb-1.5" />
        {fallbackTitle && (
          <span className="text-xs font-medium text-center line-clamp-2 text-slate-200">
            {fallbackTitle}
          </span>
        )}
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
}

export function Modal({
  open,
  onClose,
  title,
  subtitle,
  children,
  maxWidth = 'max-w-2xl',
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  maxWidth?: string;
}) {
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className={`w-full ${maxWidth} max-h-[90vh] flex flex-col bg-white dark:bg-[#111d36] border border-slate-200 dark:border-slate-700 rounded-xl shadow-2xl overflow-hidden`}
      >
        <div className="flex items-start justify-between gap-4 px-6 py-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h2 className="font-display text-xl font-semibold text-[#0f1e3d] dark:text-white">
              {title}
            </h2>
            {subtitle && (
              <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                {subtitle}
              </p>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-6 overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}

export function EmptyState({
  title,
  description,
  actionLabel,
  onAction,
}: {
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
}) {
  return (
    <div className="bg-white dark:bg-[#111d36] border border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-10 text-center">
      <h3 className="text-base font-semibold text-[#0f1e3d] dark:text-white">{title}</h3>
      <p className="mt-1.5 text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto">
        {description}
      </p>
      {actionLabel && onAction && (
        <button
          type="button"
          onClick={onAction}
          className="mt-5 px-4 py-2 text-sm font-medium rounded-lg bg-[#4c1d95] text-white hover:bg-[#3b1675] transition-colors"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}

export function ToastBanner({
  toast,
  onDismiss,
}: {
  toast: { type: 'success' | 'error'; message: string } | null;
  onDismiss: () => void;
}) {
  if (!toast) return null;
  return (
    <div className="fixed bottom-5 right-5 z-50 max-w-md animate-in fade-in slide-in-from-bottom-2">
      <div
        className={`flex items-start gap-3 px-4 py-3 rounded-xl border shadow-lg ${
          toast.type === 'success'
            ? 'bg-white dark:bg-[#111d36] border-emerald-300 dark:border-emerald-700 text-emerald-900 dark:text-emerald-200'
            : 'bg-white dark:bg-[#111d36] border-red-300 dark:border-red-700 text-red-900 dark:text-red-200'
        }`}
      >
        {toast.type === 'success' ? (
          <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
        ) : (
          <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 shrink-0 mt-0.5" />
        )}
        <p className="text-sm font-medium leading-snug">{toast.message}</p>
        <button
          type="button"
          onClick={onDismiss}
          className="text-slate-400 hover:text-slate-700 dark:hover:text-white ml-2"
          aria-label="Dismiss message"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
